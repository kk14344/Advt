varying vec4 v_fragmentColor;
varying vec2 v_texCoord;

uniform float u_phase;
uniform float u_tier;
uniform float u_intensity;

vec3 rbRotateHue(vec3 col, float angle)
{
    const vec3 k = vec3(0.57735, 0.57735, 0.57735);
    float cosA = cos(angle);
    return col * cosA + cross(k, col) * sin(angle) + k * dot(k, col) * (1.0 - cosA);
}

void main()
{
    vec2 uv = v_texCoord;
    vec4 col = texture2D(CC_Texture0, uv);
    if (col.a < 0.04) {
        discard;
    }

    // Preserve outer silver-white 8-corner chamfered border (pixel coords 0..8 and 103..111)
    vec2 pxCoord = floor(uv * 112.0);
    float inside = step(9.0, pxCoord.x) * step(pxCoord.x, 102.0)
                 * step(9.0, pxCoord.y) * step(pxCoord.y, 102.0);

    vec3 outRgb = col.rgb;
    if (inside > 0.5 && u_intensity > 0.01) {
        vec2 qUv = (floor(pxCoord * 0.5) * 2.0 + 1.0) / 112.0;
        float lum = dot(col.rgb, vec3(0.299, 0.587, 0.114));
        float blackMask = smoothstep(0.08, 0.22, lum);

        float t = CC_Time.y * 0.85 + u_phase;
        float tx = sin(t * 1.10) * 0.72;
        float d = length(qUv - vec2(0.5, 0.52));

        // Gentle jewel rainbow breathing (never harsh RGB neon)
        float hueWave = sin(t * 0.55 + qUv.x * 1.6 + tx * 0.65) * 0.22 * u_intensity;
        vec3 jewel = rbRotateHue(col.rgb, hueWave);

        // Subtle rotating 12-ray royal golden sunburst from card center
        float angle = atan(qUv.y - 0.52, qUv.x - 0.5);
        float rays = 0.5 + 0.5 * cos(angle * 12.0 - t * 0.85);
        float centerHalo = (1.0 - smoothstep(0.05, 0.48, d)) * rays;
        float rayAmt = (u_tier < 1.5) ? 0.05 : ((u_tier < 2.5) ? 0.13 : 0.20);

        // Sweeping warm champagne metallic light ribbon
        float sw = fract(qUv.x * 0.55 + (1.0 - qUv.y) * 0.65 - t * 0.30 + tx * 0.22);
        float wave = smoothstep(0.35, 0.50, sw) * (1.0 - smoothstep(0.50, 0.65, sw));
        float waveAmt = (u_tier > 2.5) ? 0.20 : 0.11;

        vec3 gold = vec3(1.0, 0.88, 0.54);
        outRgb = jewel + gold * (centerHalo * rayAmt + wave * waveAmt) * u_intensity * blackMask;
    }

    gl_FragColor = vec4(clamp(outRgb, 0.0, 1.0) * v_fragmentColor.rgb, col.a * v_fragmentColor.a);
}
