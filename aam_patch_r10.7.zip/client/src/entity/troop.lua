local config_manager = require "logic.config_manager"
local skill_manager = require "logic.skill_manager"
local client_constants = require "util.client_constants"
local constants = require "util.constants"

local CONST_BATTLE = client_constants.BATTLE

local DEATH_ACTION = CONST_BATTLE["death_action"]
local VICTORY_ACTION = CONST_BATTLE["victory_action"]

local LEFT_TROOP_ID = CONST_BATTLE["left_troop_id"]
local RIGHT_TROOP_ID = CONST_BATTLE["right_troop_id"]

local ROW_GAP, COL_GAP = CONST_BATTLE["row_gap"], CONST_BATTLE["col_gap"]

local ROLE_SHADOW_SCALE = CONST_BATTLE["role_shadow_scale"]
local ROLE_SHADOW_OFFSET = CONST_BATTLE["role_shadow_offset"]

local WALK_ANIMATION_TIME = 0.1

local SPEED_FACTOR = skill_manager.SPEED_FACTOR
local DODGE_FACTOR = skill_manager.DODGE_FACTOR
local AUTHORITY_FACTOR = skill_manager.AUTHORITY_FACTOR
local skill_buffer_config = config_manager.skill_buffer_config
local math = math
local math_random = math.random
local math_floor = math.floor
local math_ceil = math.ceil
local bit_rshift = bit.rshift
local bit_band = bit.band

-- [MOD] 四圣四凶定制 buff：显示名独立，实际结算仍按基础类型
local BUFF_BASE_NAME = {
    chaos_bleed = "bleed",
    chaos_poison = "poison",
    chaos_weak = "weak",
    qiongqi_bleed = "bleed",
    taowu_weak = "weak",
    dragon_poison = "poison",
    tiger_bleed = "bleed",
    phoenix_poison = "poison",
    turtle_injured = "seriously_injured",
    dragon_weak = "weak",
    world_bleed = "bleed",
    final_poison = "poison",
}
local function BaseBuffName(name)
    return BUFF_BASE_NAME[name] or name
end

local function LOG(adress, details)
    local path = cc.FileUtils:getInstance():getWritablePath()
    local file = io.open(path .. "log.txt", "a+")
    file:write(adress, "|", details, "\n")
    file:close()
end

-- 方向朝向
local DIRECTION = {
    ["none"] = 0,
    ["front"] = 1,
    ["down"] = 2,
    ["back"] = 3,
    ["up"] = 4,
    ["center"] = 5
}

local troop = {}
troop.__index = troop

function troop.New(id)
    local t = {
        id = id,

        battle_point = 0,

        speed = 0,
        dodge = 0,
        defense = 0,
        authority = 0,

        original_speed = 0,
        original_dodge = 0,
        original_defense = 0,
        original_authority = 0,

        cur_bp = 0,
        max_bp = 0,

        roles = {},
        role_num = 0,
        cultivation_property = {},
        weapon_info = {},
        init_position_xs = {}, -- 初始坐标x
        init_position_ys = {}, -- 初始坐标y

        is_play_action = false,

        center_x = 0,
        center_y = 0,

        effect_x = 0, -- 特效播放坐标
        effect_y = 0,

        role_num_per_col = {0, 0, 0, 0},

        buffer_list = {}
    }

    return setmetatable(t, troop)
end

function troop:SetProperty(max_bp, cur_bp, cur_shield_bp, enemy, speed, defense, dodge, authority, original_speed,
    original_defense, original_dodge, original_authority)
    self.speed = tonumber(speed)
    self.defense = tonumber(defense)
    self.dodge = tonumber(dodge)
    self.authority = tonumber(authority)

    self.original_speed = tonumber(original_speed)
    self.original_defense = tonumber(original_defense)
    self.original_dodge = tonumber(original_dodge)
    self.original_authority = tonumber(original_authority)

    self.cur_bp = cur_bp
    self.max_bp = max_bp
    self.cur_shield_bp = cur_shield_bp or 0

    self.enemy = enemy

    self.exhaust_turn = 0
    self.clear_turn = 0
    self.absorb_turn = 0
    self.absorb_value = 0

    self.last_turn_skill = nil
end

function troop:SetCultivation(cultivation)
    self.cultivation_property = cultivation
end

function troop:SetWeaponInfo(weapon_info)
    self.weapon_info = weapon_info
end

function troop:CalcDamageFactor()
    self.defense = math.max(self.defense, -50)
    self.dodge = math.max(self.dodge, -50)
    self.speed = math.max(self.speed, -50)

    self.damage_reduction_factor = 100 / (100 + self.defense)
    self.dodge_chance = math.ceil(self.dodge / (100 + self.dodge) * 1000)

    self.final_damage_modifier = (self.authority > self.enemy.authority) and
                                     (1 + (self.authority - self.enemy.authority) * AUTHORITY_FACTOR) or 1.0

    self.bp_increase_factor = 1 + DODGE_FACTOR * self.dodge
end

function troop:SetRolePosition(i, x, y)
    local role = self.roles[i]

    role:SetPosition(x, y)
    role:SetShadowPosition(x, y - ROLE_SHADOW_OFFSET)
    role.shadow:setScaleX(1.0)

    self.init_position_xs[i] = x
    self.init_position_ys[i] = y
end

local POSITION_MAP = {{1, 26, 27, 28, 29, 30, 31, 32, 42, 47}, {2, 3, 14, 15, 20, 21, 24, 25, 43, 48},
                      {4, 5, 6, 7, 16, 17, 22, 23, 44, 49}, {8, 9, 10, 11, 12, 13, 18, 19, 45, 50},
                      {33, 34, 35, 36, 37, 38, 39, 40, 41, 46}}

-- 更新阵型
function troop:UpdateFormation()
    local col_num = 0
    if self.role_num == 1 then
        col_num = 1
    elseif self.role_num <= 3 then
        col_num = 2
    elseif self.role_num <= 7 then
        col_num = 3
    elseif self.role_num <= 30 then
        col_num = 4
    else
        col_num = 5
    end
    -- print("UpdateFormation===>",self.role_num, col_num)

    local init_x, init_y = 0, 0
    if self.id == LEFT_TROOP_ID then
        init_x = CONST_BATTLE["left_troop_x"] + (col_num - 4) * CONST_BATTLE["troop_offset_x"]
        init_y = CONST_BATTLE["left_troop_y"]
        -- 军团中心点
        self.center_x = init_x - COL_GAP * 1.5
        -- 特效播放点
        self.effect_x = init_x - COL_GAP * 0.5
    else
        init_x = CONST_BATTLE["right_troop_x"] + (4 - col_num) * CONST_BATTLE["troop_offset_x"]
        init_y = CONST_BATTLE["right_troop_y"]
        -- 军团中心点
        self.center_x = init_x + COL_GAP * 1.5
        -- 特效播放点
        self.effect_x = init_x + COL_GAP * 0.5
    end

    self.center_y = init_y
    self.effect_y = init_y

    -- 统计每排的人数
    for col = 1, col_num do
        self.role_num_per_col[col] = 0
        local map = POSITION_MAP[col]

        for j = 1, #map do
            if map[j] <= self.role_num then
                self.role_num_per_col[col] = self.role_num_per_col[col] + 1
            else
                break
            end
        end
        -- print("----->", col, self.role_num_per_col[col])
    end

    local roles = self.roles
    for col = 1, col_num do
        local map = POSITION_MAP[col]
        local role_num = self.role_num_per_col[col]
        -- print("---->",col,role_num)

        local x, y = init_x, init_y
        if role_num % 2 == 0 then
            for i = 1, role_num do
                local role_index = map[i]
                local role = roles[role_index]

                if i % 2 == 0 then
                    -- 偶数站上面
                    self:SetRolePosition(role_index, x, y + ROW_GAP * (math_floor(i / 2) - 0.5))
                    role.sprite:setLocalZOrder(150 - i)
                    role.shadow:setLocalZOrder(150 - i)
                else
                    self:SetRolePosition(role_index, x, y - ROW_GAP * (math_floor(i / 2) + 0.5))
                    role.sprite:setLocalZOrder(150 + i)
                    role.shadow:setLocalZOrder(150 + i)
                end
            end

        else

            self:SetRolePosition(map[1], x, y)
            for i = 2, role_num do
                local role_index = map[i]
                local role = roles[role_index]

                if i % 2 == 0 then
                    -- 偶数站上面
                    self:SetRolePosition(role_index, x, y + ROW_GAP * math_floor(i / 2))
                    role.sprite:setLocalZOrder(150 - i)
                    role.shadow:setLocalZOrder(150 - i)
                else
                    self:SetRolePosition(role_index, x, y - ROW_GAP * math_floor(i / 2))
                    role.sprite:setLocalZOrder(150 + i)
                    role.shadow:setLocalZOrder(150 + i)
                end
            end
        end

        if self.id == LEFT_TROOP_ID then
            init_x = init_x - COL_GAP
        else
            init_x = init_x + COL_GAP
        end
    end

    self.is_play_final_action = false
    self:StopPlayAction()
end

function troop:SetAction(action)
    if not action then
        self.cur_action = nil
        self.remain_time = 0
        self.total_time = 0
        self.action_duration = 0
        self.is_play_action = false
        return
    end
    self.cur_action = action

    -- 剩余时间, 单位秒
    self.remain_time = (action.time + math_random(0, action.time_offset * 2) - action.time_offset) / 1000

    self.total_time = self.remain_time

    -- 已运行过的时间
    self.action_duration = 0

    self.action_end_time = action.end_time / 1000

    -- 转身频率
    self.turn_around_freq = action.turn_around_freq / 1000

    -- 颜色
    self.init_r = bit_band(bit_rshift(action.init_color, 16), 0xff) * action.init_color_alpha
    self.init_g = bit_band(bit_rshift(action.init_color, 8), 0xff) * action.init_color_alpha
    self.init_b = bit_band(action.init_color, 0xff) * action.init_color_alpha

    self.end_r = bit_band(bit_rshift(action.end_color, 16), 0xff) * action.end_color_alpha
    self.end_g = bit_band(bit_rshift(action.end_color, 8), 0xff) * action.end_color_alpha
    self.end_b = bit_band(action.end_color, 0xff) * action.end_color_alpha

    -- 归位操作
    if action.is_reset_pos then
        local init_position_xs, init_position_ys = self.init_position_xs, self.init_position_ys
        for i = 1, self.role_num do
            local role = self.roles[i]

            -- print("SetAction--->",i)
            role.speed_x = (init_position_xs[i] - role.position_x) / self.total_time
            role.speed_y = (init_position_ys[i] - role.position_y) / self.total_time

            if self.cur_action.is_turn_around then
                role:TurnAroundAnimation(self.turn_around_freq)
            else
                role:WalkAnimation(1, WALK_ANIMATION_TIME)
            end

            role:SetVibration(action)
        end
    else

        for i = 1, self.role_num do
            local delta = 0
            local speed_x, speed_y = 0, 0

            -- 计算x轴和y轴方向上的速度
            if action.move_distance ~= 0 then
                delta = (action.move_distance + math_random(0, action.move_offset * 2) - action.move_offset) /
                            self.remain_time
            end

            if action.move_direction == DIRECTION["up"] then
                speed_y = delta

            elseif action.move_direction == DIRECTION["down"] then
                speed_y = -delta

            elseif action.move_direction == DIRECTION["front"] then
                speed_x = self.id == LEFT_TROOP_ID and delta or -delta

            elseif action.move_direction == DIRECTION["back"] then
                speed_x = self.id == LEFT_TROOP_ID and -delta or delta

            elseif action.move_direction == DIRECTION["center"] then
                speed_x = delta
                speed_y = delta
            end

            local role = self.roles[i]
            role.speed_x = speed_x
            role.speed_y = speed_y

            if self.cur_action.is_turn_around then
                role:TurnAroundAnimation(self.turn_around_freq)

            elseif action.move_direction == DIRECTION["front"] then
                role:WalkAnimation(self.id == LEFT_TROOP_ID and 3 or 2, WALK_ANIMATION_TIME)
            end
            role:SetVibration(action)
        end
    end
end

function troop:GetVibrationOffset(elapsed_time)
    local vx, vy = 0, 0
    if self.vibration_freq > 0 then

        self.vibration_duration = self.vibration_duration + elapsed_time
        if self.vibration_duration >= self.vibration_freq then
            self.vibration_duration = 0

            vx = (math_random(1, 100) / 100 - 0.5) * self.cur_action.vibration_x
            vy = (math_random(1, 100) / 100 - 0.5) * self.cur_action.vibration_y
        end
    end

    return vx, vy
end

function troop:Update(elapsed_time)
    for i = 1, self.role_num do
        self.roles[i]:Update(elapsed_time)
    end

    if not self.is_play_action then
        return
    end

    if self.remain_time > 0 then
        self.remain_time = math.max(0, self.remain_time - elapsed_time)
        self.action_duration = math.min(self.action_duration + elapsed_time, self.total_time)

        -- 颜色混合
        local duration_percent = self.action_duration / self.total_time
        local blend_mode = self.cur_action.blend_mode
        local r, g, b = 255, 255, 255

        if blend_mode == 2 then
            -- 缓慢变色
            if self.cur_action.init_color ~= 0 then
                r = math.max(self.init_r + (self.end_r - self.init_r) * duration_percent, 0)
                g = math.max(self.init_g + (self.end_g - self.init_g) * duration_percent, 0)
                b = math.max(self.init_b + (self.end_b - self.init_b) * duration_percent, 0)

            else
                r = self.end_r * duration_percent
                g = self.end_g * duration_percent
                b = self.end_b * duration_percent
            end

        elseif blend_mode == 1 then
            -- 立即变色
            r, g, b = self.end_r, self.end_g, self.end_b
        end

        -- 透明度
        local alpha = 1
        if self.cur_action.seq_action_id == 0 then
            alpha = 1 - (1 - self.cur_action.end_role_alpha) * self.action_duration / self.total_time

        elseif blend_mode ~= 0 then
            alpha =
                self.cur_action.init_role_alpha + (self.cur_action.end_role_alpha - self.cur_action.init_role_alpha) *
                    (blend_mode == 1 and 1 or self.action_duration / self.total_time)
        end

        -- 2dx 在存储透值时用的byte, 为了避免溢出，必须检测是否小于0
        if alpha < 0 then
            alpha = 0
        end

        -- 跳跃高度
        local jump_height = self:GetJumpHeight()
        local max_jump_height = self.cur_action.jump_height

        -- 更新位置
        if self.cur_action.move_direction == DIRECTION["center"] then
            -- 围绕中心移动
            local center_x, center_y = self.center_x, self.center_y
            local move_damping = self.cur_action.move_damping
            local random_angle = self.cur_action.random_angle

            for i = 1, self.role_num do
                local role = self.roles[i]
                local x, y = role:GetPosition()

                local sx = math.abs(x - center_x) / COL_GAP * move_damping
                local sy = math.abs(y - center_y) / ROW_GAP * move_damping

                sx = math.max(1 - sx, 0)
                sy = math.max(1 - sy, 0)

                local align = math.atan2(y - center_y, x - center_x)
                align = align + (math_random(1, 100) / 100 - 0.5) * random_angle / 180 * 3.1415926

                local ax = role.speed_x * elapsed_time * math.cos(align) * sx
                local ay = role.speed_y * elapsed_time * math.sin(align) * sy

                if self.id == RIGHT_TROOP_ID then
                    ax = -ax
                end

                local vx, vy = role:GetVibrationOffset()
                role:SetPositionEx(x + ax, y + ay, vx, vy + jump_height)

                -- 调整阴影大小和位置
                if max_jump_height > 0 then
                    local shadow_scale = 1 - (jump_height / max_jump_height * ROLE_SHADOW_SCALE)
                    role.shadow:setScaleX(shadow_scale)
                end
                role:SetShadowPosition(x + ax + vx, y + ay + vy - ROLE_SHADOW_OFFSET)

                if blend_mode ~= 0 then
                    role:SetOpacity(alpha)
                    role:SetColor(r, g, b)
                end
            end

        else
            for i = 1, self.role_num do
                local role = self.roles[i]
                local x, y = role:GetPosition()
                local vx, vy = role:GetVibrationOffset()

                x = x + role.speed_x * elapsed_time
                y = y + role.speed_y * elapsed_time

                role:SetPositionEx(x, y, vx, vy + jump_height)

                -- 调整阴影大小和位置
                if max_jump_height > 0 then
                    local shadow_scale = 1 - (jump_height / max_jump_height * ROLE_SHADOW_SCALE)
                    role.shadow:setScaleX(shadow_scale)
                end
                role:SetShadowPosition(x + vx, y + vy - ROLE_SHADOW_OFFSET)

                if blend_mode ~= 0 then
                    role:SetOpacity(alpha)
                    role:SetColor(r, g, b)
                end
            end
        end

    else
        if self.action_end_time > 0 then
            self.action_end_time = self.action_end_time - elapsed_time

        else
            -- 切换到下一个动作
            self:ChangeToSequentAction()

            if not self.cur_action then
                if not self.is_play_final_action then
                    -- 终结动作不需要重置颜色
                    for i = 1, self.role_num do
                        self.roles[i]:ResetColorAndOpacity()
                    end
                else

                end
                self.is_play_action = false
                self.is_play_final_action = false
            end
        end
    end
end

function troop:ResetColorAndOpacity()
    for i = 1, self.role_num do
        self.roles[i]:ResetColorAndOpacity()
    end
end

function troop:GetJumpHeight()
    local jump_type = self.cur_action.jump_type
    local jump_height = self.cur_action.jump_height
    local total_time = self.total_time
    if jump_type == 1 then
        -- 浮起
        return self.action_duration / total_time * jump_height

    elseif jump_type == 2 then
        -- 跳起降落
        if self.action_duration * 2 <= total_time then
            return 2 * self.action_duration / total_time * jump_height
        else
            return jump_height - (self.action_duration - total_time * 0.5) * 2 / total_time * jump_height
        end

    elseif jump_type == 3 then
        -- 降落
        return -(jump_height - jump_height / total_time * jump_height)
    end

    return 0
end

function troop:ChangeToSequentAction()
    if self.cur_action.seq_action_id == 0 then
        self.cur_action = nil
        return
    end

    local seq_action = config_manager.role_action[self.cur_action.seq_action_id]
    self:SetAction(seq_action)
end

function troop:PlayDeathAction()
    self.is_play_action = true
    self.is_play_final_action = true
    self:SetAction(config_manager.role_action[DEATH_ACTION])
end

function troop:PlayVictoryAction()
    self.is_play_action = true
    self.is_play_final_action = true
    self:SetAction(config_manager.role_action[VICTORY_ACTION])
end

function troop:IsPlayAction()
    return self.is_play_action
end

function troop:StartPlayAction(action)
    self.is_play_action = true
end

function troop:StopPlayAction()
    self.is_play_action = false

    for i = 1, self.role_num do
        self.roles[i]:WalkAnimation(1, WALK_ANIMATION_TIME)
    end
end

function troop:UseSkill(skill, is_dodge, buffer_id, buffer_id2, buffer_id3)

    local turn_fixed = 0

    self.enemy.damage_reduction_factor = skill.ignore_defense and 1.0 or (100 / (100 + self.enemy.defense))

    -- 主动技能，如果有清除Debuff的属性。就直接把自身的Debuff都取消掉。
    if skill and skill.clear_debuff and skill.clear_debuff == 1 then
        self.exhaust_turn = 0 -- 虚弱技能清除
        self.buffer_list = {} -- 所有BUFF进行清空
    end

    local effect_method = skill_manager:GetEffect(skill.effect_type)
    local real_skill = effect_method(self, self.enemy, skill, is_dodge)

    -- 需要考虑复制技能
    real_skill = real_skill or skill
    -- LOG(tostring(self),"使用技能:"..real_skill.name.."|"..real_skill.desc)
    -- 触发附加技能效果
    local trigger_addon_effect = true
    if real_skill.need_hit == 1 and is_dodge then
        trigger_addon_effect = false
    end

    if trigger_addon_effect then
        if real_skill.exhaust_turn > 0 then
            if self.enemy.clear_turn == nil or self.enemy.clear_turn <= 0 then
                self.enemy.exhaust_turn = math.max(self.enemy.exhaust_turn, real_skill.exhaust_turn)
            end
        end

        if real_skill.clear_turn and real_skill.clear_turn > 0 then
            -- 我方给自己加一个免疫buff，回合数量。只在对方回合减少
            self.clear_turn = math.max(self.clear_turn, real_skill.clear_turn)
        end

        -- 攻击吸收(吸收伤害并下一次进行释放)
        if real_skill.absorb_turn and real_skill.absorb_turn > 0 then
            self.absorb_turn = math.max(self.absorb_turn, real_skill.absorb_turn)
            self.absorb_value = real_skill.absorb_value
        end

        if real_skill.turn_fixed then
            turn_fixed = real_skill.turn_fixed
        end

        -- 敌方四维变化
        if #real_skill.enemy_property_map > 0 then
            local map = real_skill.enemy_property_map
            self.enemy.speed = self.enemy.speed + map[1]
            self.enemy.defense = self.enemy.defense + map[2]
            self.enemy.dodge = self.enemy.dodge + map[3]
            self.enemy.authority = self.enemy.authority + map[4]
        end

        -- 我方四维变化
        if #real_skill.self_property_map > 0 then
            local map = real_skill.self_property_map
            self.speed = self.speed + map[1]
            self.defense = self.defense + map[2]
            self.dodge = self.dodge + map[3]
            self.authority = self.authority + map[4]
        end

        self.enemy:CalcDamageFactor()
        self:CalcDamageFactor()
    end

    self.exhaust_turn = math.max(0, self.exhaust_turn - 1)
    self.enemy.clear_turn = math.max(0, self.enemy.clear_turn - 1)
    -- 敌方的吸收BUFF，是在敌方回合减少的
    self.enemy.absorb_turn = math.max(0, self.enemy.absorb_turn - 1)

    self.last_turn_skill = real_skill

    self.enemy.new_buffers = {}

    local function apply_buffer(id)
        if id and id > 0 then
            local buff_name = self:BuffTrigger(id)
            if type(buff_name) == "table" then
                for _, name in ipairs(buff_name) do
                    self.enemy.new_buffers[name] = true
                end
            elseif buff_name then
                self.enemy.new_buffers[buff_name] = true
            end
        end
    end
    apply_buffer(buffer_id)
    apply_buffer(buffer_id2)
    apply_buffer(buffer_id3)

    return turn_fixed
end

function troop:BuffTrigger(buffer_id)
    if buffer_id > 0 then
        local config = skill_buffer_config[buffer_id]
        if not config then
            return
        end
        local chance = config.chance
        if config.type == 1 then
            local buffer_list = self.enemy.buffer_list
            if self.enemy.clear_turn == nil or self.enemy.clear_turn <= 0 then
                if not buffer_list[config.name] then
                    buffer_list[config.name] = {}
                end

                table.insert(buffer_list[config.name], {
                    factor = config.factor,
                    turn_times = config.turn_times
                })
            end
        elseif config.type == 3 then
            -- 复合负面：一次附加全部对敌负面（电磁炮EX）
            -- [FIX] 改为走标准 buff 配置（19 流血15%/2、27 中毒22%/2、
            -- 24 虚弱30%/3、13 重伤50%/2、30 痛苦30%），
            -- 这样系数同样是 0.xx，和普通技能的 debuff 完全一致。
            local buffer_list = self.enemy.buffer_list
            if self.enemy.clear_turn == nil or self.enemy.clear_turn <= 0 then
                local ids = { 19, 27, 24, 13, 30 }
                local names = {}
                for _, id in ipairs(ids) do
                    local c = skill_buffer_config[id]
                    if c then
                        if not buffer_list[c.name] then
                            buffer_list[c.name] = {}
                        end
                        table.insert(buffer_list[c.name], {
                            factor = c.factor,
                            turn_times = c.turn_times
                        })
                        names[#names + 1] = c.name
                    end
                end
                return names
            end
        elseif config.type == 0 then
            local buffer_list = self.buffer_list
            if not buffer_list[config.name] then
                buffer_list[config.name] = {}
            end
            table.insert(buffer_list[config.name], {
                factor = config.factor,
                turn_times = config.turn_times
            })
        end
        -- LOG(tostring(self),"附加BUFF:"..config.name.."|"..config.desc)
        return config.name
    end
    return
end

-- 回合次数减1
function troop:BuffTimesProcess()
    for name, buffers in pairs(self.buffer_list) do
        for i = #buffers, 1, -1 do
            -- 回合次数-1
            buffers[i].turn_times = buffers[i].turn_times - 1
            if buffers[i].turn_times <= 0 then
                table.remove(buffers, i)
            end
        end
    end
end

function troop:ClearBufState()
    self.bleed_damage = nil
    self.last_bleed_bp = nil
    self.last_bleed_shield_bp = nil
    self.pre_poison_bp = nil
    self.pre_poison_shield_bp = nil
    self.poison_damage = nil
    self.last_poison_bp = nil
    self.last_poison_shield_bp = nil
end

-- 获取buffer叠加的系数和
function troop:CaculateFactor(name)
    local factor = 0
    -- 定制 buff 的 name 是唯一的，但结算按基础类型汇总
    for key, buffers in pairs(self.buffer_list) do
        if BaseBuffName(key) == name then
            for _, data in ipairs(buffers) do
                if data.turn_times > 0 then
                    factor = factor + data.factor
                end
            end
        end
    end
    return factor
end
-- 虚弱处理  削弱伤害效果
function troop:BuffWeak(damage)
    local factor = math.min(1, self:CaculateFactor("weak"))
    local del_damage = math_ceil(damage * factor)
    local new_damage = damage - del_damage
    if factor > 0 then
        -- LOG(tostring(self),"触发虚弱效果=>".."削弱前伤害效果:"..damage.."|削弱值(damage):"..del_damage.."|削弱后伤害效果:"..new_damage)
    end
    return new_damage
end
-- 重伤处理 削弱回血效果
function troop:BuffSeriouslyInjured(reply)
    local factor = math.min(1, self:CaculateFactor("seriously_injured"))
    local del_reply = math_ceil(reply * factor)
    local new_reply = reply - del_reply
    if factor > 0 then
        -- LOG(tostring(self),"触发重伤效果=>".."削弱前回复效果:"..reply.."|削弱值(reply):"..del_reply.."|削弱后回复效果:"..new_reply)
    end
    return new_reply
end

-- 痛苦效果 治疗转伤害效果
function troop:BuffPain(reply)
    local buffers = self.buffer_list["pain"]
    if not buffers or #buffers <= 0 then
        return reply, 0
    end
    local factor = self:CaculateFactor("pain")
    if factor <= 0 or reply <= 0 then
        return reply, 0
    end
    local del_reply = math_ceil(reply * factor)
    -- [FIX] 描述是“触发后消失”：消耗掉痛苦层数，按标准 buff 生命周期处理。
    self.buffer_list["pain"] = {}
    return reply - del_reply, del_reply
end

-- 流血处理 掉血效果
function troop:BuffBleed()
    local factor = self:CaculateFactor("bleed")
    local damage = math_ceil(self.cur_bp * factor)
    local pre_bp = self.cur_bp
    -- 伤害处理
    self:CalcDamageBp(damage)

    if damage > 0 then
        -- LOG(tostring(self),"触发流血效果=>".."流血前战力:"..pre_bp.."|伤害值(damage):"..damage.."|流血后战力:"..self.cur_bp)
    end

    self.bleed_damage = self.cur_bp - pre_bp
    self.last_bleed_bp = self.cur_bp
    self.last_bleed_shield_bp = self.cur_shield_bp
end
-- 中毒处理  
function troop:BuffPoison()
    local factor = self:CaculateFactor("poison")
    local damage = math_ceil(self.max_bp * factor)
    local pre_bp = self.cur_bp
    local pre_shield_bp = self.cur_shield_bp
    -- 伤害处理
    self:CalcDamageBp(damage)
    if damage > 0 then
        -- LOG(tostring(self),"触发中毒效果=>".."中毒前战力:"..pre_bp.."|伤害值(damage):"..damage.."|中毒后战力:"..self.cur_bp)
    end
    self.pre_poison_bp = pre_bp
    self.pre_poison_shield_bp = pre_shield_bp
    self.poison_damage = self.cur_bp - pre_bp
    self.last_poison_bp = self.cur_bp
    self.last_poison_shield_bp = self.cur_shield_bp
end

function troop:CalcDamageBp(damage)
    if self.cur_shield_bp > 0 then
        if self.cur_shield_bp > damage then
            self.cur_shield_bp = self.cur_shield_bp - damage
            damage = 0
        else
            damage = damage - self.cur_shield_bp
            self.cur_shield_bp = 0
        end
    end

    self.cur_bp = self.cur_bp - damage
    -- 如果当前被施法方战力等于或低于0 同时存在抵御致死攻击的效果
    if self.cur_bp <= 0 and self.resist_lethal_num and self.resist_lethal_num > 0 then
        -- LOG(tostring(self),"触发抵御致死,当前血量变为1")
        self.resist_lethal_num = self.resist_lethal_num - 1
        self.cur_bp = 1
        self.is_resist_lethal = true
        self.resist_lethal_damage = self.cur_bp
    end
end

-- 回合之前的buffer前置掉血处理（同一基础类型只结算一次，避免定制 buff 多 key 重复扣血）
function troop:BuffProcessPre()
    local has_bleed = false
    for name, data in pairs(self.buffer_list) do
        if BaseBuffName(name) == "bleed" then
            for _, v in ipairs(data) do
                if v.turn_times and v.turn_times > 0 then
                    has_bleed = true
                    break
                end
            end
        end
        if has_bleed then
            break
        end
    end
    if has_bleed then
        self:BuffBleed()
    end
end

-- 回合之后的buffer掉血处理
function troop:BuffProcessLast()
    local has_poison = false
    for name, data in pairs(self.buffer_list) do
        if BaseBuffName(name) == "poison" then
            for _, v in ipairs(data) do
                if v.turn_times and v.turn_times > 0 then
                    has_poison = true
                    break
                end
            end
        end
        if has_poison then
            break
        end
    end
    if has_poison then
        self:BuffPoison()
    end
end

return troop
