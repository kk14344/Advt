local config_manager = require "logic.config_manager"
local network = require "util.network"
local graphic = require "logic.graphic"
local vip_logic = require "logic.vip"
local resource_recycle_logic = require "logic.resource_recycle"
local constants = require "util.constants"

local RESOURCE_TYPE = constants.RESOURCE_TYPE

local time_logic
local user_logic
local troop_logic
local resource_logic
local mining_logic

local bag = {}
function bag:Init()
    user_logic = require "logic.user"
    troop_logic = require "logic.troop"
    time_logic = require "logic.time"
    resource_logic = require "logic.resource"
    vip_logic = require "logic.vip"
    mining_logic = require "logic.mining"

    self.level = 1
    self.item_list = {}
    self.capacity = 1

    self.item_id_generator = 0
    self.batch_open_active = false
    self.batch_queue = {}
    self.batch_summary = nil
    self.batch_stop_reason = nil
    self.item_not_list = {}
    self.item_not_list[10000031] = 1
    self.item_not_list[10000032] = 1
    self.item_not_list[10000047] = 1
    self.item_not_list[10000052] = 1
    self.item_not_list[10000059] = 1

    -- [PC PORT] Bag items are client-side; persist them so restarting does
    -- not empty the bag.
    self:LoadPersistent()

    self:RegisterMsgHandler()
end

function bag:LoadPersistent()
    local user_data = require "util.user_data"
    -- [PC PORT] bag contents follow the logged-in account.
    self.save_data = user_data:new(nil, "bag_save_local")
    local saved = self.save_data:getKeyValue("bag")
    if type(saved) ~= "table" or type(saved.items) ~= "table" then
        return
    end
    for _, item in ipairs(saved.items) do
        local template_id = tonumber(item.template_id)
        local template_info = config_manager.item_config[template_id]
        if template_info then
            local item_id = tonumber(item.item_id) or 0
            table.insert(self.item_list, {
                item_id = item_id,
                template_id = template_id,
                template_info = template_info,
                create_time = tonumber(item.create_time) or 0,
                num = tonumber(item.num) or 1,
                is_new = false,
            })
            self.item_id_generator = math.max(self.item_id_generator, item_id)
        end
    end
    local saved_generator = tonumber(saved.item_id_generator)
    if saved_generator then
        self.item_id_generator = math.max(self.item_id_generator, saved_generator)
    end
end

function bag:SavePersistent()
    if not self.save_data then
        return
    end
    local items = {}
    for _, item in ipairs(self.item_list) do
        items[#items + 1] = {
            item_id = item.item_id,
            template_id = item.template_id,
            create_time = item.create_time,
            num = item.num or 1,
        }
    end
    self.save_data:setKeyValue("bag", {
        items = items,
        item_id_generator = self.item_id_generator,
    })
end

function bag:GetItemList()
    return self.item_list
end

function bag:GetItemInfo(item_id)
    for i, item in ipairs(self.item_list) do
        if item.item_id == item_id then
            return item
        end
    end
end

function bag:GetItemCount(template_id)
    local count = 0
    for i, item in ipairs(self.item_list) do
        if item.template_id == template_id then
            count = count + 1
        end
    end
    return count
end

function bag:GetCapacity()
    return self.capacity, self.level
end

-- 获取代金券，根据金钱
function bag:GetItemCashTickets(price)
    for i, item in ipairs(self.item_list) do
        local rule_type = item.template_info.rule_type
        if rule_type == constants.ITEM_RULE.cash_tickets then -- 代金券不能正常使用
            -- print("----->", rule_type)
            if tonumber(price) == tonumber(item.template_info.param_1) then
                return item
            end
        end
    end
end
-- 获取包裹中空白的位置
function bag:GetSpaceCount()
    return self.capacity - #self.item_list
end

function bag:ResetItemFlag()
    for i, item in ipairs(self.item_list) do
        item.is_new = false
    end
end

-- [PC PORT] 英雄礼包统一交给服务端开启：服务端会同时在 troop_save 里建立
-- 对应佣兵记录，并让客户端按同一 instance_id 创建佣兵。若像以前那样在
-- 客户端本地直接 CreateMercenary，服务端名单里没有该佣兵，上阵时就会返回
-- “有特殊佣兵，不能该操作”。

-- 使用道具
function bag:UseItem(item_id, golem_lv)
    self.quick_use_item = false

    local found = false
    local cur_item
    local cur_index = 0
    for i, item in ipairs(self.item_list) do
        if item.item_id == item_id then
            found = true
            cur_item = item
            cur_index = i
            break
        end
    end

    if not found then
        graphic:DispatchEvent("show_prompt_panel", "bag_item_not_exist")
        return
    end

    if cur_item.template_info.rule_type == constants.ITEM_RULE["hero_biography"] and not troop_logic:CheckMercenaryNum() then
        return

    elseif cur_item.template_info.rule_type == constants.ITEM_RULE["refresh_mining"] and
        not mining_logic:CheckRefreshArea(golem_lv, true) then
        return
    end

    -- [MOD] 嗜血印记：全队被动（造成伤害 30% 回血），不可叠加
    if cur_item.template_id == 16000081 then
        local team_buff = require "logic.team_buff"
        if not team_buff:ApplyLifesteal(30) then
            graphic:DispatchEvent("show_prompt_panel", "已拥有嗜血效果，不可叠加")
            return
        end
        table.remove(self.item_list, cur_index)
        self:SavePersistent()
        graphic:DispatchEvent("update_bag")
        if _G["BOOT_TRACE"] then _G["BOOT_TRACE"]("lifesteal item used") end
        return
    end

        -- [MOD] 四维精魄交给服务端处理：给主角 +1 四维（服务端权威，属性面板可见）

    -- [MOD] 神之馈赠：四维各 +10000、战力 +100000000，纯本地生效并持久化
    if cur_item.template_id == 16000080 then
        local divine = require "logic.divine_boost"
        divine:Apply()
        local gift_count = tonumber(cur_item.num) or 1
        if gift_count > 1 then
            cur_item.num = gift_count - 1
        else
            table.remove(self.item_list, cur_index)
        end
        self:SavePersistent()
        graphic:DispatchEvent("update_bag")
        graphic:DispatchEvent("bag_is_full")
        if _G["BOOT_TRACE"] then _G["BOOT_TRACE"]("divine item used") end
        return
    end

    -- [PC PORT] The server has no bag mirror (items are client-side), so the
    -- optional golem_lv field carries the item template id; 刷新矿区 does not
    -- need the golem level server-side (it keeps the current level).
    network:Send({
        use_item = {
            item_id = tonumber(item_id) or 0,
            golem_lv = tonumber(cur_item.template_id) or 0
        }
    })
end

local upgrade_params = {"copper", "iron", "silver", "tin", "gold", "diamond", "ruby", "purple_gem", "emerald", "topaz"}

-- 升级背包
function bag:UpgradeBag()
    local config = config_manager.bag_info_config[self.level]

    if not config then
        return
    end

    -- 检测资源是否充足
    for i = 1, #upgrade_params do
        local num = config[upgrade_params[i]]
        local resource_type = RESOURCE_TYPE[upgrade_params[i]]

        if num > 0 and not resource_logic:CheckResourceNum(resource_type, num, true) then
            return
        end
    end

    network:Send({
        upgrade_bag = {}
    })
end


-- 可叠加道具：同模板只占一个格子，按 num 堆叠
local STACKABLE_ITEM_IDS = {
    [16000079] = true, -- 四维精魄
    [16000080] = true, -- 神之馈赠
}

-- 包装不下的物品先应该进背包。这里不做任何客户端本地数据，
-- 只把因客户端背包已满而装入失败的道具/资源名上报，服务端
-- challenge_battlefront_boss 的 report 字段（5 位）为标记。
local mail_overflow = {}

function bag:NewItem(template_id)
    if #self.item_list >= self.capacity then
        return false
    end

    if STACKABLE_ITEM_IDS[template_id] then
        for _, exist in ipairs(self.item_list) do
            if exist.template_id == template_id then
                exist.num = (tonumber(exist.num) or 1) + 1
                if _G["BOOT_TRACE"] then
                    _G["BOOT_TRACE"](string.format("bag stack add %d -> %d", template_id, exist.num))
                end
                self:SavePersistent()
                graphic:DispatchEvent("bag_is_full")
                return true
            end
        end
    end

    local item = {}
    self.item_id_generator = self.item_id_generator + 1
    item.item_id = self.item_id_generator
    item.template_id = template_id
    item.template_info = config_manager.item_config[template_id]
    item.create_time = time_logic:Now()
    item.num = 1

    table.insert(self.item_list, item)
    self:SavePersistent()
    if _G["BOOT_TRACE"] and STACKABLE_ITEM_IDS[template_id] then
        _G["BOOT_TRACE"](string.format("bag stack new %d", template_id))
    end
    -- 背包是否满了提醒
    graphic:DispatchEvent("bag_is_full")
    return true
end

-- 加物品；放不下的部分记下来，稍后统一转成邮件。
function bag:NewItemOrMail(template_id, count)
    template_id = tonumber(template_id) or 0
    count = math.max(0, math.floor(tonumber(count) or 0))
    local cfg = config_manager.item_config[template_id]
    local auto_consume = (template_id == 14000001) or (cfg and cfg.rule_type == constants.ITEM_RULE.cash_tickets)
    for i = 1, count do
        if not self:NewItem(template_id) then
            mail_overflow[template_id] = (mail_overflow[template_id] or 0) + 1
        elseif auto_consume then
            -- [MOD] 兜底：若抵扣券或出阵+1 经客户端直写路径（如每日签到）进入背包，立刻自动触发服务端使用
            local added = self.item_list[#self.item_list]
            if added and added.template_id == template_id then
                self:UseItem(added.item_id)
            end
        end
    end
end

function bag:FlushOverflowMail()
    if not next(mail_overflow) then
        return
    end
    local overflow = mail_overflow
    mail_overflow = {}
    for template_id, count in pairs(overflow) do
        network:Send({
            challenge_battlefront_boss = {
                boss_id = 500000000 + template_id,
                actual_winner = count,
                is_report = 1,
            }
        })
    end
end

function bag:RegisterMsgHandler()
    network:RegisterEvent("query_bag_info_ret", function(recv_msg)
        print("query_bag_info_ret")
        self.level = recv_msg.level
        self.capacity = recv_msg.max_count

        local item_config = config_manager.item_config

        if recv_msg.item_list then
            for i, item in ipairs(recv_msg.item_list) do
                -- 过滤非法的item
                if item_config[item.template_id] then
                    item.template_info = item_config[item.template_id]
                    item.is_new = false
                    table.insert(self.item_list, item)
                end
            end
        end

        -- Keep the local generator ahead of server-provided ids and saved ids;
        -- otherwise a restart could reuse ids and collide with saved items.
        self.item_id_generator = math.max(
            self.item_id_generator or 0,
            tonumber(recv_msg.item_id_generator) or 0
        )
        self:SavePersistent()

        -- 背包是否满了提醒
        graphic:DispatchEvent("bag_is_full")
    end)

    network:RegisterEvent("use_item_ret", function(recv_msg)
        -- [MOD] 竞技场战力倍率区间同步回包（item_id == -3），不走背包扣除逻辑
        local rid_num = tonumber(recv_msg.item_id) or 0
        if rid_num == -3 then
            local arena_logic = require "logic.arena"
            if arena_logic and arena_logic.OnServerBpRangeSync then
                arena_logic:OnServerBpRangeSync(recv_msg.extra_num)
            end
            return
        end
        -- [MOD r10.3] 心愿祈愿池专用回包（item_id <= -200），不走背包扣除逻辑
        if rid_num <= -200 and rid_num >= -209 then
            if recv_msg.result == "not_enough_mercenary_space" or recv_msg.result == 6 or recv_msg.result == "6" then
                pcall(function()
                    local pixel_kit = require "ui.pixel_kit"
                    pixel_kit:ShowToast("佣兵营地空间不足，请先扩充营地或解雇多余佣兵", 0xf87f26)
                end)
            end
            return
        end
        -- [MOD] 兼容服务端枚举以数字返回的情况（0 = success, 5 = event_take）
        if _G["BOOT_TRACE"] then
            _G["BOOT_TRACE"]("use_item_ret result=" .. tostring(recv_msg.result) .. " item=" .. tostring(recv_msg.item_id))
        end
        local result_ok = (recv_msg.result == "success" or recv_msg.result == 0) or recv_msg.result == 0 or recv_msg.result == "0"
        local result_event = recv_msg.result == "event_take" or recv_msg.result == 5 or recv_msg.result == "5"
        if result_ok or result_event then
            local item_index = 0
            local template_info

            for i, item in ipairs(self.item_list) do
                if item.item_id == recv_msg.item_id then
                    item_index = i
                    template_info = item.template_info
                    break
                end
            end

            if item_index ~= 0 then
                local use_item = self.item_list[item_index]
                local stack = tonumber(use_item.num) or 1
                if stack > 1 then
                    use_item.num = stack - 1
                else
                    table.remove(self.item_list, item_index)
                end
            end
            self:SavePersistent()

            if template_info then
                if template_info.rule_type == constants.ITEM_RULE["vip"] then
                    vip_logic:ActivateAdventurer(template_info.roll_count * 86400)
                end
            end
            if result_ok then
                local extra_n = tonumber(recv_msg.extra_num) or 0
                local is_form_cap_discard = template_info and template_info.ID == 14000001 and extra_n >= 900000
                if self.batch_open_active and self.batch_summary then
                    self.batch_summary.opened_count = (self.batch_summary.opened_count or 0) + 1
                    if is_form_cap_discard then
                        self.batch_summary.formation_discarded = (self.batch_summary.formation_discarded or 0) + 1
                    end
                    -- 兼容四维精魄 (16000079)：通过 extra_num 记录提升类型 (1先攻/2防御/3闪避/4王者)
                    if template_info and template_info.ID == 16000079 then
                        local stat_type = extra_n
                        if stat_type >= 1 and stat_type <= 4 then
                            self.batch_summary.four_dim[stat_type] = (self.batch_summary.four_dim[stat_type] or 0) + 1
                        end
                    end
                else
                    if is_form_cap_discard then
                        if reward_logic and reward_logic.ResetRewardInfoList then
                            reward_logic:ResetRewardInfoList()
                        end
                        pcall(function()
                            local pixel_kit = require "ui.pixel_kit"
                            local cap = extra_n - 900000
                            pixel_kit:ShowToast(string.format("出战人数已达上限（%d人），该道具已自动销毁", cap), 0xf3a833)
                        end)
                    end
                    graphic:DispatchEvent("use_item_which_in_bag", recv_msg.item_id, recv_msg.extra_num, template_info)
                    -- 背包是否满了提醒
                    graphic:DispatchEvent("bag_is_full")
                end
            elseif result_event and self.batch_open_active and self.batch_summary then
                self.batch_summary.opened_count = (self.batch_summary.opened_count or 0) + 1
            end

            if recv_msg.extra_num then
                resource_recycle_logic.temperature = recv_msg.extra_num
            end

            if self.batch_open_active then
                self:DispatchNextBatchItem()
            elseif self.quick_use_item == true then
                self:QuickUseItem()
            end

        elseif recv_msg.result == "daily_limit" then
            if (recv_msg and recv_msg.item_id) then
                self.item_not_list[tonumber(recv_msg.item_id)] = 1
            end
            if self.batch_open_active then
                if self.batch_is_use_all then
                    self:SkipBatchTemplateByItemId(recv_msg.item_id)
                    self:DispatchNextBatchItem()
                else
                    self.batch_stop_reason = "已达今日使用上限，提前结束"
                    self:FinishBatchOpen()
                end
            else
                graphic:DispatchEvent("show_prompt_panel", "bag_use_item_dayly_limit")
            end
        elseif recv_msg.result == "item_not_found" then
            if self.batch_open_active then
                self:DispatchNextBatchItem()
            else
                graphic:DispatchEvent("show_prompt_panel", "bag_item_not_exist")
            end

        elseif recv_msg.result == "not_enough_mercenary_space" then
            if self.batch_open_active then
                self.batch_stop_reason = string.format("佣兵营帐已满（上限 %d），提前结束", troop_logic:GetCampCapacity())
                self:FinishBatchOpen()
            else
                graphic:DispatchEvent("show_prompt_panel", "troop_not_enough_mercenary_space", troop_logic:GetCampCapacity())
            end

        elseif recv_msg.result == "mining_time_limit" then
            if self.batch_open_active then
                if self.batch_is_use_all then
                    self:SkipBatchTemplateByItemId(recv_msg.item_id)
                    self:DispatchNextBatchItem()
                else
                    self.batch_stop_reason = "矿区正在挖掘中，无法继续使用"
                    self:FinishBatchOpen()
                end
            else
                graphic:DispatchEvent("show_prompt_panel", "mining_is_digging")
            end

        elseif recv_msg.result == "mining_collect_first" then
            if self.batch_open_active then
                if self.batch_is_use_all then
                    self:SkipBatchTemplateByItemId(recv_msg.item_id)
                    self:DispatchNextBatchItem()
                else
                    self.batch_stop_reason = "请先收取矿区资源"
                    self:FinishBatchOpen()
                end
            else
                graphic:DispatchEvent("show_prompt_panel", "mining_collect_resource_first")
            end

        elseif recv_msg.result == "temple_today_cant_recruit" then
            if self.batch_open_active then
                if self.batch_is_use_all then
                    self:SkipBatchTemplateByItemId(recv_msg.item_id)
                    self:DispatchNextBatchItem()
                else
                    self.batch_stop_reason = "神殿今日无法继续招募"
                    self:FinishBatchOpen()
                end
            else
                graphic:DispatchEvent("show_prompt_panel", "temple_not_enough_recruit_count")
            end

        elseif recv_msg.result == "mining_not_enough_golem_lv" then
            if self.batch_open_active then
                if self.batch_is_use_all then
                    self:SkipBatchTemplateByItemId(recv_msg.item_id)
                    self:DispatchNextBatchItem()
                else
                    self.batch_stop_reason = "魔像等级不足"
                    self:FinishBatchOpen()
                end
            else
                graphic:DispatchEvent("show_prompt_panel", "mining_not_enough_golem_lv")
            end

        elseif recv_msg.result == "reach_max_level" or recv_msg.result == 2 then
            if self.batch_open_active then
                if self.batch_is_use_all then
                    self:SkipBatchTemplateByItemId(recv_msg.item_id)
                    self:DispatchNextBatchItem()
                else
                    self.batch_stop_reason = "出战上限已达最高等级"
                    self:FinishBatchOpen()
                end
            else
                graphic:DispatchEvent("show_prompt_panel", "formation_capacity_reach_max")
            end
        else
            if self.batch_open_active then
                if self.batch_is_use_all then
                    self:SkipBatchTemplateByItemId(recv_msg.item_id)
                    self:DispatchNextBatchItem()
                else
                    self.batch_stop_reason = tostring(recv_msg.result or "使用中断")
                    self:FinishBatchOpen()
                end
            else
                graphic:DispatchEvent("show_prompt_panel", recv_msg.result)
            end
        end

    end)

    network:RegisterEvent("upgrade_bag_ret", function(recv_msg)
        if (recv_msg.result == "success" or recv_msg.result == 0) then
            local old_level = self.level
            local old_config = config_manager.bag_info_config[old_level]
            self.level = recv_msg.new_level

            local config = config_manager.bag_info_config[self.level]
            if config then
                self.capacity = config.capacity
            end

            -- [PC PORT] 升级消耗由客户端钱包扣除（bag_info.csv 当前等级行的
            -- 铜/锡/铁/银/黄金/钻石/宝石需求）。
            if old_config then
                local updated = false
                for i = 1, #upgrade_params do
                    local name = upgrade_params[i]
                    local num = tonumber(old_config[name]) or 0
                    local resource_id = RESOURCE_TYPE[name]
                    if num > 0 and resource_id then
                        resource_logic:UpdateResource(resource_id, -num)
                        updated = true
                    end
                end
                if updated then
                    graphic:DispatchEvent("update_resource_list")
                    resource_logic:ClearDirtyFlags()
                end
            end

            graphic:DispatchEvent("show_prompt_panel", "bag_upgrade_success")
            graphic:DispatchEvent("update_bag")
            -- 背包是否满了提醒
            graphic:DispatchEvent("bag_is_full")

        elseif recv_msg.result == "not_enough_resource" then

        elseif recv_msg.result == "reach_max_level" then
            graphic:DispatchEvent("show_prompt_panel", "bag_already_max_level")
        end
    end)
end

local NON_BATCHABLE_TEMPLATE_IDS = {
    [10000031] = true, -- 矿区刷新
    [10000032] = true, -- 天空神像
    [16000081] = true, -- 嗜血印记（不可叠加）
}

function bag:CollectBatchRewards(reward_info_list)
    if not self.batch_open_active or not self.batch_summary or type(reward_info_list) ~= "table" then
        return
    end
    local REWARD_TYPE = constants.REWARD_TYPE
    local summary = self.batch_summary
    local merc_cfg = config_manager.mercenary_config or {}
    for _, reward_info in ipairs(reward_info_list) do
        local rtype = reward_info.id or reward_info.reward_type
        if rtype == REWARD_TYPE["mercenary"] then
            local tid = tonumber(reward_info.param1) or 0
            if tid > 0 then
                local entry = summary.mercenaries[tid]
                if not entry then
                    local conf = merc_cfg[tid] or {}
                    entry = {
                        template_id = tid,
                        name = conf.name or ("佣兵#" .. tostring(tid)),
                        quality = tonumber(conf.quality) or 1,
                        sprite = conf.sprite or tostring(tid),
                        count = 0,
                        is_new = false,
                    }
                    summary.mercenaries[tid] = entry
                end
                entry.count = entry.count + 1
                if reward_info.is_new then
                    entry.is_new = true
                end
            end
        elseif rtype == REWARD_TYPE["resource"] then
            local rid = tonumber(reward_info.param1) or 0
            local num = tonumber(reward_info.param2) or 0
            if rid > 0 and num > 0 then
                summary.resources[rid] = (summary.resources[rid] or 0) + num
            end
        elseif rtype == REWARD_TYPE["item"] then
            local iid = tonumber(reward_info.param1) or 0
            local num = math.max(1, tonumber(reward_info.param2) or 1)
            if iid > 0 then
                summary.items[iid] = (summary.items[iid] or 0) + num
            end
        elseif rtype == REWARD_TYPE["soul_stone"] then
            local sid = tonumber(reward_info.param1) or 0
            local num = math.max(1, tonumber(reward_info.param2) or 1)
            if sid > 0 then
                summary.soul_stones[sid] = (summary.soul_stones[sid] or 0) + num
            end
        elseif rtype == REWARD_TYPE["leader_bp"] then
            summary.leader_bp = (summary.leader_bp or 0) + (tonumber(reward_info.param1) or 0)
        elseif rtype == REWARD_TYPE["pickaxe_count"] then
            summary.pickaxe_count = (summary.pickaxe_count or 0) + (tonumber(reward_info.param1) or 0)
        elseif rtype == REWARD_TYPE["camp_capacity"] then
            summary.camp_capacity = (summary.camp_capacity or 0) + (tonumber(reward_info.param1) or 0)
        elseif rtype == REWARD_TYPE["formation_capacity"] or rtype == 12 then
            local cap = tonumber(reward_info.param1) or 0
            local disc = tonumber(reward_info.param2) or 0
            if disc > 0 then
                summary.formation_discarded = (summary.formation_discarded or 0) + disc
            elseif cap > (summary.formation_capacity or 0) then
                summary.formation_capacity = cap
            end
        end
    end
end

function bag:SkipBatchTemplateByItemId(item_id)
    local target = self:GetItemInfo(item_id)
    local skip_tid = target and target.template_id or nil
    if not skip_tid then
        return
    end
    local kept = {}
    for _, entry in ipairs(self.batch_queue or {}) do
        if entry.template_id ~= skip_tid then
            kept[#kept + 1] = entry
        end
    end
    self.batch_queue = kept
end

function bag:FinishBatchOpen()
    local summary = self.batch_summary
    local stop_reason = self.batch_stop_reason
    self.batch_open_active = false
    self.batch_is_use_all = false
    self.batch_queue = {}
    self.batch_summary = nil
    self.batch_stop_reason = nil
    self.quick_use_item = false

    graphic:DispatchEvent("update_bag")
    graphic:DispatchEvent("bag_is_full")

    if summary and (summary.opened_count or 0) > 0 then
        graphic:DispatchEvent("bag_batch_open_done", summary, stop_reason)
    elseif stop_reason then
        graphic:DispatchEvent("show_prompt_panel", stop_reason)
    end
end

function bag:DispatchNextBatchItem()
    if not self.batch_open_active then
        return
    end
    while #self.batch_queue > 0 do
        local next_entry = table.remove(self.batch_queue, 1)
        local cur_item = self:GetItemInfo(next_entry.item_id)
        if cur_item then
            if cur_item.template_info and cur_item.template_info.rule_type == constants.ITEM_RULE["hero_biography"]
                and not troop_logic:CheckMercenaryNum() then
                self.batch_stop_reason = string.format("佣兵营帐已满（上限 %d），提前结束", troop_logic:GetCampCapacity())
                self:FinishBatchOpen()
                return
            end
            network:Send({
                use_item = {
                    item_id = cur_item.item_id,
                    golem_lv = cur_item.template_id
                }
            })
            return
        end
    end
    self:FinishBatchOpen()
end

function bag:QuickUseItem(item_id)
    if #self.item_list <= 0 then
        return false
    end
    if self.batch_open_active then
        return false
    end

    local target, target_index
    if item_id then
        for i, item in ipairs(self.item_list) do
            if item.item_id == item_id then
                target, target_index = item, i
                break
            end
        end
    end
    if not target then
        target_index = #self.item_list
        target = self.item_list[target_index]
    end
    if not target then
        return false
    end

    local template_id = target.template_id
    local rule_type = target.template_info and target.template_info.rule_type
    if NON_BATCHABLE_TEMPLATE_IDS[template_id]
        or rule_type == constants.ITEM_RULE["refresh_mining"]
        or rule_type == constants.ITEM_RULE["refresh_temple"]
        or rule_type == constants.ITEM_RULE["vip"]
        or rule_type == constants.ITEM_RULE["recycle_coolant"] then
        self.quick_use_item = false
        graphic:DispatchEvent("show_prompt_panel", "该道具不支持一键批量开启，请单个使用")
        return false
    end

    -- 神之馈赠：一键使用整叠并走统一结算展示
    if template_id == 16000080 then
        local count = math.max(0, tonumber(target.num) or 1)
        local divine = require "logic.divine_boost"
        for _ = 1, count do
            divine:Apply()
        end
        table.remove(self.item_list, target_index)
        self:SavePersistent()
        graphic:DispatchEvent("update_bag")
        graphic:DispatchEvent("bag_is_full")
        graphic:DispatchEvent("bag_batch_open_done", {
            template_id = template_id,
            template_name = target.template_info and target.template_info.name or "神之馈赠",
            opened_count = count,
            mercenaries = {},
            resources = {},
            items = {},
            soul_stones = {},
            leader_bp = count * 100000000,
            pickaxe_count = 0,
            camp_capacity = 0,
            four_dim = { count * 10000, count * 10000, count * 10000, count * 10000 },
        }, nil)
        return true
    end

    -- 收集同模板全部可批量开启道具（含堆叠道具数量）
    local queue = {}
    for _, item in ipairs(self.item_list) do
        if item.template_id == template_id and self.item_not_list[tonumber(item.item_id)] == nil then
            local stack = math.max(1, tonumber(item.num) or 1)
            for _ = 1, stack do
                queue[#queue + 1] = { item_id = item.item_id, template_id = template_id }
            end
        end
    end

    if #queue == 0 then
        return false
    end
    if #queue == 1 then
        -- 仅 1 个时保留原有单个开启演出
        self:UseItem(queue[1].item_id)
        return true
    end

    self.batch_open_active = true
    self.batch_is_use_all = false
    self.batch_queue = queue
    self.batch_stop_reason = nil
    self.batch_summary = {
        template_id = template_id,
        template_name = target.template_info and target.template_info.name or "道具",
        opened_count = 0,
        mercenaries = {},
        resources = {},
        items = {},
        soul_stones = {},
        leader_bp = 0,
        pickaxe_count = 0,
        camp_capacity = 0,
        formation_capacity = 0,
        formation_discarded = 0,
        four_dim = { 0, 0, 0, 0 },
    }
    self:DispatchNextBatchItem()
    return true
end

function bag:IsItemAutoUsable(item)
    if not item or not item.template_info then
        return false
    end
    local tid = tonumber(item.template_id) or 0
    if NON_BATCHABLE_TEMPLATE_IDS[tid] or self.item_not_list[tonumber(item.item_id)] ~= nil then
        return false
    end
    local rule_type = item.template_info.rule_type
    if rule_type == constants.ITEM_RULE["refresh_mining"]
        or rule_type == constants.ITEM_RULE["refresh_temple"]
        or rule_type == constants.ITEM_RULE["vip"]
        or rule_type == constants.ITEM_RULE["recycle_coolant"] then
        return false
    end
    return true
end

function bag:CountAllUsableItems()
    local total = 0
    for _, item in ipairs(self.item_list) do
        if self:IsItemAutoUsable(item) then
            total = total + math.max(1, tonumber(item.num) or 1)
        end
    end
    return total
end

-- [MOD] 道具背包「全部使用」：一次性开启背包内全部可自动使用的不同品类道具，
-- 先开非佣兵类（抵扣券/出阵+1/资源包/营帐扩容等），再开佣兵包，最后弹出统一汇总结算弹窗。
function bag:UseAllItems()
    if self.batch_open_active then
        return false
    end
    local summary = {
        is_use_all = true,
        template_id = 0,
        template_name = "全部可用道具",
        opened_count = 0,
        mercenaries = {},
        resources = {},
        items = {},
        soul_stones = {},
        leader_bp = 0,
        pickaxe_count = 0,
        camp_capacity = 0,
        formation_capacity = 0,
        formation_discarded = 0,
        four_dim = { 0, 0, 0, 0 },
    }

    -- 1) 本地消耗神之馈赠 (16000080)
    local divine_used = 0
    for i = #self.item_list, 1, -1 do
        local item = self.item_list[i]
        if item.template_id == 16000080 then
            local cnt = math.max(1, tonumber(item.num) or 1)
            local divine = require "logic.divine_boost"
            for _ = 1, cnt do
                divine:Apply()
            end
            divine_used = divine_used + cnt
            table.remove(self.item_list, i)
        end
    end
    if divine_used > 0 then
        self:SavePersistent()
        summary.opened_count = summary.opened_count + divine_used
        summary.leader_bp = summary.leader_bp + divine_used * 100000000
        for s = 1, 4 do
            summary.four_dim[s] = summary.four_dim[s] + divine_used * 10000
        end
    end

    -- 2) 收集全部服务端可开启道具：非佣兵包优先，佣兵包殿后（防营帐满提前卡住资源/抵扣券）
    local non_merc_queue = {}
    local merc_queue = {}
    for _, item in ipairs(self.item_list) do
        if self:IsItemAutoUsable(item) then
            local tid = item.template_id
            local name = tostring(item.template_info.name or "")
            local rt = item.template_info.rule_type
            local is_merc_pack = (rt == constants.ITEM_RULE["hero_biography"])
                or (string.find(name, "英雄", 1, true) ~= nil)
                or (string.find(name, "佣兵", 1, true) ~= nil)
                or (string.find(name, "伙伴", 1, true) ~= nil)
            local bucket = is_merc_pack and merc_queue or non_merc_queue
            local stack = math.max(1, tonumber(item.num) or 1)
            for _ = 1, stack do
                bucket[#bucket + 1] = { item_id = item.item_id, template_id = tid }
            end
        end
    end

    local queue = {}
    for _, e in ipairs(non_merc_queue) do queue[#queue + 1] = e end
    for _, e in ipairs(merc_queue) do queue[#queue + 1] = e end

    if #queue == 0 then
        if divine_used > 0 then
            graphic:DispatchEvent("update_bag")
            graphic:DispatchEvent("bag_is_full")
            graphic:DispatchEvent("bag_batch_open_done", summary, nil)
            return true
        end
        graphic:DispatchEvent("show_prompt_panel", "背包内暂无可自动使用的道具")
        return false
    end

    self.batch_open_active = true
    self.batch_is_use_all = true
    self.batch_queue = queue
    self.batch_stop_reason = nil
    self.batch_summary = summary
    self:DispatchNextBatchItem()
    return true
end

return bag
