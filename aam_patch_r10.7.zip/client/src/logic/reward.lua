local network = require "util.network"
local constants = require "util.constants"

local config_manager = require "logic.config_manager"

local REWARD_SOURCE = constants.REWARD_SOURCE
local REWARD_TYPE = constants.REWARD_TYPE
local client_constants = require "util.client_constants"

local user_logic
local resource_logic
local troop_logic
local destiny_logic
local mining_logic
local adventure_logic
local bag_logic
local carnival_logic
local rune_logic
local achievement_logic
local hot_mercenary_logic

local graphic = require "logic.graphic"

local reward = {}

function reward:Init()
    user_logic = require "logic.user"
    adventure_logic = require "logic.adventure"
    troop_logic = require "logic.troop"
    resource_logic = require "logic.resource"
    destiny_logic = require "logic.destiny_weapon"
    mining_logic = require "logic.mining"
    bag_logic = require "logic.bag"
    carnival_logic = require "logic.carnival"
    rune_logic = require "logic.rune"
    achievement_logic = require "logic.achievement"
    hot_mercenary_logic = require "logic.hot_mercenary"

    self.max_reward_num = 0

    self.reward_info_list = nil
    self.last_reward_source = nil

    self.reward_info_list_head = nil
    self.reward_info_list_tail = nil

    self:RegisterMsgHandler()
end

function reward:GetRewardInfoList()
    return self.reward_info_list
end

function reward:ResetRewardInfoList()
    self.reward_info_list = {}
end

function reward:PushRewardInfoList(source, reward_info_list)
    reward_info_list.source = source

    if self.reward_info_list_tail then
        self.reward_info_list_tail.next = reward_info_list
    else
        self.reward_info_list_tail = reward_info_list
        self.reward_info_list_head = reward_info_list
    end
end

function reward:PopRewardInfoList()
    local cur_reward_info_list = self.reward_info_list_head
    if self.reward_info_list_head then
        self.reward_info_list_head = self.reward_info_list_head.next
    end

    if not self.reward_info_list_tail.next then

    end

    return cur_reward_info_list
end

--客户端为了显示而虚拟奖励数据
function reward:AddRewardInfo(source, reward_info_list)
    reward_info_list.source = source
    self.reward_info_list = reward_info_list
end

function reward:RegisterMsgHandler()
    network:RegisterEvent("reward_info_list", function(recv_msg)
        local need_remove_reward = false
        local reward_index = 0
        local source = recv_msg.source
        for i, reward_info in ipairs(recv_msg.reward_info_list) do

            local reward_type = reward_info.id
            reward_info.reward_type = reward_type

            if reward_type == REWARD_TYPE["feature"] then
                user_logic:SetPermanentMark(reward_info.param1, true)

            elseif reward_type == REWARD_TYPE["resource"] then
                --资源
                update_resource = true
                resource_logic:UpdateResource(reward_info.param1, reward_info.param2)

            elseif reward_type == REWARD_TYPE["mercenary"] then
                --佣兵
                local mercenary = troop_logic:CreateMercenary(reward_info.param1, reward_info.param2, reward_info.param3, reward_info.mercenary_att)
                reward_info["mercenary_id"] = mercenary.instance_id
                reward_info["is_new"] = mercenary.is_new
                if recv_msg.source == REWARD_SOURCE["hot_mercenary"] or recv_msg.source == REWARD_SOURCE["hot_mercenary_reward"] then
                    hot_mercenary_logic.new_mercenarys[mercenary.template_id] = mercenary.is_new
                end
                local quality = mercenary.template_info.quality
                if quality == client_constants["QUALITY_TYPE"].quality4 then
                    achievement_logic:UpdateStatisticValue(constants.ACHIEVEMENT_TYPE["mercenary_quality4"], 1)
                elseif quality == client_constants["QUALITY_TYPE"].quality5 then
                    achievement_logic:UpdateStatisticValue(constants.ACHIEVEMENT_TYPE["mercenary_quality5"], 1)
                elseif quality == client_constants["QUALITY_TYPE"].quality6 then
                    achievement_logic:UpdateStatisticValue(constants.ACHIEVEMENT_TYPE["mercenary_quality6"], 1)
                end
                if tonumber(source) == 22 or tonumber(source) == 23 then
                    local review_app_quality = 6
                    if mercenary.template_info.quality >= review_app_quality then
                        local user_data = require "util.user_data"
                        local user_config = user_data:new(nil,"blood_diamond_limit")
                        local review_app = user_config:getKeyValue("review_app") 
                        if review_app ~= nil then
                            self.review_app = nil
                        else
                            self.review_app = true
                        end
                    end
                end

            elseif reward_type == REWARD_TYPE["item"] then
                --物品；背包放不下的部分由 bag 记录后转成邮件
                bag_logic:NewItemOrMail(reward_info.param1, reward_info.param2)

            elseif reward_type == REWARD_TYPE["leader_bp"] then
                --主角战力
                troop_logic:SetLeaderBP(troop_logic.leader_bp + reward_info.param1)

            elseif reward_type == REWARD_TYPE["formation_capacity"] then
                --最大探索人数。服务端下发的是“提升后的绝对值”，直接同步；
                --param2 > 0 代表已达上限且多余出阵+1已直接销毁。
                local new_cap = tonumber(reward_info.param1) or 0
                local discarded = tonumber(reward_info.param2) or 0
                if discarded > 0 then
                    if not (bag_logic and bag_logic.batch_open_active) then
                        pcall(function()
                            local pixel_kit = require "ui.pixel_kit"
                            pixel_kit:ShowToast(string.format("出战人数已达上限（%d人），多余出阵+1已自动销毁", new_cap), 0xf3a833)
                        end)
                    end
                    need_remove_reward = true
                    reward_index = i
                elseif new_cap > 0 and troop_logic:GetFormationCapacity() ~= new_cap then
                    troop_logic:SetFormationCapacity(new_cap)
                    graphic:DispatchEvent("update_formation_capacity", new_cap)
                    if not (bag_logic and bag_logic.batch_open_active) then
                        pcall(function()
                            local pixel_kit = require "ui.pixel_kit"
                            pixel_kit:ShowToast(string.format("出战人数上限已提升至 %d 人", new_cap), 0xa1e01b)
                        end)
                    end
                else
                    need_remove_reward = true
                    reward_index = i
                end

            elseif reward_type == REWARD_TYPE["destiny_weapon"] then
                --宿命武器
                destiny_logic:AddNewWeapon(reward_info.param1)

            elseif reward_type == REWARD_TYPE["pickaxe_count"] then
                --挖掘次数
                mining_logic:AddDigCount(reward_info.param1)

            elseif reward_type == REWARD_TYPE["maze"] or reward_type == REWARD_TYPE["area"] then
                adventure_logic:UnlockMaze(reward_info.param1, reward_type == REWARD_TYPE["area"])

            elseif reward_type == REWARD_TYPE["camp_capacity"] then
                --营帐容量
                troop_logic:SetCampCapacity(troop_logic:GetCampCapacity() + reward_info.param1)

            elseif reward_type == REWARD_TYPE["soul_stone"] then
                troop_logic:UpdateSoulStone(reward_info.param1, reward_info.param2)

            elseif reward_type == REWARD_TYPE["rune"] then
                rune_logic:NewRune(reward_info.param1, reward_info.param2, reward_info.param3, reward_info.param4)
            end
        end

        if need_remove_reward then
            table.remove(recv_msg.reward_info_list, reward_index)
        end

        -- 背包溢出部分转邮件（一次奖励里的所有物品处理完再补报）
        bag_logic:FlushOverflowMail()

        self.reward_info_list = recv_msg.reward_info_list
        self.reward_info_list.source = recv_msg.source
        self.last_reward_source = recv_msg.source

        -- [MOD] 背包一键批量开启期间，把本包奖励汇总到 bag_logic，结束后统一展示
        if bag_logic and bag_logic.batch_open_active and bag_logic.CollectBatchRewards then
            bag_logic:CollectBatchRewards(recv_msg.reward_info_list)
        end

        if update_resource then
            graphic:DispatchEvent("update_resource_list", recv_msg.source)
            resource_logic:ClearDirtyFlags()
        end
    end)
end

return reward
