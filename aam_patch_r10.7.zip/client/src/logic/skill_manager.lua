local config_manager = require "logic.config_manager"
local constants = require "util.constants"

local mercenary_config = config_manager.mercenary_config
local mercenary_exp_config = config_manager.mercenary_exp_config
local active_skill_config = config_manager.active_skill_config
local passive_skill_config = config_manager.passive_skill_config
local cooperative_skill_config = config_manager.cooperative_skill_config

local PASSIVE_SKILL_EFFECT_TYPE = constants.PASSIVE_SKILL_EFFECT_TYPE
local PROPERTY_TYPE_NAME = constants.PROPERTY_TYPE_NAME

-- 每点先攻值增加%0.5的暴击伤害
local SPEED_FACTOR = 0.005

-- 每点闪避值增加%0.5的治疗量
local DODGE_FACTOR = 0.005

-- 每点王者值增加%1的最终伤害
local AUTHORITY_FACTOR = 0.01

local math_ceil = math.ceil
local math_floor = math.floor

local skill_manager = {
    active_effects = {},
    passive_effects = {}
}

local function LOG(adress, details)
    local path = cc.FileUtils:getInstance():getWritablePath()
    local file = io.open(path .. "log.txt", "a+")
    file:write(adress, "|", details, "\n")
    file:close()
end

function skill_manager:Init()

    local ACTIVE_SKILL_EFFECT_TYPE = constants.ACTIVE_SKILL_EFFECT_TYPE
    local SKILL_CULTIVATION = constants.SKILL_CULTIVATION
    self.SPEED_FACTOR = SPEED_FACTOR
    self.DODGE_FACTOR = DODGE_FACTOR
    self.AUTHORITY_FACTOR = AUTHORITY_FACTOR

    local effects = self.active_effects

    local CalcDamageBp = function(receiver, damage)
        -- [FIX r10.7] 负伤害技能（如 1400022/1400039/1400040/1400041/1400045/1500025 为敌方回血）
        -- 直接回复 cur_bp，不可倒灌进护盾条 cur_shield_bp。
        if damage < 0 then
            receiver.cur_bp = receiver.cur_bp - damage
            receiver.is_resist_lethal = false
            return
        end

        if receiver.cur_shield_bp > 0 then
            if receiver.cur_shield_bp > damage then
                receiver.cur_shield_bp = receiver.cur_shield_bp - damage
                damage = 0
            else
                damage = damage - receiver.cur_shield_bp
                receiver.cur_shield_bp = 0
            end

        end

        receiver.cur_bp = receiver.cur_bp - damage
        -- FYD  如果当前被施法方战力等于或低于0 同时存在抵御致死攻击的效果
        receiver.is_resist_lethal = false -- 是否抵御致死
        if receiver.cur_bp <= 0 and receiver.resist_lethal_num and receiver.resist_lethal_num > 0 then
            ----LOG(tostring(receiver),"触发抵御致死,当前血量变为1")
            receiver.resist_lethal_num = receiver.resist_lethal_num - 1
            receiver.is_resist_lethal = true
            receiver.resist_lethal_damage = receiver.cur_bp
            receiver.cur_bp = 1
        end
    end
    -- 修炼的计算方法
    local CaculateCultivation = function(receiver, caster, cur_type, damage)

        -- 施法方的当前修炼技能伤害加成
        local coefficient1 = 0
        local coefficient2 = 0
        if caster.cultivation_property[cur_type] and caster.cultivation_property[cur_type].coefficient1 then
            coefficient1 = caster.cultivation_property[cur_type].coefficient1
        end
        if receiver.cultivation_property[cur_type] and receiver.cultivation_property[cur_type].coefficient2 then
            coefficient2 = receiver.cultivation_property[cur_type].coefficient2
        end
        damage = math.ceil(damage * (1 + coefficient1 / 100 + coefficient2 / 100))

        return damage
    end
    local ReplyProcess = function(caster, receiver, reply, cur_type)
        -- 施法方的当前修炼技能伤害加成
        local coefficient1 = 0
        local coefficient2 = 0
        local damage = 0
        if caster.cultivation_property[cur_type] and caster.cultivation_property[cur_type].coefficient1 then
            coefficient1 = caster.cultivation_property[cur_type].coefficient1
        end
        if receiver.cultivation_property[cur_type] and receiver.cultivation_property[cur_type].coefficient2 then
            coefficient2 = receiver.cultivation_property[cur_type].coefficient2
        end
        -- 回血量处理
        reply = math.ceil(reply * (1 + coefficient1 / 100 + coefficient2 / 100))
        -- 削弱回血buff
        reply = caster:BuffSeriouslyInjured(reply)
        -- 痛苦效果buff
        reply, damage = caster:BuffPain(reply)
        if damage > 0 then
            reply = 0 -- 痛苦会让治疗效果直接为0，并且造成伤害加成
            caster.cur_bp = caster.cur_bp - damage
            CalcDamageBp(caster, damage)
        end
        return reply
    end

    -- 普通攻击
    effects[ACTIVE_SKILL_EFFECT_TYPE["melee_damage"]] = function(caster, receiver, skill, is_dodge)
        if is_dodge then
            return
        end

        local damage = math_ceil((caster.max_bp / 5 + caster.cur_bp / 10) * receiver.damage_reduction_factor *
                                     caster.final_damage_modifier)
        CCLOG("damagedamage:", damage)
        -- BUFF 削弱伤害效果
        damage = caster:BuffWeak(damage)

        if caster.exhaust_turn > 0 then
            ----LOG(tostring(caster),"原始虚弱技能:伤害变成1")
            damage = 1
        end

        if receiver.absorb_turn and receiver.absorb_turn > 0 then
            local reply = math.floor((damage * receiver.absorb_value or 0) / 100)
            if reply < 0 then
                reply = 1
            end

            local cur_type = SKILL_CULTIVATION["increase_by_self_bp"]
            reply = ReplyProcess(receiver, caster, reply, cur_type)
            receiver.cur_bp = receiver.cur_bp + reply
            return
        end
        CalcDamageBp(receiver, damage)
    end

    -- 暴击
    effects[ACTIVE_SKILL_EFFECT_TYPE["critical_damage"]] = function(caster, receiver, skill, is_dodge)
        local damage = math_ceil((caster.max_bp / 5 + caster.cur_bp / 10) *
                                     (skill.param / 100 + SPEED_FACTOR * caster.speed) *
                                     receiver.damage_reduction_factor * caster.final_damage_modifier)
        local cur_type = SKILL_CULTIVATION["critical_damage"]
        damage = CaculateCultivation(receiver, caster, cur_type, damage)
        -- BUFF 削弱伤害效果
        damage = caster:BuffWeak(damage)

        if caster.exhaust_turn > 0 then
            ----LOG(tostring(caster),"原始虚弱技能:伤害变成1")
            damage = 1
        end

        if receiver.absorb_turn and receiver.absorb_turn > 0 then
            local reply = math.floor((damage * receiver.absorb_value or 0) / 100)
            if reply < 0 then
                reply = 1
            end

            local cur_type = SKILL_CULTIVATION["increase_by_self_bp"]
            reply = ReplyProcess(receiver, caster, reply, cur_type)
            receiver.cur_bp = receiver.cur_bp + reply
            return
        end
        CalcDamageBp(receiver, damage)
    end

    -- 伤害加深
    effects[ACTIVE_SKILL_EFFECT_TYPE["increase_damage"]] = function(caster, receiver, skill, is_dodge)
        if is_dodge then
            return
        end

        local damage = math_ceil((caster.max_bp / 5 + caster.cur_bp / 10) * skill.param / 100 *
                                     receiver.damage_reduction_factor * caster.final_damage_modifier)

        local cur_type = SKILL_CULTIVATION["increase_damage"]
        damage = CaculateCultivation(receiver, caster, cur_type, damage)

        -- BUFF 削弱伤害效果
        damage = caster:BuffWeak(damage)

        if caster.exhaust_turn > 0 then
            ----LOG(tostring(caster),"原始虚弱技能:伤害变成1")
            damage = 1
        end

        if receiver.absorb_turn and receiver.absorb_turn > 0 then
            local reply = math.floor((damage * receiver.absorb_value or 0) / 100)
            if reply < 0 then
                reply = 1
            end

            local cur_type = SKILL_CULTIVATION["increase_by_self_bp"]
            reply = ReplyProcess(receiver, caster, reply, cur_type)
            receiver.cur_bp = receiver.cur_bp + reply
            return
        end

        CalcDamageBp(receiver, damage)
    end

    -- 怒气攻击
    effects[ACTIVE_SKILL_EFFECT_TYPE["rage_damage"]] = function(caster, receiver, skill, is_dodge)
        if is_dodge then
            return
        end

        local damage = math_ceil(
            (caster.max_bp - caster.cur_bp) * skill.param / 100 * receiver.damage_reduction_factor *
                caster.final_damage_modifier)

        local cur_type = SKILL_CULTIVATION["rage_damage"]
        damage = CaculateCultivation(receiver, caster, cur_type, damage)
        -- BUFF 削弱伤害效果
        damage = caster:BuffWeak(damage)

        if caster.exhaust_turn > 0 then
            ----LOG(tostring(caster),"原始虚弱技能:伤害变成1")
            damage = 1
        end

        damage = damage > 0 and damage or 1

        if receiver.absorb_turn and receiver.absorb_turn > 0 then
            local reply = math.floor((damage * receiver.absorb_value or 0) / 100)
            if reply < 0 then
                reply = 1
            end

            local cur_type = SKILL_CULTIVATION["increase_by_self_bp"]
            reply = ReplyProcess(receiver, caster, reply, cur_type)
            receiver.cur_bp = receiver.cur_bp + reply
            return
        end

        CalcDamageBp(receiver, damage)

    end

    -- 反噬敌当
    effects[ACTIVE_SKILL_EFFECT_TYPE["damage_by_enemy_bp"]] =
        function(caster, receiver, skill, is_dodge)
            if is_dodge then
                return
            end

            local damage = math_ceil(receiver.cur_bp * skill.param / 100 * receiver.damage_reduction_factor *
                                         caster.final_damage_modifier)

            local cur_type = SKILL_CULTIVATION["damage_by_enemy_bp"]
            damage = CaculateCultivation(receiver, caster, cur_type, damage)
            -- BUFF 削弱伤害效果
            damage = caster:BuffWeak(damage)

            if caster.exhaust_turn > 0 then
                ----LOG(tostring(caster),"原始虚弱技能:伤害变成1")
                damage = 1
            end
            if receiver.absorb_turn and receiver.absorb_turn > 0 then
                local reply = math.floor((damage * receiver.absorb_value or 0) / 100)
                if reply < 0 then
                    reply = 1
                end

                local cur_type = SKILL_CULTIVATION["increase_by_self_bp"]
                reply = ReplyProcess(receiver, caster, reply, cur_type)
                receiver.cur_bp = receiver.cur_bp + reply
                return
            end
            CalcDamageBp(receiver, damage)
        end

    -- 反噬敌初
    effects[ACTIVE_SKILL_EFFECT_TYPE["damage_by_enemy_init_bp"]] =
        function(caster, receiver, skill, is_dodge)
            if is_dodge then
                return
            end

            local damage = math_ceil(receiver.max_bp * skill.param / 100 * receiver.damage_reduction_factor *
                                         caster.final_damage_modifier)

            local cur_type = SKILL_CULTIVATION["damage_by_enemy_init_bp"]
            damage = CaculateCultivation(receiver, caster, cur_type, damage)

            -- BUFF 削弱伤害效果
            damage = caster:BuffWeak(damage)

            if caster.exhaust_turn > 0 then
                ----LOG(tostring(caster),"原始虚弱技能:伤害变成1")
                damage = 1
            end
            if receiver.absorb_turn and receiver.absorb_turn > 0 then
                local reply = math.floor((damage * receiver.absorb_value or 0) / 100)
                if reply < 0 then
                    reply = 1
                end

                local cur_type = SKILL_CULTIVATION["increase_by_self_bp"]
                reply = ReplyProcess(receiver, caster, reply, cur_type)
                receiver.cur_bp = receiver.cur_bp + reply
                return
            end
            CalcDamageBp(receiver, damage)
        end

    -- 反噬敌损
    effects[ACTIVE_SKILL_EFFECT_TYPE["damage_by_enemy_loss_bp"]] =
        function(caster, receiver, skill, is_dodge)
            if is_dodge then
                return
            end

            local damage = math_ceil((receiver.max_bp - receiver.cur_bp) * skill.param / 100 *
                                         receiver.damage_reduction_factor * caster.final_damage_modifier)

            local cur_type = SKILL_CULTIVATION["damage_by_enemy_loss_bp"]
            damage = CaculateCultivation(receiver, caster, cur_type, damage)

            -- BUFF 削弱伤害效果
            damage = caster:BuffWeak(damage)

            if caster.exhaust_turn > 0 then
                ----LOG(tostring(caster),"原始虚弱技能:伤害变成1")
                damage = 1
            end

            damage = damage > 0 and damage or 1

            if receiver.absorb_turn and receiver.absorb_turn > 0 then
                local reply = math.floor((damage * receiver.absorb_value or 0) / 100)
                if reply < 0 then
                    reply = 1
                end

                local cur_type = SKILL_CULTIVATION["increase_by_self_bp"]
                reply = ReplyProcess(receiver, caster, reply, cur_type)
                receiver.cur_bp = receiver.cur_bp + reply
                return
            end
            CalcDamageBp(receiver, damage)
        end

    -- 战力吸收
    effects[ACTIVE_SKILL_EFFECT_TYPE["bp_steal"]] = function(caster, receiver, skill, is_dodge)
        if is_dodge then
            return
        end

        local damage = math_ceil((caster.max_bp / 5 + caster.cur_bp / 10) * receiver.damage_reduction_factor *
                                     caster.final_damage_modifier * (skill.param2 and (skill.param2 / 100) or 1))

        local cur_type = SKILL_CULTIVATION["bp_steal"]
        damage = CaculateCultivation(receiver, caster, cur_type, damage)

        -- BUFF 削弱伤害效果
        damage = caster:BuffWeak(damage)

        if caster.exhaust_turn > 0 then
            ----LOG(tostring(caster),"原始虚弱技能:伤害变成1")
            damage = 1
        end
        if receiver.absorb_turn and receiver.absorb_turn > 0 then
            local reply = math.floor((damage * receiver.absorb_value or 0) / 100)
            if reply < 0 then
                reply = 1
            end

            local cur_type = SKILL_CULTIVATION["increase_by_self_bp"]
            reply = ReplyProcess(receiver, caster, reply, cur_type)
            receiver.cur_bp = receiver.cur_bp + reply
            return
        end
        caster.cur_bp = math_ceil(caster.cur_bp + damage * skill.param / 100 * caster.bp_increase_factor)

        CalcDamageBp(receiver, damage)
    end

    -- 战力提升己当
    effects[ACTIVE_SKILL_EFFECT_TYPE["increase_by_self_bp"]] =
        function(caster, receiver, skill, is_dodge)
            local cur_type = SKILL_CULTIVATION["increase_by_self_bp"]

            -- 当前回复量
            local reply = math_ceil(caster.cur_bp * skill.param / 100 * caster.bp_increase_factor)
            local cur_type = SKILL_CULTIVATION["increase_by_self_bp"]
            reply = ReplyProcess(caster, receiver, reply, cur_type)
            caster.cur_bp = caster.cur_bp + reply

            if is_dodge then
                return
            end

            local damage = (caster.max_bp * 0.2 + caster.cur_bp * 0.1) * receiver.damage_reduction_factor *
                               caster.final_damage_modifier
            local ratio = (skill.param2 and skill.param2 ~= 0) and skill.param2 or 100
            damage = math_ceil(damage * ratio / 100)

            -- BUFF 削弱伤害效果
            damage = caster:BuffWeak(damage)

            if caster.exhaust_turn > 0 then
                ----LOG(tostring(caster),"原始虚弱技能:伤害变成1")
                damage = 1
            end

            if receiver.absorb_turn and receiver.absorb_turn > 0 then
                local reply = math.floor((damage * receiver.absorb_value or 0) / 100)
                if reply < 0 then
                    reply = 1
                end

                local cur_type = SKILL_CULTIVATION["increase_by_self_bp"]
                reply = ReplyProcess(receiver, caster, reply, cur_type)
                receiver.cur_bp = receiver.cur_bp + reply
                return
            end
            CalcDamageBp(receiver, damage)
        end

    -- 战力提升己初
    effects[ACTIVE_SKILL_EFFECT_TYPE["increase_by_self_init_bp"]] =
        function(caster, receiver, skill, is_dodge)
            local reply = math_ceil(caster.max_bp * skill.param / 100 * caster.bp_increase_factor)
            local cur_type = SKILL_CULTIVATION["increase_by_self_init_bp"]
            reply = ReplyProcess(caster, receiver, reply, cur_type)
            caster.cur_bp = caster.cur_bp + reply

            if is_dodge then
                return
            end

            local damage = (caster.max_bp * 0.2 + caster.cur_bp * 0.1) * receiver.damage_reduction_factor *
                               caster.final_damage_modifier
            local ratio = (skill.param2 and skill.param2 ~= 0) and skill.param2 or 100
            damage = math_ceil(damage * ratio / 100)

            -- BUFF 削弱伤害效果
            damage = caster:BuffWeak(damage)

            if caster.exhaust_turn > 0 then
                ----LOG(tostring(caster),"原始虚弱技能:伤害变成1")
                damage = 1
            end

            if receiver.absorb_turn and receiver.absorb_turn > 0 then
                local reply = math.floor((damage * receiver.absorb_value or 0) / 100)
                if reply < 0 then
                    reply = 1
                end

                local cur_type = SKILL_CULTIVATION["increase_by_self_bp"]
                reply = ReplyProcess(receiver, caster, reply, cur_type)
                receiver.cur_bp = receiver.cur_bp + reply
                return
            end

            CalcDamageBp(receiver, damage)
        end

    -- 战力提升敌当
    effects[ACTIVE_SKILL_EFFECT_TYPE["increase_by_enemy_bp"]] =
        function(caster, receiver, skill, is_dodge)
            local reply = math_ceil(receiver.cur_bp * skill.param / 100 * caster.bp_increase_factor)
            local cur_type = SKILL_CULTIVATION["increase_by_enemy_bp"]
            reply = ReplyProcess(caster, receiver, reply, cur_type)
            caster.cur_bp = caster.cur_bp + reply

            if is_dodge then
                return
            end

            local damage = (caster.max_bp * 0.2 + caster.cur_bp * 0.1) * receiver.damage_reduction_factor *
                               caster.final_damage_modifier
            local ratio = (skill.param2 and skill.param2 ~= 0) and skill.param2 or 100
            damage = math_ceil(damage * ratio / 100)

            -- BUFF 削弱伤害效果
            damage = caster:BuffWeak(damage)

            if caster.exhaust_turn > 0 then
                ----LOG(tostring(caster),"原始虚弱技能:伤害变成1")
                damage = 1
            end
            if receiver.absorb_turn and receiver.absorb_turn > 0 then
                local reply = math.floor((damage * receiver.absorb_value or 0) / 100)
                if reply < 0 then
                    reply = 1
                end

                local cur_type = SKILL_CULTIVATION["increase_by_self_bp"]
                reply = ReplyProcess(receiver, caster, reply, cur_type)
                receiver.cur_bp = receiver.cur_bp + reply
                return
            end
            CalcDamageBp(receiver, damage)
        end

    -- 战力提升敌初
    effects[ACTIVE_SKILL_EFFECT_TYPE["increase_by_enemy_init_bp"]] =
        function(caster, receiver, skill, is_dodge)
            local reply = math_ceil(receiver.max_bp * skill.param / 100 * caster.bp_increase_factor)
            local cur_type = SKILL_CULTIVATION["increase_by_enemy_init_bp"]
            reply = ReplyProcess(caster, receiver, reply, cur_type)
            caster.cur_bp = caster.cur_bp + reply
            if is_dodge then
                return
            end

            local damage = (caster.max_bp * 0.2 + caster.cur_bp * 0.1) * receiver.damage_reduction_factor *
                               caster.final_damage_modifier
            local ratio = (skill.param2 and skill.param2 ~= 0) and skill.param2 or 100
            damage = math_ceil(damage * ratio / 100)

            -- BUFF 削弱伤害效果
            damage = caster:BuffWeak(damage)

            if caster.exhaust_turn > 0 then
                ----LOG(tostring(caster),"原始虚弱技能:伤害变成1")
                damage = 1
            end
            if receiver.absorb_turn and receiver.absorb_turn > 0 then
                local reply = math.floor((damage * receiver.absorb_value or 0) / 100)
                if reply < 0 then
                    reply = 1
                end

                local cur_type = SKILL_CULTIVATION["increase_by_self_bp"]
                reply = ReplyProcess(receiver, caster, reply, cur_type)
                receiver.cur_bp = receiver.cur_bp + reply
                return
            end
            CalcDamageBp(receiver, damage)
        end

    -- 纯粹攻击 不用计算防御值
    effects[ACTIVE_SKILL_EFFECT_TYPE["true_damage"]] = function(caster, receiver, skill, is_dodge)
        local damage = math_ceil((caster.max_bp / 5 + caster.cur_bp / 10) * skill.param / 100 *
                                     caster.final_damage_modifier)

        local cur_type = SKILL_CULTIVATION["true_damage"]
        damage = CaculateCultivation(receiver, caster, cur_type, damage)

        -- BUFF 削弱伤害效果
        damage = caster:BuffWeak(damage)

        if caster.exhaust_turn > 0 then
            ----LOG(tostring(caster),"原始虚弱技能:伤害变成1")
            damage = 1
        end
        if receiver.absorb_turn and receiver.absorb_turn > 0 then
            local reply = math.floor((damage * receiver.absorb_value or 0) / 100)
            if reply < 0 then
                reply = 1
            end

            local cur_type = SKILL_CULTIVATION["increase_by_self_bp"]
            reply = ReplyProcess(receiver, caster, reply, cur_type)
            receiver.cur_bp = receiver.cur_bp + reply
            return
        end
        CalcDamageBp(receiver, damage)
    end

    -- 复制技能
    effects[ACTIVE_SKILL_EFFECT_TYPE["copy_skill"]] = function(caster, receiver, skill, is_dodge)
        skill = receiver.last_turn_skill or self:GetMeleeSkill()
        if skill then
            receiver.damage_reduction_factor = skill.ignore_defense and 1.0 or (100 / (100 + receiver.defense))
            local effect_method = self:GetEffect(skill.effect_type)
            effect_method(caster, receiver, skill, is_dodge)

            return skill
        end
    end

    effects[ACTIVE_SKILL_EFFECT_TYPE["armageddon_a"]] = function(caster, receiver, skill, is_dodge)
        if is_dodge then
            return
        end

        local caster_damage = math_ceil(caster.cur_bp * skill.param * 0.01)
        local receiver_damage = math_ceil(receiver.cur_bp * skill.param * 0.01 * receiver.damage_reduction_factor)

        -- BUFF 削弱伤害效果
        receiver_damage = caster:BuffWeak(receiver_damage)
        caster_damage = receiver:BuffWeak(caster_damage)

        if caster.exhaust_turn > 0 then
            ----LOG(tostring(caster),"原始虚弱技能:伤害变成1")
            receiver_damage = 1
        end
        if receiver.absorb_turn and receiver.absorb_turn > 0 then
            local reply = math.floor((receiver_damage * receiver.absorb_value or 0) / 100)
            if reply < 0 then
                reply = 1
            end

            local cur_type = SKILL_CULTIVATION["increase_by_self_bp"]
            reply = ReplyProcess(receiver, caster, reply, cur_type)
            receiver.cur_bp = receiver.cur_bp + reply
            return
        end
        caster.cur_bp = caster.cur_bp - caster_damage
        if caster.cur_bp <= 0 and caster.resist_lethal_num and caster.resist_lethal_num > 0 then
            caster.resist_lethal_num = caster.resist_lethal_num - 1
            caster.is_resist_lethal = true
            caster.resist_lethal_damage = caster.cur_bp
            caster.cur_bp = 1
        end
        CalcDamageBp(receiver, receiver_damage)
    end

    effects[ACTIVE_SKILL_EFFECT_TYPE["armageddon_b"]] = function(caster, receiver, skill, is_dodge)
        if is_dodge then
            return
        end

        caster.damage_reduction_factor = (100 / (100 + caster.defense))

        local caster_damage = math_ceil(caster.cur_bp * (skill.param * 0.01) * caster.damage_reduction_factor)
        local receiver_damage = math_ceil(receiver.cur_bp * (skill.param * 0.01) * receiver.damage_reduction_factor)

        -- BUFF 削弱伤害效果
        receiver_damage = caster:BuffWeak(receiver_damage)
        caster_damage = receiver:BuffWeak(caster_damage)

        if caster.exhaust_turn > 0 then
            ----LOG(tostring(caster),"原始虚弱技能:伤害变成1")
            receiver_damage = 1
        end

        if receiver.absorb_turn and receiver.absorb_turn > 0 then
            local reply = math.floor((receiver_damage * receiver.absorb_value or 0) / 100)
            if reply < 0 then
                reply = 1
            end

            local cur_type = SKILL_CULTIVATION["increase_by_self_bp"]
            reply = ReplyProcess(receiver, caster, reply, cur_type)
            receiver.cur_bp = receiver.cur_bp + reply
            return
        end

        caster.cur_bp = caster.cur_bp - caster_damage
        if caster.cur_bp <= 0 and caster.resist_lethal_num and caster.resist_lethal_num > 0 then
            caster.resist_lethal_num = caster.resist_lethal_num - 1
            caster.is_resist_lethal = true
            caster.resist_lethal_damage = caster.cur_bp
            caster.cur_bp = 1
        end
        CalcDamageBp(receiver, receiver_damage)
    end

    -- 战力百分比互换
    effects[ACTIVE_SKILL_EFFECT_TYPE["swap_bp_percent"]] = function(caster, receiver, skill, is_dodge)
        if is_dodge then
            return
        end

        local caster_bp_percent = caster.cur_bp / caster.max_bp
        local receiver_bp_percent = receiver.cur_bp / receiver.max_bp

        caster.cur_bp = math.ceil(receiver_bp_percent * caster.max_bp)
        receiver.cur_bp = math.ceil(caster_bp_percent * receiver.max_bp)
    end
end

function skill_manager:GetEffect(effect_id)
    return self.active_effects[effect_id]
end

function skill_manager:GetMeleeSkill()
    return config_manager.active_skill_config[1000001]
end

function skill_manager:IsCanUseSkill(skill_id, turn, bp_pecent)
    local skill = active_skill_config[skill_id]
    if not skill then
        return false
    end

    local turn = turn or 1
    if turn <= skill.turn_cond1 then
        return false

    elseif skill.turn_cond2 ~= 0 and turn >= skill.turn_cond2 then
        return false
    end

    if bp_pecent <= skill.self_bp_cond1 then
        return false

    elseif skill.self_bp_cond2 ~= 0 and bp_pecent >= skill.self_bp_cond2 then
        return false
    end

    if bp_pecent <= skill.enemy_bp_cond1 then
        return false

    elseif skill.enemy_bp_cond2 ~= 0 and bp_pecent >= skill.enemy_bp_cond2 then
        return false
    end

    return true
end

-- [MOD] 按技能描述校验“敌方战力高于我方 X%”类限制条件。
-- bp_pecent 采用与 IsCanUseSkill 相同的口径：敌方当前战力 / 我方当前战力 * 100。
function skill_manager:CheckEnemyBpCondition(skill, caster_bp, receiver_bp)
    if not skill then
        return true
    end

    local cond1 = tonumber(skill.enemy_bp_cond1) or 0
    local cond2 = tonumber(skill.enemy_bp_cond2) or 0
    if cond1 <= 0 and cond2 <= 0 then
        return true
    end

    caster_bp = tonumber(caster_bp) or 0
    receiver_bp = tonumber(receiver_bp) or 0
    if caster_bp <= 0 then
        return true
    end

    local bp_pecent = receiver_bp * 100 / caster_bp
    if cond1 > 0 and bp_pecent <= cond1 then
        return false
    end
    if cond2 > 0 and bp_pecent >= cond2 then
        return false
    end

    return true
end

-- [FIX r10.7] 全量 0★/★/★★ 与 EX 变体归并函数，与服务端 canonicalCoopMercId 保持严格一致：
--   - 四圣四凶/五鲲：190013xx(★)/190023xx(★★) -> 190003xx
--   - EX女仆姐姐/妹妹 0★/★/★★ -> 19000171 / 19000172（兼容 100088 姐妹）
--   - EX蛇姬 ★/★★ -> 19100103
--   - 其余全部 EX★ (100000..199999) / EX★★ (200000..299999) -> 0★ EX 基础 ID
function skill_manager:CanonicalCoopMercId(id)
    id = tonumber(id) or 0
    if id >= 19001300 and id <= 19001399 then
        return id - 1000
    elseif id >= 19002300 and id <= 19002399 then
        return id - 2000
    elseif id == 19100171 or id == 119171 or id == 219171 then
        return 19000171
    elseif id == 19100172 or id == 119172 or id == 219172 then
        return 19000172
    elseif id == 119103 or id == 219103 then
        return 19100103
    elseif id >= 100000 and id < 200000 then
        return id - 100000
    elseif id >= 200000 and id < 300000 then
        return id - 200000
    end
    return id
end

function skill_manager:GetCoopTemplateCount(template_id_map, mercenary_template_id)
    if not template_id_map then
        return 0
    end
    local target_canon = self:CanonicalCoopMercId(mercenary_template_id)
    local total = 0
    for tid, cnt in pairs(template_id_map) do
        if cnt and cnt > 0 and self:CanonicalCoopMercId(tid) == target_canon then
            total = total + cnt
        end
    end
    return total
end

local COOP_SIXIONG_BASE = { 19000325, 19000326, 19000327, 19000328 }
local COOP_SISHENG_BASE = { 19000329, 19000330, 19000331, 19000332 }

function skill_manager:CheckCoopSkillCanUse(troop, coop_skill_id, formation_id)
    -- 检测合体技能
    local coop_skill = cooperative_skill_config[coop_skill_id]
    if not coop_skill then
        return false
    end

    local id_map = troop.all_mercenary_template_ids
    -- 当传入的是 troop_logic（带 GetFormationMercenaryList）时，始终按指定 formation_id 实时统计，
    -- 即使该阵容为空也必须置空 id_map，防止回落到旧的 all_mercenary_template_ids 缓存造成误触发。
    if troop.GetFormationMercenaryList and (formation_id or troop.GetCurFormationId) then
        local target_fid = formation_id or troop:GetCurFormationId()
        local list = troop:GetFormationMercenaryList(target_fid)
        id_map = {}
        if list then
            for _, m in ipairs(list) do
                if m and m.template_id then
                    id_map[m.template_id] = (id_map[m.template_id] or 0) + 1
                end
            end
        end
    end
    if not id_map then
        return false
    end

    -- 构造归并后的计数表，避免在循环中重复扫描
    local canon_counts = {}
    for tid, cnt in pairs(id_map) do
        if cnt and cnt > 0 then
            local cid = self:CanonicalCoopMercId(tid)
            canon_counts[cid] = (canon_counts[cid] or 0) + cnt
        end
    end

    -- [MOD] 100302 四圣四凶「悖论」：任意四凶（含 0★/★/★★）与任意四圣（含 0★/★/★★）同时上阵即触发
    if tonumber(coop_skill_id) == 100302 then
        local has_xiong, has_sheng = false, false
        for i = 1, #COOP_SIXIONG_BASE do
            if (canon_counts[COOP_SIXIONG_BASE[i]] or 0) > 0 then
                has_xiong = true
                break
            end
        end
        for i = 1, #COOP_SISHENG_BASE do
            if (canon_counts[COOP_SISHENG_BASE[i]] or 0) > 0 then
                has_sheng = true
                break
            end
        end
        return has_xiong and has_sheng
    end

    -- 严格按归并后的条件需求人数累加校验（例如同一角色或同一 EX 家族多只需求）
    local need_canon = {}
    local has_any_need = false
    for mercenary_template_id, need_num in pairs(coop_skill.mercenary_ids) do
        local cid = self:CanonicalCoopMercId(mercenary_template_id)
        need_canon[cid] = (need_canon[cid] or 0) + need_num
        has_any_need = true
    end
    if not has_any_need then
        return false
    end
    for cid, need_num in pairs(need_canon) do
        if (canon_counts[cid] or 0) < need_num then
            return false
        end
    end
    return true
end

function skill_manager:GetSkill(skill_id)
    local active = active_skill_config[skill_id]
    if active then
        return active
    end
    return passive_skill_config[skill_id]
end

function skill_manager:FixPropertyNum(troop, skill, add_num)
    if skill.stack_limit ~= 0 then
        local skill_index = (troop.special_skill_index and troop.special_skill_index ~= 0) and troop.special_skill_index or skill.ID
        local cur_num = troop.stack_list[skill_index] or 0

        if cur_num + add_num >= skill.stack_limit then
            add_num = skill.stack_limit - cur_num
        end

        troop.stack_list[skill_index] = cur_num + add_num
    end

    return add_num
end

function skill_manager:AddPassiveSkill(troop, skill_id, take_special)
    local skill_info = self:GetSkill(skill_id)
    if not skill_info then
        return
    end
    -- [FIX] is_special 被动技（如露娜 341044 变身、阿普 341046、永恒EX 340037、光明意志EX 330070、C.C 31009037）
    -- 在第一轮(take_special=nil)已累加固定四维，第二轮(take_special=true)执行转化/人数统计时不得重复累加固定四维。
    if not take_special then
        troop.speed = troop.speed + (skill_info.speed or 0)
        troop.defense = troop.defense + (skill_info.defense or 0)
        troop.dodge = troop.dodge + (skill_info.dodge or 0)
        troop.authority = troop.authority + (skill_info.authority or 0)
    end

    -- [FIX] 部分联动被动技 ID >= 1000001（如 31009036 Geass / 31009037 被诅咒的魔女 / 31009038 神之力），
    -- 必须直接查 passive_skill_config 而不能按 ACTIVE_SKILL_ID_OFFSET 提前截断。
    local skill = config_manager.passive_skill_config[skill_id]
    if not skill then
        return
    end

    if skill.is_special and not take_special then
        if skill.effect_type == PASSIVE_SKILL_EFFECT_TYPE["convert_property"] then
            table.insert(troop.special_skill_list, skill_id)
        elseif skill.effect_type == PASSIVE_SKILL_EFFECT_TYPE["convert_property2"] then
            if not troop.special_skill_list2 then
                troop.special_skill_list2 = {}
            end
            table.insert(troop.special_skill_list2, skill_id)
        else
            table.insert(troop.special_skill_list, 1, skill_id)
        end

        return
    end

    -- 被动技能立即生效
    local num = 0

    -- 只能是合体技
    if skill.job ~= 0 or skill.sex ~= 0 or skill.race ~= 0 then
        for template_id, mercenary_num in pairs(troop.all_mercenary_template_ids) do
            local mercenary_template_info = config_manager.mercenary_config[template_id]
            local check_job = skill.job == 0 or skill.job == mercenary_template_info.job
            local check_sex = skill.sex == 0 or skill.sex == mercenary_template_info.sex
            local check_race = skill.race == 0 or skill.race == mercenary_template_info.race

            if check_job and check_sex and check_race then
                num = num + mercenary_num
            end
        end

    else
        num = 1
    end

    local add_num = skill.param1 * num
    if skill.effect_type == PASSIVE_SKILL_EFFECT_TYPE["increase_speed"] then
        troop.speed = troop.speed + self:FixPropertyNum(troop, skill, add_num)

    elseif skill.effect_type == PASSIVE_SKILL_EFFECT_TYPE["increase_defense"] then
        troop.defense = troop.defense + self:FixPropertyNum(troop, skill, add_num)

    elseif skill.effect_type == PASSIVE_SKILL_EFFECT_TYPE["increase_dodge"] then
        troop.dodge = troop.dodge + self:FixPropertyNum(troop, skill, add_num)

    elseif skill.effect_type == PASSIVE_SKILL_EFFECT_TYPE["increase_authority"] then
        troop.authority = troop.authority + self:FixPropertyNum(troop, skill, add_num)

    elseif skill.effect_type == PASSIVE_SKILL_EFFECT_TYPE["convert_property"] then
        if skill.param1 == 0 or skill.param2 == 0 or skill.param3 == 0 then
            return
        end

        local src_property = PROPERTY_TYPE_NAME[skill.param1]
        local dst_property = "extra_" .. PROPERTY_TYPE_NAME[skill.param2]

        local src_num = troop[src_property] >= 0 and troop[src_property] or 0

        troop[dst_property] = troop[dst_property] +
                                  self:FixPropertyNum(troop, skill, math.floor(src_num / skill.param3 * num))
    elseif skill.effect_type == PASSIVE_SKILL_EFFECT_TYPE["convert_property2"] then
        if skill.param1 == 0 or skill.param2 == 0 or skill.param3 == 0 then
            return
        end

        local src_property = PROPERTY_TYPE_NAME[skill.param1]
        local dst_property = "extra_" .. PROPERTY_TYPE_NAME[skill.param2]

        local src_num = troop[src_property] >= 0 and troop[src_property] or 0
        local add_num = src_num >= skill.param3 and skill.stack_limit or 0

        troop[dst_property] = troop[dst_property] + add_num
    elseif skill.effect_type == PASSIVE_SKILL_EFFECT_TYPE["shield_defense"] then
        troop.shield_bp = (troop.shield_bp or 0) + (skill.param1 or 0)
        if (skill.param2 or 0) > 0 then
            troop.shield_bp_percent = (troop.shield_bp_percent or 0) + skill.param2
            if troop.max_bp and troop.max_bp > 0 then
                troop.shield_bp = troop.shield_bp + math_floor(troop.max_bp * skill.param2 / 100)
            end
        end
    elseif skill.effect_type == PASSIVE_SKILL_EFFECT_TYPE["resist_lethal"] then
        troop.resist_lethal_num = math.max(troop.resist_lethal_num or 0, skill.param1 or 0)
    end
end

do
    skill_manager:Init()
end

return skill_manager
