local graphic = require "logic.graphic"
local panel_prototype = require "ui.panel"
local config_manager = require "logic.config_manager"

local constants = require "util.constants"
local client_constants = require "util.client_constants"
local lang_constants = require "util.language_constants"
local audio_manager = require "util.audio_manager"
local arena_logic = require "logic.arena"
local social_logic = require "logic.social"
local troop_logic = require "logic.troop"
local vip_logic = require "logic.vip"
local user_logic = require "logic.user"

local time_logic = require "logic.time"
local panel_util = require "ui.panel_util"
local pixel_kit = require "ui.pixel_kit"

local icon_panel = require "ui.icon_panel"
local platform_manager = require "logic.platform_manager"
local feature_config = require "logic.feature_config"

local JUMP_CONST = client_constants["JUMP_CONST"] 

local RIVAL_NUM = 9
local REWARD_COUNT = 3
local REWARD_BTN_BEGIN_POS_Y = 1040
local REWARD_BTN_DISTANCE = 100

--对手的基本信息sub panel
local rival_info_sub_panel = panel_prototype.New()
rival_info_sub_panel.__index = rival_info_sub_panel

function rival_info_sub_panel.New()
    local t = {}
    return setmetatable(t, rival_info_sub_panel)
end

function rival_info_sub_panel:Init(root_node, index)
    self.root_node = root_node
    self.index = index

    self.bg_img = root_node:getChildByName("bg")
    self.name_text = root_node:getChildByName("name")
    self.bp_text = root_node:getChildByName("bp_value")

    self.friend_btn = root_node:getChildByName("friend_btn")
    self.friend_btn:setTag(index)

    self.friend_btn_pos_x = self.friend_btn:getPositionX()
    self.friend_btn_pos_y = self.friend_btn:getPositionY()

    self.challenge_btn = root_node:getChildByName("challenge_btn")
    self.challenge_btn:setTag(index)

    self.win_icon_img = root_node:getChildByName("win_icon_new")
    self.win_icon_img:setVisible(false)

    self.icon_panel = icon_panel.New(nil, client_constants["ICON_TEMPLATE_MODE"]["no_text"])
    self.icon_panel:Init(root_node)
    self.icon_panel:SetPosition(60, 60)

    self.gonghui_bg = root_node:getChildByName("gonghui_bg")
    self.deac_gonghui = root_node:getChildByName("deac_gonghui")
    self.bp_icon = root_node:getChildByName("bp_icon")

    -- [MOD r10.5] 永久隐藏单机版空白公会灰条，将战力图标与数值移至对手 ID 正下方左对齐
    if self.gonghui_bg then
        self.gonghui_bg:setVisible(false)
    end
    if self.deac_gonghui then
        self.deac_gonghui:setString("")
        self.deac_gonghui:setVisible(false)
    end
    if self.bp_icon then
        self.bp_icon:setPosition(128, 40)
    end
    if self.bp_text then
        self.bp_text:setPosition(146, 40)
    end

    -- [PC PORT] The original CSB places the challenge button outside the
    -- visible row on this build.  Tapping the rival row itself challenges.
    root_node:setTouchEnabled(true)
    root_node:addTouchEventListener(function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            local rival = arena_logic:GetSingleRivalInfo(self.index)
            if rival and not rival.state then
                audio_manager:PlayEffect("click")
                arena_logic:ChallengeRival(self.index)
            end
        end
    end)
end

function rival_info_sub_panel:ReLoadInfo()

    local rival_info = arena_logic:GetSingleRivalInfo(self.index)
    if not rival_info then
        self.root_node:setVisible(false)
        return
    end
    self.root_node:setVisible(true)
    local template_id = rival_info.template_id

    self.icon_panel:Show(constants["REWARD_TYPE"]["mercenary"], template_id, nil, nil, false)

    --  多语言名字
    local loacle = platform_manager:GetLocale()
    if rival_info["leader_name_"..loacle] then
        self.name_text:setString(rival_info["leader_name_"..loacle])
    else
        self.name_text:setString(rival_info.leader_name)
    end
    
    self.bp_text:setString(rival_info.battle_point)

    if not rival_info.user_id then
        self.friend_btn:setVisible(false)
    else
        local has_friend = social_logic:HasFriend(rival_info.user_id)
        self.friend_btn:setVisible(not has_friend)
    end

    if rival_info.state then
        --挑战成功
        self.challenge_btn:setVisible(false)
        self.win_icon_img:setVisible(true)
        self.friend_btn:setPosition(self.challenge_btn:getPosition())
        self.bg_img:setColor(panel_util:GetColor4B(0xe9fe9e))

    else
        self.friend_btn:setPosition(self.friend_btn_pos_x, self.friend_btn_pos_y)
        self.win_icon_img:setVisible(false)
        self.challenge_btn:setVisible(true)
        self.bg_img:setColor(panel_util:GetColor4B(0xffffff))
    end
    self.user_id = rival_info.user_id

    if self.gonghui_bg then
        self.gonghui_bg:setVisible(false)
    end
    if self.deac_gonghui then
        self.deac_gonghui:setString("")
        self.deac_gonghui:setVisible(false)
    end
    
end

------------------------
local arena_main_panel = panel_prototype.New(true)
function arena_main_panel:Init()
    self.root_node = (require "util.helper"):Loader("ui/arena_main_panel.csb")
    local root_node = self.root_node

    local top_node = root_node:getChildByName("title_bg")
    self.challenge_num_text = top_node:getChildByName("challenge_num")
    self.challenge_bg_img = top_node:getChildByName("challenge_bg")
    self.challenge_bg_img:setTouchEnabled(true)
    --连胜奖励img
    self.reward_icon_imgs= {}
    for i = 1, REWARD_COUNT do
        local reward_icon = top_node:getChildByName("reward_icon" .. i)
        self.reward_icon_imgs[i] = reward_icon
        reward_icon:setColor(panel_util:GetColor4B(0xf7f7f7))
    end

    --胜利次数img
    self.win_times_imgs = {}
    for i = 1, RIVAL_NUM do
        local win_times_img = top_node:getChildByName("win" .. i)
        win_times_img:setVisible(false)
        self.win_times_imgs[i] = win_times_img
    end
    self.list_view = root_node:getChildByName("list_view")

    --文本加描边
    self.reward1_1x_txt = top_node:getChildByName("reward1_1x_txt")
    self.reward1_win_txt = top_node:getChildByName("reward1_win_txt")
    self.reward2_4x_txt = top_node:getChildByName("reward2_4x_txt")
    self.reward2_win_txt = top_node:getChildByName("reward2_win_txt")
    self.reward3_9x_txt_0 = top_node:getChildByName("reward3_9x_txt_0")
    self.reward3_win_txt = top_node:getChildByName("reward3_win_txt")

    if self.reward1_1x_txt then
        panel_util:SetTextOutline(self.reward1_1x_txt)
    end
    if self.reward1_win_txt then
        panel_util:SetTextOutline(self.reward1_win_txt)
    end
    if self.reward2_4x_txt then
        panel_util:SetTextOutline(self.reward2_4x_txt)
    end
    if self.reward2_win_txt then
        panel_util:SetTextOutline(self.reward2_win_txt)
    end
    if self.reward3_9x_txt_0 then
        panel_util:SetTextOutline(self.reward3_9x_txt_0)
    end
    if self.reward3_win_txt then
        panel_util:SetTextOutline(self.reward3_win_txt)
    end

    --对手
    self.rival_sub_panels = {}
    local template = root_node:getChildByName("template")

    -- [PC PORT] The CSB ListView fails to lay out its items on this 3.4
    -- runtime (all rows stay at the template position, so most rivals are
    -- missing and drags do nothing).  Rebuild the column on a plain
    -- ScrollView, which works after the anchor fix.
    self.list_view:setVisible(false)
    self.rival_scroll = ccui.ScrollView:create()
    -- 列表视口避开顶部连胜栏和底部按钮；滚动内容会从连胜栏后面穿过。
    self.rival_scroll:setContentSize(cc.size(640, 760))
    self.rival_scroll:setAnchorPoint(cc.p(0, 0))
    self.rival_scroll:setPosition(cc.p(0, 210))
    self.rival_scroll:setBounceEnabled(true)
    self.rival_scroll:setClippingEnabled(false)
    root_node:addChild(self.rival_scroll)
    -- 顶部连胜栏必须压在列表上方，否则滚动的行会盖住它。
    top_node:setLocalZOrder(20)

    local row_size = template:getContentSize()
    self.rival_row_height = row_size.height + 20
    local content_height = self.rival_row_height * RIVAL_NUM

    local inner = self.rival_scroll:getInnerContainer()
    for i = 1, RIVAL_NUM do
        local sub_panel = rival_info_sub_panel.New()
        sub_panel:Init(template:clone(), i)
        sub_panel:Show()

        self.rival_sub_panels[i] = sub_panel

        sub_panel.root_node:setPosition(
            320,
            content_height - (i - 1) * self.rival_row_height - row_size.height / 2)
        if sub_panel.root_node.setPropagateTouchEvents then
            sub_panel.root_node:setPropagateTouchEvents(true)
        end
        inner:addChild(sub_panel.root_node)
    end

    self.rival_scroll:setInnerContainerSize(cc.size(640, content_height))

    -- Keep the bottom actions above the list so its last row cannot swallow
    -- taps on 兑换奖励/阵容排列/返回.
    for _, name in ipairs({ "back_btn", "exchange_reward_btn", "formation_btn",
        "refresh_btn", "look_rule_btn" }) do
        local node = root_node:getChildByName(name)
        if node then
            node:setLocalZOrder(5)
        end
    end

    template:setVisible(false)

    self.refresh_btn = root_node:getChildByName("refresh_btn")
    self.refresh_time_text = self.refresh_btn:getChildByName("time")
    self.formation_btn = root_node:getChildByName("formation_btn")
    
    --刷新开关要通过gm开关控制
    self:ShowRefreshBtn()
    self:BuildBpRangeButton()

    self:RegisterEvent()
    self:RegisterWidgetEvent()
end

-- [MOD r10.5] 底部「挑战次数」与「名单刷新」之间居中放置原生 1A 金色「战力 + 倍率」按钮，并支持幂等自检防消失
function arena_main_panel:BuildBpRangeButton()
    if self.bp_range_btn and not tolua.isnull(self.bp_range_btn) then
        self.bp_range_btn:setVisible(true)
        self.bp_range_btn:setTouchEnabled(true)
        self.bp_range_btn:setLocalZOrder(25)
        return
    end
    self.bp_range_btn = nil
    self.bp_range_lbl = nil
    if not self.root_node or tolua.isnull(self.root_node) then
        return
    end
    local ry = 252.2
    if self.refresh_btn and not tolua.isnull(self.refresh_btn) then
        local _, y = self.refresh_btn:getPosition()
        if y and y > 0 then
            ry = y
        end
    end
    local btn_w, btn_h = 114, 56
    -- 底部排布：[i](9..93) | 挑战次数(77..200) | 【居中空位 221..335 (x=278)】 | 名单刷新(352..623)
    local target_x = 278
    local target_y = ry

    local btn = pixel_kit:CreateButton({
        style = "gold",
        size = cc.size(btn_w, btn_h),
        pos = cc.p(target_x, target_y),
        title = "",
        on_click = function()
            self:ShowBpRangeDialog()
        end,
    })

    local icon_frame = CheckTextureCache("icon/resource/bp_header.png")
    if icon_frame and icon_frame ~= "" then
        local icon = ccui.ImageView:create(icon_frame, ccui.TextureResType.plistType)
        icon:setScale(0.56)
        icon:setPosition(30, 38)
        btn:addChild(icon, 2)
    end

    local title_lbl = pixel_kit:CreateLabel("战力", {
        font_size = 16,
        color = 0x1f1608,
        pos = cc.p(68, 38),
        outline = false,
    })
    btn:addChild(title_lbl, 3)

    local range_lbl = pixel_kit:CreateLabel(arena_logic:GetBpRangeLabel(), {
        font_size = 15,
        color = 0x5c2f08,
        pos = cc.p(btn_w * 0.5, 16),
        outline = false,
    })
    btn:addChild(range_lbl, 3)

    self.root_node:addChild(btn, 25)
    self.bp_range_btn = btn
    self.bp_range_lbl = range_lbl
end

function arena_main_panel:UpdateBpRangeBadge()
    self:BuildBpRangeButton()
    if self.bp_range_lbl and not tolua.isnull(self.bp_range_lbl) then
        self.bp_range_lbl:setString(arena_logic:GetBpRangeLabel())
    end
end

function arena_main_panel:ShowBpRangeDialog()
    if self.bp_range_dlg and self.bp_range_dlg.Close then
        self.bp_range_dlg:Close()
        self.bp_range_dlg = nil
    end

    local cur_min, cur_max = arena_logic:GetBpRange()
    local dlg = pixel_kit:CreateDialog(self.root_node, {
        title = "对手战力范围设置",
        width = 576,
        height = 556,
        z_order = 210,
        on_close = function()
            self.bp_range_dlg = nil
        end,
    })
    self.bp_range_dlg = dlg
    local inner = dlg.inner
    local iw = dlg.inner_w
    local top_y = dlg.content_top

    -- 1A 原生羊皮纸内卡
    local paper_h = top_y - 72
    pixel_kit:CreatePaperCard(inner, {
        width = iw,
        height = paper_h,
        pos = cc.p(iw * 0.5, 68 + paper_h * 0.5),
        z_order = 1,
    })

    local desc = pixel_kit:CreateLabel(
        "按我方当前阵容战力倍率随机匹配对手（0.1 ~ 100 倍）\n保存后立即免费刷新未击败对手，保留当前连胜与次数",
        {
            font_size = 16,
            color = 0x5b4827,
            align = cc.TEXT_ALIGNMENT_CENTER,
            pos = cc.p(iw * 0.5, top_y - 38),
            outline = false,
        }
    )
    inner:addChild(desc, 2)

    local function fmtMult(v)
        v = math.floor(v * 10 + 0.5) / 10
        if v == math.floor(v) then
            return tostring(math.floor(v))
        end
        return string.format("%.1f", v)
    end
    local function readNum(tf, fallback)
        local raw = string.gsub(tf:getString() or "", "[^%d%.]", "")
        return tonumber(raw) or fallback
    end

    local min_step, max_step
    inner:addChild(pixel_kit:CreateLabel("最低倍率 (x)", {
        font_size = 17,
        color = 0x5d3b0b,
        pos = cc.p(iw * 0.25, top_y - 84),
        outline = false,
    }), 2)
    min_step = pixel_kit:CreateStepper(inner, {
        pos = cc.p(iw * 0.25, top_y - 122),
        height = 46,
        btn_width = 46,
        box_width = 96,
        gap = 6,
        value = fmtMult(cur_min),
        placeholder = "0.1~100",
        max_length = 5,
        on_minus = function(tf)
            local lo = math.max(0.1, readNum(tf, 1.0) - 0.5)
            local hi = readNum(max_step.tf, 20.0)
            if lo > hi then lo = hi end
            tf:setString(fmtMult(lo))
        end,
        on_plus = function(tf)
            local hi = readNum(max_step.tf, 20.0)
            local lo = math.min(hi, readNum(tf, 1.0) + 0.5)
            tf:setString(fmtMult(lo))
        end,
    })

    inner:addChild(pixel_kit:CreateLabel("～", {
        font_size = 24,
        color = 0x5d3b0b,
        pos = cc.p(iw * 0.5, top_y - 122),
        outline = false,
    }), 2)

    inner:addChild(pixel_kit:CreateLabel("最高倍率 (x)", {
        font_size = 17,
        color = 0x5d3b0b,
        pos = cc.p(iw * 0.75, top_y - 84),
        outline = false,
    }), 2)
    max_step = pixel_kit:CreateStepper(inner, {
        pos = cc.p(iw * 0.75, top_y - 122),
        height = 46,
        btn_width = 46,
        box_width = 96,
        gap = 6,
        value = fmtMult(cur_max),
        placeholder = "0.1~100",
        max_length = 5,
        on_minus = function(tf)
            local lo = readNum(min_step.tf, 1.0)
            local hi = math.max(lo, readNum(tf, 20.0) - 1.0)
            tf:setString(fmtMult(hi))
        end,
        on_plus = function(tf)
            local hi = math.min(100.0, readNum(tf, 20.0) + 1.0)
            tf:setString(fmtMult(hi))
        end,
    })
    local min_tf = min_step.tf
    local max_tf = max_step.tf

    -- 快捷预设档（2 排同形等高原生像素按钮）
    local preset_title = pixel_kit:CreateLabel("快捷档位（点选即填入）", {
        font_size = 17,
        color = 0x5d3b0b,
        pos = cc.p(iw * 0.5, top_y - 174),
        outline = false,
    })
    inner:addChild(preset_title, 2)

    local presets = {
        { label = "轻松 0.5~1x",   lo = 0.5, hi = 1.0,  style = "green" },
        { label = "均势 0.8~1.5x", lo = 0.8, hi = 1.5,  style = "gold" },
        { label = "挑战 1~5x",     lo = 1.0, hi = 5.0,  style = "gold" },
        { label = "默认 1~20x",    lo = 1.0, hi = 20.0, style = "grey" },
        { label = "极限 5~50x",    lo = 5.0, hi = 50.0, style = "orange" },
    }
    for idx, p in ipairs(presets) do
        local row = (idx <= 3) and 1 or 2
        local col = (row == 1) and idx or (idx - 3)
        local cx = (row == 1) and (iw * 0.5 + (col - 2) * 154) or (iw * 0.5 + (col - 1.5) * 184)
        local cy = (row == 1) and (top_y - 218) or (top_y - 272)
        local bw = (row == 1) and 144 or 168
        local pbtn = pixel_kit:CreateButton({
            style = p.style,
            title = p.label,
            font_size = 17,
            size = cc.size(bw, 44),
            pos = cc.p(cx, cy),
            on_click = function()
                min_tf:setString(fmtMult(p.lo))
                max_tf:setString(fmtMult(p.hi))
            end,
        })
        inner:addChild(pbtn, 3)
    end

    -- 底部操作按钮：恢复默认 / 保存并刷新（同形同高对称）
    local reset_btn = pixel_kit:CreateButton({
        style = "grey",
        title = "恢复默认",
        font_size = 21,
        size = cc.size(172, 52),
        pos = cc.p(iw * 0.28, 30),
        on_click = function()
            min_tf:setString("1")
            max_tf:setString("20")
        end,
    })
    inner:addChild(reset_btn, 3)

    local save_btn = pixel_kit:CreateButton({
        style = "green",
        title = "保存并刷新",
        font_size = 22,
        size = cc.size(196, 52),
        pos = cc.p(iw * 0.70, 30),
        on_click = function()
            local raw_lo = string.gsub(min_tf:getString() or "", "[^%d%.]", "")
            local raw_hi = string.gsub(max_tf:getString() or "", "[^%d%.]", "")
            local lo, hi = arena_logic:NormalizeBpRange(tonumber(raw_lo) or 1.0, tonumber(raw_hi) or 20.0)
            arena_logic:SetBpRange(lo, hi)
            self:UpdateBpRangeBadge()
            dlg:Close()
            pixel_kit:ShowToast("竞技场战力范围已设为 " .. arena_logic:GetBpRangeLabel() .. "，未击败对手已免费刷新", 0xa1e01b)
        end,
    })
    inner:addChild(save_btn, 3)
end

function arena_main_panel:ShowRefreshBtn()
    --刷新开关要通过gm开关控制
    if feature_config:IsFeatureOpen("review") then
        self.refresh_btn:setTouchEnabled(false)
        local btn = self.refresh_btn:getChildByName("btn")
        local icon0 = self.refresh_btn:getChildByName("icon0")
        if btn:isVisible() then
            btn:setVisible(false)
            icon0:setVisible(false)
        end
    else
        self.refresh_btn:setTouchEnabled(true)
        local btn = self.refresh_btn:getChildByName("btn")
        local icon0 = self.refresh_btn:getChildByName("icon0")
        if not btn:isVisible() then
            btn:setVisible(true)
            icon0:setVisible(true)
        end
    end
end

function arena_main_panel:Show()
    self.root_node:setVisible(true)
    self:ResetRivalScroll()

    self:ReLoadInfo()
    --  竞技场界面已经完整的显示出来了
    graphic:DispatchEvent("jump_finish",JUMP_CONST["pvp_arena"])
end

function arena_main_panel:ResetRivalScroll()
    local inner = self.rival_scroll:getInnerContainer()
    inner:setPositionY(self.rival_scroll:getContentSize().height - inner:getContentSize().height)
end
function arena_main_panel:ReLoadInfo()
    local win_times = arena_logic.win_num or 0

    for i = 1, RIVAL_NUM do
        self.rival_sub_panels[i]:ReLoadInfo()

        if i <= win_times then
            self.win_times_imgs[i]:setVisible(true)
        else
            self.win_times_imgs[i]:setVisible(false)
        end
    end

    self.challenge_num_text:setString(arena_logic.challenge_num)
    self.duration = time_logic:GetDurationToFixedTime(arena_logic.refresh_time)
    self:UpdateBpRangeBadge()
end

--检查连胜奖励是否获取
function arena_main_panel:CheckRewardIsGet()
    local win_times = arena_logic.win_num
    local color  = panel_util:GetColor4B(0xffffff)

    for i = 1, REWARD_COUNT do
        self.reward_icon_imgs[i]:setColor(panel_util:GetColor4B(0xf7f7f7))
        --领取奖励的条件 胜利次数达到1， 4 ，9
        local take_reward_win_times = i * i

        --领取奖励的btn状态和icon的状态
        if win_times >= take_reward_win_times then
            self.reward_icon_imgs[i]:setColor(color)
        end
    end
end

function arena_main_panel:Update(elapsed_time)
    self.duration = self.duration or 0
    self.duration = self.duration - elapsed_time
    --时间到了则重新请求数据
    if self.duration <= 0 then
        self.duration = 0
    end

    self.refresh_time_text:setString(panel_util:GetTimeStr(self.duration))
end

function arena_main_panel:RegisterEvent()
    --挑战
    graphic:RegisterEvent("arena_challenge_result", function(result)

        if not self.root_node:isVisible() then
            return
        end

        self.challenge_num_text:setString(arena_logic.challenge_num)
        if result == "success" then
            local challenge_pos = arena_logic.challenge_rival_pos

            local sub_panel = self.rival_sub_panels[challenge_pos]
            sub_panel:ReLoadInfo()

            local win_times = arena_logic.win_num

            if self.win_times_imgs[win_times] then
                self.win_times_imgs[win_times]:setVisible(true)
            else
                assert(false, "win_num " .. tostring(win_times))
            end

            self:CheckRewardIsGet()
        end
    end)

    --刷新竞技场
    graphic:RegisterEvent("arena_refresh_rival", function(result)
        if not self.root_node:isVisible() then
            return
        end

        self:ResetRivalScroll()
        self:ReLoadInfo()
    end)

    --刷新连胜奖励
    graphic:RegisterEvent("arena_take_prize", function(result)
        if not self.root_node:isVisible() then
            return
        end
        self:CheckRewardIsGet()
    end)

    --邀请好友
    graphic:RegisterEvent("invite_player", function(player)
        if not self.root_node:isVisible() then
            return
        end

        --self.social_sub_msgbox[mode]:Show()
    end)

    --搜索结果
    graphic:RegisterEvent("search_player_result", function(result, player)
        if not self.root_node:isVisible() then
            return
        end

        if not player then
            return
        end
        graphic:DispatchEvent("show_world_sub_panel", "social_msgbox", client_constants.SOCIAL_MSGBOX_TYPE["invite_player_msgbox"], player)
    end)

    --gm工具开关控制
    graphic:RegisterEvent("update_feature_config", function()
        self:ShowRefreshBtn()
    end)

    graphic:RegisterEvent("arena_bp_range_updated", function()
        self:UpdateBpRangeBadge()
    end)
end

function arena_main_panel:RegisterWidgetEvent()
    --返回
    self.root_node:getChildByName("back_btn"):addTouchEventListener(function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            graphic:DispatchEvent("show_world_sub_scene", "pvp_sub_scene")
        end
    end)

    --查看奖品规则
    self.root_node:getChildByName("look_rule_btn"):addTouchEventListener(function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            graphic:DispatchEvent("show_world_sub_panel", "arena_rule_msgbox")
        end
    end)

    --刷新
    self.refresh_btn:addTouchEventListener(function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            local mode = client_constants["CONFIRM_MSGBOX_MODE"]["refresh_arena"]
            graphic:DispatchEvent("show_world_sub_panel", "confirm_msgbox", mode)
        end
    end)

    --兑换奖励
    self.root_node:getChildByName("exchange_reward_btn"):addTouchEventListener(function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            arena_logic:QueryExchangeConfig()
        end
    end)

    self.challenge_bg_img:addTouchEventListener(function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")

            if not vip_logic:IsActivated(constants.VIP_TYPE["adventure"]) then
                --月卡购买界面
                graphic:DispatchEvent("show_simple_msgbox", lang_constants:Get("buy_vip_title"),
                    lang_constants:Get("arena_times_desc"),
                    lang_constants:Get("common_confirm"),
                    lang_constants:Get("common_cancel"),
                    function()
                        graphic:DispatchEvent("show_world_sub_panel", "store_shopnew_vip_panel",1,1)
                end)
            end
        end
    end)

    --阵容切换
    self.formation_btn:addTouchEventListener(function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            local trans_type = constants["SCENE_TRANSITION_TYPE"]["none"]
            local mode = client_constants["FORMATION_PANEL_MODE"]["multi"]
            local back_panel = self:GetName()
            graphic:DispatchEvent("show_world_sub_scene", "formation_sub_scene", trans_type, mode, back_panel)
        end
    end)

    --挑战和加好友
    self.challenge_method = function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            local i = widget:getTag()
            arena_logic:ChallengeRival(i)
        end
    end

    self.friend_method = function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            local i = widget:getTag()
            local user_id = self.rival_sub_panels[i].user_id

            social_logic:SearchFriend(user_id)
        end
    end

    for i = 1, RIVAL_NUM do
        self.rival_sub_panels[i].friend_btn:addTouchEventListener(self.friend_method)
        self.rival_sub_panels[i].challenge_btn:addTouchEventListener(self.challenge_method)
    end

end



return arena_main_panel
