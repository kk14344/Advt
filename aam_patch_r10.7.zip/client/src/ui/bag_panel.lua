local config_manager = require "logic.config_manager"
local graphic = require "logic.graphic"
local panel_prototype = require "ui.panel"
local panel_util = require "ui.panel_util"
local single_reward_panel = require "ui.single_reward_panel"

local resource_logic = require "logic.resource"
local bag_logic = require "logic.bag"
local reward_logic = require "logic.reward"

local resource_config = config_manager.resource_config

local constants = require "util.constants"
local client_constants = require "util.client_constants"
local RESOURCE_SHOW_BAG_TYPE_NAME = client_constants["RESOURCE_SHOW_BAG_TYPE_NAME"]

local platform_manager = require "logic.platform_manager"

local spine_manager = require "util.spine_manager"
local spine_node_tracker = require "util.spine_node_tracker"

local REWARD_TYPE = constants.REWARD_TYPE
local RESOURCE_TYPE = constants.RESOURCE_TYPE
local ITEM_RULE = constants.ITEM_RULE

local TEXT_QUALITY_COLOR = client_constants["TEXT_QUALITY_COLOR"]
local BG_QUALITY_COLOR = client_constants["BG_QUALITY_COLOR"]
local BIG_QUALITY_BG_IMG_PATH = client_constants["MERCENARY_BG_SPRITE"]

local audio_manager = require "util.audio_manager"
local reuse_scrollview = require "widget.reuse_scrollview"
local helper = require "util.helper"
local pixel_kit = require "ui.pixel_kit"

local MAX_ROW, MAX_COL = 6, 6
local SUB_PANEL_HEIGHT = 88
local FIRST_SUB_PANEL_OFFSET = -55

local BAG_EMPTY_BG = "bg/bag_emtpybg.png"
local BAG_BG = "bg/activity_herobg.png"

local EXP_ICON = "icon/resource/exp_header.png"
local BP_ICON = "icon/resource/bp_header.png"
local PICKAGE_ICON = "icon/global/ore_picks.png"

local TAB_TYPE = {
    ["item"] = 1,
    ["resource"] = 2
}

local PLIST_TYPE = ccui.TextureResType.plistType

local ITEM_STATUS = {
    ["have_item"] = 1,
    ["unlock_but_no_item"] = 2,
    ["show_lock_text"] = 3,
    ["lock"] = 4
}

local detail_info_sub_panel = panel_prototype.New()
function detail_info_sub_panel:Init(root_node)
    self.root_node = root_node

    self.have_item_node = root_node:getChildByName("have_item_node")
    self.no_item_desc_text = root_node:getChildByName("no_item_desc")

    self.bg_img = self.have_item_node:getChildByName("item_bg")
    self.icon_img = self.have_item_node:getChildByName("item_icon")
    self.name_text = self.have_item_node:getChildByName("item_name")
    self.icon_img:ignoreContentAdaptWithSize(true)

    self.use_btn = self.have_item_node:getChildByName("use_btn")
    self.use_btn1 = self.have_item_node:getChildByName("use_btn_1")
    self.use_btn_yijian = self.have_item_node:getChildByName("yijian_btn_1")

    self.use_btn:setVisible(false)

    self.desc_scroll_view = self.have_item_node:getChildByName("desc_list")
    self.desc_text = self.desc_scroll_view:getChildByName("desc")

    helper:AddClick(self.use_btn1, function()
        if self.cur_tab_type ~= TAB_TYPE["item"] then
            return
        end

        local item = bag_logic:GetItemInfo(self.item_id)

        if not item then
            graphic:DispatchEvent("show_prompt_panel", "bag_item_not_exist")
            return
        end

        if item.template_info.rule_type == ITEM_RULE["refresh_mining"] then
            graphic:DispatchEvent("show_world_sub_panel", "mining_reset_panel", self.item_id)

        elseif item.template_info.rule_type == ITEM_RULE["refresh_temple"] then
            local mode = client_constants.CONFIRM_MSGBOX_MODE["use_item"]
            graphic:DispatchEvent("show_world_sub_panel", "confirm_msgbox", mode, self.item_id)

        else
            bag_logic:UseItem(self.item_id)
        end

    end)

    helper:AddClick(self.use_btn_yijian, function()
        bag_logic:QuickUseItem(self.item_id)
    end)

    helper:AddClick(self.use_btn, function()
        if self.cur_tab_type ~= TAB_TYPE["item"] then
            return
        end

        local item = bag_logic:GetItemInfo(self.item_id)

        if not item then
            graphic:DispatchEvent("show_prompt_panel", "bag_item_not_exist")
            return
        end

        if item.template_info.rule_type == ITEM_RULE["refresh_mining"] then
            graphic:DispatchEvent("show_world_sub_panel", "mining_reset_panel", self.item_id)

        elseif item.template_info.rule_type == ITEM_RULE["refresh_temple"] then
            local mode = client_constants.CONFIRM_MSGBOX_MODE["use_item"]
            graphic:DispatchEvent("show_world_sub_panel", "confirm_msgbox", mode, self.item_id)

        else
            bag_logic:UseItem(self.item_id)
        end

    end)

    self.root_node:setVisible(true)
end

function detail_info_sub_panel:SetCurTabType(tab_type)
    self.cur_tab_type = tab_type

    local is_allow_use = self.cur_tab_type == TAB_TYPE['item']

    self.use_btn1:setVisible(is_allow_use)
    self.use_btn_yijian:setVisible(is_allow_use)

    if is_allow_use then
        self.desc_scroll_view:setContentSize(287, 72)
        self.desc_text:setContentSize(285, 300)
    else
        self.desc_scroll_view:setContentSize(377, 72)
        self.desc_text:setContentSize(375, 300)
    end
end

function detail_info_sub_panel:Show(id)
    if not id or id == 0 then
        self.have_item_node:setVisible(false)
        self.no_item_desc_text:setVisible(true)
        return
    end

    self.have_item_node:setVisible(true)
    self.no_item_desc_text:setVisible(false)

    if self.cur_tab_type == TAB_TYPE["item"] then
        self:ShowItem(id)
    elseif self.cur_tab_type == TAB_TYPE['resource'] then
        self:ShowResource(id)
    end
    self:SetCurTabType(self.cur_tab_type)
end

-- 显示道具
function detail_info_sub_panel:ShowItem(item_id)

    local item = bag_logic:GetItemInfo(item_id)
    if not item then
        return
    end

    self.item_id = item_id

    local quality = item.template_info.quality
    self.name_text:setString(item.template_info.name)
    self.bg_img:loadTexture(CheckTextureCache(client_constants.MERCENARY_BG_SPRITE[quality]), PLIST_TYPE)
    if quality == client_constants["DEFAULT_QUALITY"] then
        self.bg_img:setOpacity(255 * 0.6)
    else
        self.bg_img:setOpacity(255)
    end

    self.icon_img:loadTexture(CheckTextureCache(item.template_info.icon), PLIST_TYPE)
    self.desc_text:setString(item.template_info.desc)
end

-- 显示资源
function detail_info_sub_panel:ShowResource(index)
    local resource_name = constants["RESOURCE_TYPE_NAME"][index]
    if resource_name then
        local template_id = constants['RESOURCE_TYPE'][resource_name]
        local resource_template = resource_config[template_id]
        self.icon_img:loadTexture(CheckTextureCache(resource_template.icon), PLIST_TYPE)
        self.item_id = template_id
        self.name_text:setString(resource_template.name .. "x" .. resource_logic:GetResourcenNumByName(resource_name))
        self.desc_text:setString(resource_template.desc)

        local quality = resource_template["quality"]
        self.bg_img:loadTexture(CheckTextureCache(client_constants.MERCENARY_BG_SPRITE[quality]), PLIST_TYPE)
        if quality == client_constants["DEFAULT_QUALITY"] then
            self.bg_img:setOpacity(255 * 0.6)
        else
            self.bg_img:setOpacity(255)
        end
    else
        print("ShowResource==>", index)
    end
end

local item_sub_panel = panel_prototype.New()
item_sub_panel.__index = item_sub_panel

function item_sub_panel.New()
    return setmetatable({}, item_sub_panel)
end

function item_sub_panel:Init(root_node)
    self.root_node = root_node
    self.icon_img = root_node:getChildByName("item_icon")
    self.lock_icon = root_node:getChildByName("lock_icon")
    self.text_bg_img = root_node:getChildByName("text_bg")
    self.num_text = self.text_bg_img:getChildByName("num")
    self.text_bg_img:setVisible(false)

    self.root_node:setCascadeColorEnabled(false)
    self.root_node:setCascadeOpacityEnabled(true)
end

function item_sub_panel:Load(item_info, status, tab_type)
    self.root_node:setVisible(true)
    self.root_node:setOpacity(255)
    self.lock_icon:setVisible(false)
    self.next_unlock = false

    if tab_type == TAB_TYPE["item"] then
        self:LoadItem(item_info, status)
        -- 叠加道具保留数量显示
        local stack_count = item_info and tonumber(item_info.num) or 1
        if not (stack_count and stack_count > 1) then
            self.text_bg_img:setVisible(false)
        end

    elseif tab_type == TAB_TYPE['resource'] then
        self:LoadResource(item_info, status)
    end
end

-- load 道具
function item_sub_panel:LoadItem(item_info, status)
    if item_info and item_info.template_info then
        self.icon_img:setVisible(true)
        self.icon_img:loadTexture(CheckTextureCache(item_info.template_info.icon), PLIST_TYPE)
        local quality = item_info.template_info.quality or 1

        if quality == client_constants["DEFAULT_QUALITY"] then
            self.root_node:loadTexture(CheckTextureCache(BAG_EMPTY_BG), PLIST_TYPE)
        else
            self.root_node:loadTexture(CheckTextureCache(BAG_BG), PLIST_TYPE)
            self.root_node:setColor(panel_util:GetColor4B(BG_QUALITY_COLOR[quality]))
        end

        self.item_id = item_info.item_id
        -- stack count：可叠加道具显示数量
        local count = tonumber(item_info.num) or 1
        if count > 1 then
            self.text_bg_img:setVisible(true)
            self.num_text:setString(tostring(count))
        else
            self.text_bg_img:setVisible(false)
        end
    else
        self.icon_img:setVisible(false)
        self.root_node:loadTexture(CheckTextureCache(BAG_EMPTY_BG), PLIST_TYPE)
        self.root_node:setColor(panel_util:GetColor4B(client_constants["LIGHT_BLEND_COLOR"]))
        self.item_id = 0
    end

    if status == ITEM_STATUS["show_lock_text"] then
        self.lock_icon:setVisible(true)
        self.next_unlock = true

    elseif status == ITEM_STATUS["lock"] then
        self.root_node:setOpacity(255 * 0.4)
    end
end

-- load资源
function item_sub_panel:LoadResource(resource_name, status)
    if resource_name and resource_logic:GetResourcenNumByName(resource_name) > 0 then
        local template_id = constants['RESOURCE_TYPE'][resource_name]
        local resource_template = resource_config[template_id]
        self.icon_img:loadTexture(CheckTextureCache(resource_template.icon), PLIST_TYPE)
        self.icon_img:setVisible(true)
        self.item_id = template_id
        self.num_text:setString(resource_logic:GetResourcenNumByName(resource_name))

        local quality = resource_template["quality"]
        if quality == client_constants["DEFAULT_QUALITY"] then
            self.root_node:loadTexture(CheckTextureCache(BAG_EMPTY_BG), PLIST_TYPE)
        else
            self.root_node:loadTexture(CheckTextureCache(BAG_BG), PLIST_TYPE)
            self.root_node:setColor(panel_util:GetColor4B(BG_QUALITY_COLOR[quality]))
        end
        self.text_bg_img:setVisible(true)

    else
        self.icon_img:setVisible(false)
        self.root_node:loadTexture(CheckTextureCache(BAG_EMPTY_BG), PLIST_TYPE)
        self.root_node:setColor(panel_util:GetColor4B(client_constants["LIGHT_BLEND_COLOR"]))
        self.text_bg_img:setVisible(false)
        self.item_id = 0
    end
end

local bag_panel = panel_prototype.New(true)
function bag_panel:Init()
    self.root_node = (require "util.helper"):Loader("ui/bag_panel.csb")
    local root_node = self.root_node
    detail_info_sub_panel:Init(root_node:getChildByName("item_explain"))

    self.item_tab_btn = root_node:getChildByName("item_tab")
    self.item_tab_btn:setTag(1)
    self.resource_tab_btn = root_node:getChildByName("res_tab")
    self.resource_tab_btn:setTag(2)

    self.template = root_node:getChildByName("bag_template")
    self.template:setVisible(false)

    self.scroll_view = root_node:getChildByName("scroll_view")

    self.reward_node = root_node:getChildByName("reward")
    self.reward_panel = single_reward_panel.New()
    self.reward_panel:Init(self.reward_node)

    self.root_node:getChildByName("close_btn"):setLocalZOrder(102)

    -- [MOD] 道具背包新增「全部使用」按钮（原生 1A 统一绿键，居中置于底部边框正中）
    do
        local sv_box = self.scroll_view:getBoundingBox()
        local btn_x = sv_box.x + sv_box.width * 0.5
        local btn_y = math.max(150, sv_box.y - 24)
        self.use_all_btn = pixel_kit:CreateButton({
            style = "green",
            title = "全部使用",
            font_size = 22,
            size = cc.size(184, 48),
            pos = cc.p(btn_x, btn_y),
            on_click = function()
                local total = bag_logic:CountAllUsableItems()
                if total <= 0 then
                    graphic:DispatchEvent("show_prompt_panel", "背包内暂无可自动使用的道具")
                    return
                end
                graphic:DispatchEvent("show_simple_msgbox", "全部使用确认",
                    string.format("确认一键使用背包中全部可开启道具（共 %d 个）？\n（将自动跳过矿区刷新、神像、月卡等特殊道具，并先开资源/抵扣券再开佣兵包）", total),
                    "全部使用", "取消",
                    function()
                        bag_logic:UseAllItems()
                    end, function()
                    end)
            end,
        })
        self.root_node:addChild(self.use_all_btn, 102)
    end
    self.select_spine = spine_manager:GetNode("item_skill_choose")
    self.scroll_view:addChild(self.select_spine, 100)
    self.select_spine:setVisible(false)
    self.select_spine:setAnimation(0, "animation", true)

    self.scroll_view:setVisible(true)

    self.duration = 0
    self.cur_capacity_row = 0
    self.item_sub_panels = {}

    self.item_offset, self.sub_panel_row = 0, 0

    self.cur_reward_index, self.reward_num, self.reward_info_list = 1, 0, {}
    self.cur_sub_panel_index = 1

    self.reuse_scrollview = reuse_scrollview.New(self, self.scroll_view, self.item_sub_panels, SUB_PANEL_HEIGHT)
    self.reuse_scrollview:RegisterMethod(function(self)
        return self.parent_panel.cur_capacity_row
    end, function(self, sub_panel, is_up)
        local offset = is_up and self.parent_panel.sub_panel_row or 1
        local pos_y = sub_panel.root_node:getPositionY()
        self.parent_panel:ShowSingleRowItem(self.data_offset + offset, sub_panel, pos_y)
    end)
    self:RegisterEvent()
    self:RegisterWidgetEvent()
end

function bag_panel:CreateSubPanels(row)
    local cur_row = math.min(MAX_ROW, row)
    if self.sub_panel_row >= cur_row then
        return
    end

    local begin_x, interval = 53, 88
    -- 绑定事件
    for row = self.sub_panel_row + 1, cur_row do
        self.item_sub_panels[row] = {}

        for col = 1, MAX_COL do
            local x = begin_x + (col - 1) * interval
            local tag = (row - 1) * MAX_COL + col

            local sub_panel = item_sub_panel.New()
            sub_panel:Init(self.template:clone())
            sub_panel.root_node:setTag(tag)
            sub_panel.root_node:setPositionX(x)

            sub_panel.root_node:setTouchEnabled(true)
            sub_panel.root_node:addTouchEventListener(self.view_bag_content)
            self.scroll_view:addChild(sub_panel.root_node)

            self.item_sub_panels[row][col] = sub_panel
            sub_panel.root_node:setVisible(true)
        end

        self.item_sub_panels[row].root_node = self.item_sub_panels[row][1].root_node
    end

    self.sub_panel_row = cur_row
end

function bag_panel:Show()
    self:UpdateTabStatus(TAB_TYPE['item'])

    self.root_node:setVisible(true)
end

function bag_panel:LoadItems()
    -- body
    self.item_list = bag_logic:GetItemList()
    self.real_capacity, self.bag_level = bag_logic:GetCapacity()

    self.item_num = #self.item_list
    local capacity_row = 0
    if self.real_capacity == constants["MAX_BAG_CAPACITY"] then
        capacity_row = math.ceil(self.real_capacity / MAX_COL)
    else
        capacity_row = math.ceil((self.real_capacity + 1) / MAX_COL)
    end

    self.cur_capacity_row = capacity_row
    self:UpdateItemSubPanels()
end

function bag_panel:LoadResource()

    local item_list = {}
    for k, v in pairs(RESOURCE_SHOW_BAG_TYPE_NAME) do
        if resource_logic:GetResourcenNumByName(v) > 0 then
            table.insert(item_list, v)
        end
    end

    self.item_list = item_list

    self.cur_capacity_row = math.ceil(client_constants["RESOURCE_SHOW_BAG_MAX_NUM"] / MAX_COL)
    self.real_capacity = client_constants["RESOURCE_SHOW_BAG_MAX_NUM"] - 1
    self.item_num = #self.item_list

    self:UpdateItemSubPanels()
end

function bag_panel:UpdateItemSubPanels()

    self:CreateSubPanels(self.cur_capacity_row)

    self.height = math.max(self.cur_capacity_row * SUB_PANEL_HEIGHT, self.reuse_scrollview.sview_height)
    self.cur_sub_panel_index = 1

    local begin_x, interval = 53, 88
    local begin_y = self.height + FIRST_SUB_PANEL_OFFSET

    for row = 1, self.sub_panel_row do
        local y = begin_y - (row - 1) * interval
        self:ShowSingleRowItem(row, self.item_sub_panels[row], y)
    end

    if self.item_num > 0 then
        if self.cur_sub_panel_index > self.item_num then
            self.cur_sub_panel_index = self.item_num
        end

        local row = math.ceil(self.cur_sub_panel_index / MAX_COL)
        local col = self.cur_sub_panel_index - (row - 1) * MAX_COL
        local sub_panel = self.item_sub_panels[row][col]
        detail_info_sub_panel:Show(sub_panel.item_id)

        self:SetSelectBoxPosition()

    else
        detail_info_sub_panel:Show(nil)
        self.select_spine:setVisible(false)
    end

    self.reuse_scrollview:Show(self.height, 0)
end

function bag_panel:ShowSingleRowItem(item_row, sub_row_panel, pos_y)
    for col = 1, MAX_COL do
        local data_index = (item_row - 1) * MAX_COL + col
        local sub_panel = sub_row_panel[col]

        sub_panel.root_node:setVisible(true)

        if data_index <= self.item_num then
            local item = self.item_list[data_index]
            sub_panel:Load(item, ITEM_STATUS["have_item"], self.cur_tab_type)

        elseif data_index <= self.real_capacity then
            sub_panel:Load(nil, ITEM_STATUS["unlock_but_no_item"], self.cur_tab_type)

        elseif data_index == (self.real_capacity + 1) then
            sub_panel:Load(nil, ITEM_STATUS["show_lock_text"], self.cur_tab_type)

        else
            sub_panel:Hide()
        end

        if pos_y then
            sub_panel.root_node:setPositionY(pos_y)
        end
    end
end

function bag_panel:UpdateReward()
    local reward_info = self.reward_info_list[self.cur_reward_index]
    if not reward_info then
        return
    end

    self.cur_reward_index = self.cur_reward_index + 1
    local reward_type = reward_info.id

    local value = reward_info.param2 or reward_info.param1
    local value_str = "+" .. value

    if reward_type == REWARD_TYPE["resource"] then
        local resource_type = reward_info.param1
        self:UpdateSpineNode(resource_config[resource_type]["icon"], value_str)

    elseif reward_type == REWARD_TYPE["leader_bp"] then
        self:UpdateSpineNode(BP_ICON, value_str)

    elseif reward_type == REWARD_TYPE["pickaxe_count"] then
        self:UpdateSpineNode(PICKAGE_ICON, value_str)

    elseif reward_type == REWARD_TYPE["formation_capacity"] then
        self:UpdateSpineNode("icon/item/battle_add.png", "上限→" .. tostring(reward_info.param1 or ""))

    elseif reward_type == REWARD_TYPE["carnival_token"] then
        self:UpdateSpineNode(config_manager.carnival_token_config[reward_info.param1].icon, value_str)

    elseif reward_type == REWARD_TYPE["mercenary"] then
        self.reward_num = 1
        graphic:DispatchEvent("show_world_sub_panel", "reward_panel")
    end

end

function bag_panel:UpdateSpineNode(icon, value_str)
    self.reward_panel:LoadIcon(icon)
    self.reward_panel:SetString(value_str)

    self.reward_panel:ToBindNode()
end

function bag_panel:SetSelectBoxPosition()
    local row = math.ceil(self.cur_sub_panel_index / MAX_COL)
    local col = self.cur_sub_panel_index - (row - 1) * MAX_COL

    local sub_panel = self.item_sub_panels[row][col]

    self.select_spine:setPosition(sub_panel.root_node:getPosition())
    self.select_spine:setVisible(true)
end

function bag_panel:Update(elspsed_time)
    self.reward_panel:Update()

    if not self.reward_panel:IsSpineVisible() and self.cur_reward_index <= self.reward_num then
        self:UpdateReward()
    end
end

function bag_panel:UpdateTabStatus(tab_type)
    self.cur_tab_type = tab_type
    detail_info_sub_panel:SetCurTabType(tab_type)
    if self.use_all_btn then
        self.use_all_btn:setVisible(tab_type == TAB_TYPE["item"])
    end

    if tab_type == TAB_TYPE["item"] then
        self.item_tab_btn:setColor(panel_util:GetColor4B(0xFFFFFF))
        self.item_tab_btn:setLocalZOrder(101)
        self.resource_tab_btn:setColor(panel_util:GetColor4B(0x7F7F7F))
        self.resource_tab_btn:setLocalZOrder(100)

        -- 加载item
        self:LoadItems()

    elseif tab_type == TAB_TYPE["resource"] then
        self.resource_tab_btn:setColor(panel_util:GetColor4B(0xFFFFFF))
        self.resource_tab_btn:setLocalZOrder(101)
        self.item_tab_btn:setColor(panel_util:GetColor4B(0x7F7F7F))
        self.item_tab_btn:setLocalZOrder(100)

        -- 加载resource
        self:LoadResource()
    end
end

function bag_panel:RegisterWidgetEvent()

    local click_tab_method = function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            local index = widget:getTag()
            self:UpdateTabStatus(index)
        end
    end

    self.item_tab_btn:addTouchEventListener(click_tab_method)
    self.resource_tab_btn:addTouchEventListener(click_tab_method)

    self.view_bag_content = function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            local index = widget:getTag()

            local row = math.ceil(index / MAX_COL)
            local col = index - (row - 1) * MAX_COL
            local sub_panel = self.item_sub_panels[row][col]

            if sub_panel.next_unlock then
                local mode = client_constants.CONFIRM_MSGBOX_MODE["upgrade_bag"]
                graphic:DispatchEvent("show_world_sub_panel", "confirm_msgbox", mode)
                return
            end

            self.cur_itme_id = sub_panel.item_id
            if self.cur_itme_id == 0 then
                return
            end

            detail_info_sub_panel:Show(self.cur_itme_id)

            self.cur_sub_panel_index = index
            self:SetSelectBoxPosition()
        end
    end

    panel_util:RegisterCloseMsgbox(self.root_node:getChildByName("close_btn"), "bag_panel")
end

function bag_panel:RegisterEvent()

    graphic:RegisterEvent("update_bag", function()
        if not self.root_node:isVisible() then
            return
        end

        self:Show()
    end)

    -- 使用道具
    graphic:RegisterEvent("use_item_which_in_bag", function(item_id, extra_num, item_template_info)
        if not self.root_node:isVisible() then
            return
        end

        -- [MOD] 一键批量开启进行中：跳过逐个奖励/抽卡弹窗，由 bag_batch_open_done 统一展示结算
        if bag_logic.batch_open_active then
            return
        end

        if not item_template_info then
            return
        end

        if self.cur_tab_type ~= TAB_TYPE['item'] then
            return
        end

        local rule_type = item_template_info.rule_type
        if rule_type == ITEM_RULE["refresh_temple"] then
            graphic:DispatchEvent("show_prompt_panel", "temple_refresh_success")

        elseif rule_type == ITEM_RULE["vip"] or rule_type == ITEM_RULE["refresh_mining"] then

        elseif rule_type == ITEM_RULE["recycle_coolant"] then -- CG
            -- 冷却剂使用成功后的客户端处理
        else
            local reward_info_list = reward_logic:GetRewardInfoList() or {}
            self.reward_num = #reward_info_list
            self.cur_reward_index = 1

            for i, reward_info in ipairs(reward_info_list) do
                self.reward_info_list[i] = reward_info
            end

            self:UpdateReward()
        end

        self.item_list = bag_logic:GetItemList()
        self.item_num = #self.item_list

        -- 第一个item_row 2:sub_panel_row
        for i = 1, self.sub_panel_row do
            local item_row = self.reuse_scrollview:GetDataIndex(i)
            self:ShowSingleRowItem(item_row, self.item_sub_panels[i])
        end

        if self.item_num > 0 then
            local head_sub_panel_index = self.reuse_scrollview.head_sub_panel_index

            if self.item_sub_panels[head_sub_panel_index][1].item_id == 0 then
                self.select_spine:setVisible(false)
                detail_info_sub_panel:Show(nil)

                detail_info_sub_panel.no_item_desc_text:setVisible(false)

            else
                -- 判断是不是最后一个， 下一个的item_id是否为0
                local next_row = math.ceil(self.cur_sub_panel_index / MAX_COL)
                local next_col = self.cur_sub_panel_index - (next_row - 1) * MAX_COL

                if self.item_sub_panels[next_row][next_col].item_id == 0 then
                    self.cur_sub_panel_index = self.cur_sub_panel_index - 1

                    if self.cur_sub_panel_index <= 0 then
                        self.cur_sub_panel_index = MAX_COL * MAX_ROW
                    end
                end

                local row = math.ceil(self.cur_sub_panel_index / MAX_COL)
                local col = self.cur_sub_panel_index - (row - 1) * MAX_COL
                local item_id = self.item_sub_panels[row][col].item_id

                detail_info_sub_panel:Show(item_id)

                self:SetSelectBoxPosition()
                self.select_spine:setVisible(true)
            end

        else
            detail_info_sub_panel:Show(nil, self.cur_tab_type)
            self.select_spine:setVisible(false)
        end
    end)

    -- [MOD] 一键开启批量结算统一汇总弹窗
    graphic:RegisterEvent("bag_batch_open_done", function(summary, stop_reason)
        if not self.root_node:isVisible() or not summary then
            return
        end
        self:ShowBatchSummaryModal(summary, stop_reason)
    end)
end

function bag_panel:ShowBatchSummaryModal(summary, stop_reason)
    local title_prefix = summary.is_use_all and "全部使用结算" or "一键开启结算"
    local dlg = pixel_kit:CreateDialog(self.root_node, {
        title = string.format("%s（共 %d 个）", title_prefix, tonumber(summary.opened_count) or 0),
        width = 580,
        height = 760,
        pos_y = 576,
        z_order = 320,
    })

    local inner = dlg.inner
    local iw = dlg.inner_w
    local top_y = dlg.content_top

    -- 1A 原生羊皮纸内卡容器
    local paper_h = top_y - 76
    local paper_y = 68 + paper_h * 0.5
    pixel_kit:CreatePaperCard(inner, {
        width = iw,
        height = paper_h,
        pos = cc.p(iw * 0.5, paper_y),
        z_order = 1,
    })

    -- 副标题：道具名 + 提前结束提示（如有）
    local sub_text = string.format("已开启：%s ×%d", tostring(summary.template_name or "道具"), tonumber(summary.opened_count) or 0)
    if stop_reason and stop_reason ~= "" then
        sub_text = sub_text .. "　|　" .. tostring(stop_reason)
    end
    local sub_lbl = pixel_kit:CreateLabel(sub_text, {
        font_size = 17,
        color = stop_reason and 0xa63a0e or 0x5b4827,
        pos = cc.p(iw * 0.5, top_y - 26),
        outline = false,
    })
    inner:addChild(sub_lbl, 3)

    -- 整理佣兵列表（按品质降序，再按数量降序，再按 ID）
    local merc_list = {}
    for _, entry in pairs(summary.mercenaries or {}) do
        merc_list[#merc_list + 1] = entry
    end
    table.sort(merc_list, function(a, b)
        if a.quality ~= b.quality then
            return a.quality > b.quality
        end
        if a.count ~= b.count then
            return a.count > b.count
        end
        return a.template_id < b.template_id
    end)

    -- 整理非佣兵汇总条目（资源 / 道具 / 灵魂石 / 战力 / 四维 / 矿镐 / 营帐）
    local misc_lines = {}
    local function fmt_num(n)
        n = tonumber(n) or 0
        if n >= 100000000 then
            return string.format("%.2f亿", n / 100000000)
        elseif n >= 100000 then
            return string.format("%.1f万", n / 10000)
        end
        return tostring(math.floor(n))
    end

    local fd = summary.four_dim or {}
    local fd_names = { "先攻", "防御", "闪避", "王者" }
    local fd_parts = {}
    for i = 1, 4 do
        if (fd[i] or 0) > 0 then
            fd_parts[#fd_parts + 1] = string.format("%s +%s", fd_names[i], fmt_num(fd[i]))
        end
    end
    if #fd_parts > 0 then
        misc_lines[#misc_lines + 1] = { text = "主角四维：" .. table.concat(fd_parts, "  "), color = 0x7c4608 }
    end
    if (summary.leader_bp or 0) > 0 then
        misc_lines[#misc_lines + 1] = { text = "主角战力 +" .. fmt_num(summary.leader_bp), color = 0x7c4608 }
    end
    if (summary.camp_capacity or 0) > 0 then
        misc_lines[#misc_lines + 1] = { text = "佣兵列表上限 +" .. tostring(summary.camp_capacity), color = 0x2f5e11 }
    end
    if (summary.formation_capacity or 0) > 0 then
        misc_lines[#misc_lines + 1] = { text = "出战人数上限提升至 " .. tostring(summary.formation_capacity) .. " 人", color = 0x2f5e11 }
    end
    if (summary.formation_discarded or 0) > 0 then
        misc_lines[#misc_lines + 1] = { text = "已达出战上限，多余出阵+1已自动销毁 ×" .. tostring(summary.formation_discarded), color = 0xa63a0e }
    end
    if (summary.pickaxe_count or 0) > 0 then
        misc_lines[#misc_lines + 1] = { text = "挖掘次数 +" .. tostring(summary.pickaxe_count), color = 0x2f5e11 }
    end

    local res_ids = {}
    for rid in pairs(summary.resources or {}) do res_ids[#res_ids + 1] = rid end
    table.sort(res_ids)
    for _, rid in ipairs(res_ids) do
        local rc = resource_config[rid]
        local name = (rc and rc.name) or ("资源#" .. tostring(rid))
        misc_lines[#misc_lines + 1] = { text = string.format("%s  +%s", name, fmt_num(summary.resources[rid])), color = 0x2b1f0e }
    end

    local item_cfg = config_manager.item_config or {}
    local item_ids = {}
    for iid in pairs(summary.items or {}) do item_ids[#item_ids + 1] = iid end
    table.sort(item_ids)
    for _, iid in ipairs(item_ids) do
        local ic = item_cfg[iid]
        local name = (ic and ic.name) or ("道具#" .. tostring(iid))
        misc_lines[#misc_lines + 1] = { text = string.format("%s  ×%d", name, summary.items[iid]), color = 0x1d4b7a }
    end

    local merc_cfg = config_manager.mercenary_config or {}
    local soul_ids = {}
    for sid in pairs(summary.soul_stones or {}) do soul_ids[#soul_ids + 1] = sid end
    table.sort(soul_ids)
    for _, sid in ipairs(soul_ids) do
        local mc = merc_cfg[sid]
        local name = (mc and mc.name) or ("佣兵#" .. tostring(sid))
        misc_lines[#misc_lines + 1] = { text = string.format("%s 灵魂石  ×%d", name, summary.soul_stones[sid]), color = 0x6a2882 }
    end

    -- 可滚动内容区（透明叠加在羊皮纸内卡中）
    local sv_w = iw - 36
    local sv_h = paper_h - 54
    local sv = ccui.ScrollView:create()
    sv:setDirection(ccui.ScrollViewDir.vertical)
    sv:setBounceEnabled(true)
    sv:setClippingEnabled(true)
    sv:setContentSize(cc.size(sv_w, sv_h))
    sv:setPosition(18, 82)
    inner:addChild(sv, 2)

    local cols = 4
    local cell_w = math.floor(sv_w / cols)
    local cell_h = 122
    local merc_rows = (#merc_list > 0) and math.ceil(#merc_list / cols) or 0
    local merc_header_h = (#merc_list > 0) and 34 or 0
    local misc_header_h = (#misc_lines > 0) and 34 or 0
    local misc_row_h = 30
    local total_h = math.max(sv_h, 12 + merc_header_h + merc_rows * cell_h + misc_header_h + #misc_lines * misc_row_h + 12)
    sv:setInnerContainerSize(cc.size(sv_w, total_h))

    local cur_y = total_h - 8

    if #merc_list > 0 then
        local total_merc_cnt = 0
        for _, m in ipairs(merc_list) do total_merc_cnt = total_merc_cnt + m.count end
        local sec1 = pixel_kit:CreateLabel(string.format("◆ 获得佣兵（共 %d 名，%d 种）", total_merc_cnt, #merc_list), {
            font_size = 19,
            color = 0x5d3b0b,
            anchor = cc.p(0, 1),
            pos = cc.p(6, cur_y),
            outline = false,
        })
        sv:addChild(sec1, 3)
        cur_y = cur_y - merc_header_h

        for idx, m in ipairs(merc_list) do
            local r = math.floor((idx - 1) / cols)
            local c = (idx - 1) % cols
            local cx = c * cell_w + cell_w * 0.5
            local cy = cur_y - r * cell_h - cell_h * 0.5 + 8

            local bg_path = BIG_QUALITY_BG_IMG_PATH[m.quality] or BIG_QUALITY_BG_IMG_PATH[6] or BAG_BG
            local frame_ok, frame = pcall(function()
                return ccui.ImageView:create(CheckTextureCache(bg_path), PLIST_TYPE)
            end)
            if frame_ok and frame then
                frame:setScale(0.82)
                frame:setPosition(cx, cy + 8)
                sv:addChild(frame, 2)
            end

            local role_path = client_constants["MERCENARY_ROLE_IMG_PATH"] .. tostring(m.sprite) .. ".png"
            local av_ok, av = pcall(function()
                return ccui.ImageView:create(CheckTextureCache(role_path), PLIST_TYPE)
            end)
            if av_ok and av then
                av:setContentSize(cc.size(70, 70))
                av:setPosition(cx, cy + 10)
                sv:addChild(av, 3)
            end

            if m.is_new then
                local new_lbl = pixel_kit:CreateLabel("NEW", {
                    font_size = 14,
                    color = 0xffe44d,
                    anchor = cc.p(0, 1),
                    pos = cc.p(cx - 36, cy + 44),
                    outline_size = 2,
                })
                sv:addChild(new_lbl, 5)
            end

            local cnt_lbl = pixel_kit:CreateLabel("×" .. tostring(m.count), {
                font_size = 16,
                color = 0xffffff,
                anchor = cc.p(1, 0),
                pos = cc.p(cx + 36, cy - 26),
                outline_size = 2,
            })
            sv:addChild(cnt_lbl, 5)

            local q_color = TEXT_QUALITY_COLOR[m.quality] or 0xffffff
            if m.quality >= 21 then
                q_color = 0xff80ff
            end
            local name_lbl = pixel_kit:CreateLabel(tostring(m.name), {
                font_size = 15,
                color = q_color,
                pos = cc.p(cx, cy - 42),
                outline_size = 1,
            })
            sv:addChild(name_lbl, 4)
        end
        cur_y = cur_y - merc_rows * cell_h - 8
    end

    if #misc_lines > 0 then
        local sec2 = pixel_kit:CreateLabel("◆ 获得资源与属性", {
            font_size = 19,
            color = 0x2f5e11,
            anchor = cc.p(0, 1),
            pos = cc.p(6, cur_y),
            outline = false,
        })
        sv:addChild(sec2, 3)
        cur_y = cur_y - misc_header_h

        for _, row in ipairs(misc_lines) do
            local lbl = pixel_kit:CreateLabel("• " .. row.text, {
                font_size = 18,
                color = row.color or 0x2b1f0e,
                anchor = cc.p(0, 1),
                pos = cc.p(12, cur_y),
                outline = false,
            })
            sv:addChild(lbl, 3)
            cur_y = cur_y - misc_row_h
        end
    end

    if #merc_list == 0 and #misc_lines == 0 then
        local empty_lbl = pixel_kit:CreateLabel("全部道具已开启完毕", {
            font_size = 20,
            color = 0x5b4827,
            pos = cc.p(sv_w * 0.5, sv_h * 0.5),
            outline = false,
        })
        sv:addChild(empty_lbl, 3)
    end

    local ok_btn = pixel_kit:CreateButton({
        style = "gold",
        title = "确 定",
        font_size = 23,
        size = cc.size(184, 52),
        pos = cc.p(iw * 0.5, 30),
        on_click = function()
            dlg.Close()
        end,
    })
    inner:addChild(ok_btn, 4)
end

return bag_panel
