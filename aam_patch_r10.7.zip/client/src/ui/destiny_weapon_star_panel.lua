local config_manager = require "logic.config_manager"

local constants = require "util.constants"
local client_constants  = require "util.client_constants"

local audio_manager = require "util.audio_manager"
local platform_manager = require "logic.platform_manager"
local graphic = require "logic.graphic"
local troop_logic = require "logic.troop"
local resource_logic = require "logic.resource"
local destiny_logic = require "logic.destiny_weapon"
local store_logic = require "logic.store"
local spine_manager = require "util.spine_manager"
local animation_manager = require "util.animation_manager"

local panel_prototype = require "ui.panel"

local panel_util = require "ui.panel_util"
local pixel_kit = require "ui.pixel_kit"

local lang_constants = require "util.language_constants"
local destiny_skill_config = config_manager.destiny_skill_config

local PLIST_TYPE = ccui.TextureResType.plistType

local weapon_sub_panel = panel_prototype.New()
weapon_sub_panel.__index = weapon_sub_panel
function weapon_sub_panel.New()
    return setmetatable({}, weapon_sub_panel)
end

function weapon_sub_panel:Init(root_node, id)
    self.root_node = root_node
    self.root_node:setCascadeColorEnabled(true)

    self.weapon_icon_img = root_node:getChildByName("icon")
    self.equiped_icon_img = root_node:getChildByName("equiped_icon")
    self.lock_icon_img = root_node:getChildByName("lock")

    self.id = id
end

function weapon_sub_panel:Show()
    local id = self.id
    local config = destiny_skill_config[id]
    self.weapon_icon_img:loadTexture(CheckTextureCache(config.icon), PLIST_TYPE)

    local is_actived = destiny_logic:IsWeaponActived(id)
    self.lock_icon_img:setVisible(not is_actived)

    local is_equiped = troop_logic:IsWeaponEquipped(troop_logic:GetCurFormationId(), id)
    self.equiped_icon_img:setVisible(is_equiped)
    
    if destiny_logic:IsWeaponRainbow(id) then
        self.root_node:loadTexture(CheckTextureCache(client_constants["MERCENARY_BG_SPRITE"][21]), PLIST_TYPE)
    elseif id <= constants["MAX_DESTINY_WEAPON_ID"] then
        self.root_node:loadTexture(CheckTextureCache(client_constants["MERCENARY_BG_SPRITE"][5]), PLIST_TYPE)
    else
        self.root_node:loadTexture(CheckTextureCache(client_constants["MERCENARY_BG_SPRITE"][6]), PLIST_TYPE)
    end
end

function weapon_sub_panel:Selected(is_selected)
    if is_selected then
        self.root_node:setColor(panel_util:GetColor4B(client_constants["LIGHT_BLEND_COLOR"]))
    else
        self.root_node:setColor(panel_util:GetColor4B(client_constants["DARK_BLEND_COLOR"]))
    end
end

local destiny_weapon_star_panel = panel_prototype.New(true)
function destiny_weapon_star_panel:Init()
    cc.SpriteFrameCache:getInstance():addSpriteFrames("role/destiny_ext.plist")
    self.root_node = (require "util.helper"):Loader("ui/leader_weapon_stars_up_panel.csb")
    
    --武器tab
    local weapon_tab_node = self.root_node:getChildByName("weapon_tab")
    self.list_view = weapon_tab_node:getChildByName("list_view")

    -- Same CSB anchor issue as leader_weapon_panel: the ScrollView clip rect
    -- ignores the (0, 0.5) anchor and cuts off the top half of the weapon row.
    local list_anchor = self.list_view:getAnchorPoint()
    if list_anchor.x ~= 0 or list_anchor.y ~= 0 then
        local list_size = self.list_view:getContentSize()
        self.list_view:setAnchorPoint(0, 0)
        self.list_view:setPosition(self.list_view:getPositionX() - list_anchor.x * list_size.width,
            self.list_view:getPositionY() - list_anchor.y * list_size.height)
    end

    local tempalte = self.list_view:getChildByName("weapon_template")

    self.weapon_sub_panels = {}

    --通过关卡获得的武器放在最前面
    for id = 6, constants["MAX_DESTINY_WEAPON_ID"] - 1 do
        local sub_panel = weapon_sub_panel.New()
        if id == 6 then
            sub_panel:Init(tempalte, id)
        else
            sub_panel:Init(tempalte:clone(), id)
            self.list_view:addChild(sub_panel.root_node)
        end
        self.weapon_sub_panels[id] = sub_panel
    end

    for id = 1, 5 do
        local sub_panel = weapon_sub_panel.New()
        sub_panel:Init(tempalte:clone(), id)
        self.list_view:addChild(sub_panel.root_node)
        self.weapon_sub_panels[id] = sub_panel
    end

    local sub_panel = weapon_sub_panel.New()
    sub_panel:Init(tempalte:clone(), constants["MAX_DESTINY_WEAPON_ID"])
    self.list_view:addChild(sub_panel.root_node)
    self.weapon_sub_panels[constants["MAX_DESTINY_WEAPON_ID"]] = sub_panel

    local total_id = constants["TOTAL_DESTINY_WEAPON_ID"] or (constants["MAX_DESTINY_WEAPON_ID"] + 1)
    for id = constants["MAX_DESTINY_WEAPON_ID"] + 1, total_id do
        local super_weapon_panel = weapon_sub_panel.New()
        super_weapon_panel:Init(tempalte:clone(), id)
        self.list_view:addChild(super_weapon_panel.root_node)
        self.weapon_sub_panels[id] = super_weapon_panel
    end

    local skill_bg_img = self.root_node:getChildByName("skill_bg_img")

    local star_panel = skill_bg_img:getChildByName("star")
    self.star_btn_list = {}
    self.star_spine_list = {}
    self.star_light_list = {}
    for i=1,constants["DESTINY_WEAPON_MAX_STAR_LEVEL"] do
        local star_node = star_panel:getChildByName("star" .. i)
        self.star_btn_list[i] = star_node:getChildByName("Button_1")
        self.star_spine_list[i] = spine_manager:GetNode("star_lv", 1.0, true)
        self.star_spine_list[i]:setAnimation(0, "star_loop", true)
        self.star_spine_list[i]:setVisible(false)
        self.star_light_list[i] = star_node:getChildByName("light_1")
        star_node:getChildByName("Node_10"):addChild(self.star_spine_list[i])
    end

    local resource_panel = self.root_node:getChildByName("Node_5")
    self.resource_num_text = resource_panel:getChildByName("Text_85")
    self.add_resource_btn = resource_panel:getChildByName("add_area_btn")

    self.upgrade_once_btn = self.root_node:getChildByName("exchange_reward_btn")
    self.upgrade_auto_btn = self.root_node:getChildByName("formation_btn")
    self.rule_btn = self.root_node:getChildByName("view_info_btn")
    self.close_btn = self.root_node:getChildByName("back_btn")

    self.weapon_info_panel = self.root_node:getChildByName("weapon_info_panel")
    self.weapon_name_text = self.weapon_info_panel:getChildByName("weapon_name")
    self.weapon_icon_img = self.weapon_info_panel:getChildByName("weapon_icon")
    self.weapon_star_level_text = self.weapon_info_panel:getChildByName("weapon_name_0")
    self.weapon_exp_text = skill_bg_img:getChildByName("skill_level_0")
    self.skill_name_text = skill_bg_img:getChildByName("skill_name_0")
    self.skill_desc_sview = skill_bg_img:getChildByName("skill_desc_sview")
    self.skill_desc_text = self.skill_desc_sview:getChildByName("desc")
    self.add_bp_text = skill_bg_img:getChildByName("desc_0")
    panel_util:SetTextOutline(self.weapon_name_text)
    panel_util:SetTextOutline(self.weapon_star_level_text)

    self.weapon_spine = spine_manager:GetNode("lose_light")
    self.weapon_spine:setVisible(false)
    self.weapon_info_panel:getChildByName("Node_22"):addChild(self.weapon_spine)

    self.cost_icon = self.root_node:getChildByName("Image_89")
    self.cost_text = self.root_node:getChildByName("Text_62")
    panel_util:SetTextOutline(self.cost_text)

    local weapon_bg = self.weapon_info_panel:getChildByName("weapon_bg2")

    self.exp_progress = cc.ProgressTimer:create(cc.Sprite:createWithSpriteFrameName("entrust/hoop_exp.png"))
    self.exp_progress:setType(cc.PROGRESS_TIMER_TYPE_RADIAL)
    self.exp_progress:setPosition(weapon_bg:getPosition())
    self.exp_progress:setScale(2)
    self.exp_progress:setPercentage(0)
    self.weapon_info_panel:addChild(self.exp_progress, 10)

    self.weapon_exp_light = self.weapon_info_panel:getChildByName("weapon_bg2_0")
    self.weapon_exp_light:setOpacity(0)
    
    panel_util:SetTextOutline(self.weapon_exp_text)

    self.time_line_action = animation_manager:GetTimeLine("weapon_star_upgrade_timeline")
    self.upgrade_animation_node = (require "util.helper"):Loader("ui/leader_info.csb")
    local pos_x, pos_y = weapon_bg:getPosition()
    self.upgrade_animation_node:setPosition(cc.p(pos_x, pos_y - 90))
    self.weapon_info_panel:addChild(self.upgrade_animation_node, 15)
    self.upgrade_animation_node:runAction(self.time_line_action)
    self.upgrade_animation_node:setVisible(false)

    self.action_exp_text = self.upgrade_animation_node:getChildByName("Text_1")
    self.action_light_img = self.upgrade_animation_node:getChildByName("ban_light1")
    panel_util:SetTextOutline(self.action_exp_text)

    self:BuildRainbowWidgets()

    self:RegisterEvent()
    self:RegisterWidgetEvent()
end

function destiny_weapon_star_panel:BuildRainbowWidgets()
    local font = client_constants["FONT_FACE"]
    local btn_y = self.upgrade_once_btn:getPositionY()

    -- 彩阶预览小按钮（任意星级均可点击预览彩·终极技能）
    local preview_btn = pixel_kit:CreateButton({
        style = "gold",
        title = "彩阶预览",
        size = cc.size(112, 38),
        font_size = 19,
        pos = cc.p(552, self.weapon_star_level_text:getPositionY()),
    })
    self.weapon_info_panel:addChild(preview_btn, 25)
    self.rb_preview_btn = preview_btn

    -- 底部彩虹进阶/满阶/未解锁容器（与原升星按钮同区互斥显示）
    local rb_panel = cc.Node:create()
    rb_panel:setVisible(false)
    self.root_node:addChild(rb_panel, 30)
    self.rainbow_panel = rb_panel

    -- 未解锁提示（#12~#16 未达总星级门槛时显示）
    local lock_text = ccui.Text:create("", font, 24)
    lock_text:setPosition(320, btn_y + 18)
    lock_text:setColor(panel_util:GetColor4B(0xf8b133))
    panel_util:SetTextOutline(lock_text)
    rb_panel:addChild(lock_text)
    self.rb_lock_label = lock_text

    -- 12★ -> 彩虹 简洁消耗提示条（置于左下结晶槽右侧空白区，绝不遮挡战力加成/宿命技）+ 底部进阶按钮
    local res_y = self.root_node:getChildByName("Node_5"):getPositionY()
    local cost_box = ccui.Layout:create()
    cost_box:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
    cost_box:setBackGroundColor(cc.c3b(32, 24, 18))
    cost_box:setBackGroundColorOpacity(210)
    cost_box:setContentSize(cc.size(416, 48))
    cost_box:setAnchorPoint(0.5, 0.5)
    cost_box:setPosition(412, res_y + 4)
    rb_panel:addChild(cost_box)
    self.rb_cost_box = cost_box

    self.rb_cost_labels = {}
    local col_x = { 104, 312, 104, 312 }
    local row_y = { 35, 35, 13, 13 }
    for i = 1, 4 do
        local lbl = ccui.Text:create("", font, 16)
        lbl:setPosition(col_x[i], row_y[i])
        panel_util:SetTextOutline(lbl)
        cost_box:addChild(lbl)
        self.rb_cost_labels[i] = lbl
    end

    local ascend_btn = self.upgrade_once_btn:clone()
    ascend_btn:setPosition(388, btn_y)
    ascend_btn:setTitleText("进阶彩虹")
    ascend_btn:setTitleColor(panel_util:GetColor4B(0xfff4c2))
    ascend_btn:setColor(panel_util:GetColor4B(0xffb84d))
    ascend_btn:setVisible(true)
    rb_panel:addChild(ascend_btn)
    self.rb_ascend_btn = ascend_btn

    -- 已满阶（彩虹品质）徽章
    local max_badge = ccui.Text:create("★ 彩虹品质 · 已满阶 (全队四维 +2) ★", font, 22)
    max_badge:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    max_badge:setPosition(388, btn_y)
    max_badge:setColor(panel_util:GetColor4B(0xffd966))
    panel_util:SetTextOutline(max_badge)
    rb_panel:addChild(max_badge)
    self.rb_max_badge = max_badge
end

function destiny_weapon_star_panel:ShowRainbowConfirmDialog(weapon_id)
    if self.rb_confirm_dlg and self.rb_confirm_dlg.Close then
        self.rb_confirm_dlg:Close()
        self.rb_confirm_dlg = nil
    end

    local weapon_config = destiny_skill_config[weapon_id]
    local rb_lv = constants["DESTINY_WEAPON_RAINBOW_LEVEL"] or 13
    local cur_conf = destiny_logic:GetWeaponStarConf(weapon_id, 12)
    local rb_conf = destiny_logic:GetWeaponStarConf(weapon_id, rb_lv)
    local rb_skill = panel_util:GetSkillInfo(rb_conf and rb_conf.skill_id or 0)
    local costs = destiny_logic:GetRainbowCost(weapon_id)

    local dlg = pixel_kit:CreateDialog(self.root_node, {
        title = "宿命彩虹进阶 · 彩·" .. weapon_config["name"],
        width = 568,
        height = 592,
        z_order = 200,
        on_close = function()
            self.rb_confirm_dlg = nil
        end,
    })
    self.rb_confirm_dlg = dlg
    local inner = dlg.inner
    local iw = dlg.inner_w
    local top_y = dlg.content_top

    local paper_h = top_y - 72
    pixel_kit:CreatePaperCard(inner, {
        width = iw,
        height = paper_h,
        pos = cc.p(iw * 0.5, 68 + paper_h * 0.5),
        z_order = 1,
    })

    local bp_str = string.format("单武器战力：%s  →  %s (×2.0)\n全队四维光环：额外 +2 / +2 / +2 / +2",
        panel_util:ConvertUnit(cur_conf and cur_conf.add_bp or 0),
        panel_util:ConvertUnit(rb_conf and rb_conf.add_bp or 0))
    inner:addChild(pixel_kit:CreateLabel(bp_str, {
        font_size = 19,
        color = 0x2f5e11,
        align = cc.TEXT_ALIGNMENT_CENTER,
        pos = cc.p(iw * 0.5, top_y - 46),
        outline = false,
    }), 2)

    inner:addChild(pixel_kit:CreateLabel("彩·终极技能：" .. (rb_skill and rb_skill.name or ""), {
        font_size = 21,
        color = 0x9a3f0b,
        pos = cc.p(iw * 0.5, top_y - 102),
        outline = false,
    }), 2)

    inner:addChild(pixel_kit:CreateLabel(rb_skill and rb_skill.desc or "", {
        font_size = 18,
        color = 0x3e2f19,
        size = cc.size(iw - 44, 128),
        align = cc.TEXT_ALIGNMENT_LEFT,
        valign = cc.VERTICAL_TEXT_ALIGNMENT_TOP,
        pos = cc.p(iw * 0.5, top_y - 190),
        outline = false,
    }), 2)

    inner:addChild(pixel_kit:CreateLabel("◆ 消耗材料", {
        font_size = 19,
        color = 0x5d3b0b,
        pos = cc.p(iw * 0.5, top_y - 274),
        outline = false,
    }), 2)

    local all_ok = true
    local cx = { iw * 0.27, iw * 0.73, iw * 0.27, iw * 0.73 }
    local cy = { top_y - 314, top_y - 314, top_y - 350, top_y - 350 }
    for i, c in ipairs(costs) do
        local own = resource_logic:GetResourceNum(c.id) or 0
        local ok = own >= c.num
        if not ok then all_ok = false end
        inner:addChild(pixel_kit:CreateLabel(string.format("%s %d/%d", c.name, own, c.num), {
            font_size = 18,
            color = ok and 0x2f5e11 or 0xa83214,
            pos = cc.p(cx[i], cy[i]),
            outline = false,
        }), 2)
    end

    inner:addChild(pixel_kit:CreateButton({
        style = "grey",
        title = "取 消",
        font_size = 22,
        size = cc.size(168, 52),
        pos = cc.p(iw * 0.28, 30),
        on_click = function()
            dlg:Close()
        end,
    }), 3)

    inner:addChild(pixel_kit:CreateButton({
        style = all_ok and "orange" or "grey",
        title = all_ok and "确认进阶" or "材料不足",
        font_size = 22,
        size = cc.size(192, 52),
        pos = cc.p(iw * 0.70, 30),
        on_click = function()
            dlg:Close()
            destiny_logic:AscendToRainbow(weapon_id)
        end,
    }), 3)
end

function destiny_weapon_star_panel:Show(select_weapon_id)
    for _,sub_panel in ipairs(self.weapon_sub_panels) do
        sub_panel:Show()
        sub_panel:Selected(false)
    end
    
    if select_weapon_id then
        self.select_weapon_id = select_weapon_id
    end
    self:ShowWeapon(self.select_weapon_id)
    self.weapon_sub_panels[self.select_weapon_id]:Selected(true)

    self:RefreshResource()

    -- list_view 显示百分比
    local percent = 0
    local sub_percent = 100 / 10
    if self.select_weapon_id >= 8 and self.select_weapon_id <= 10 then
        percent = (self.select_weapon_id - 8) * sub_percent
    elseif self.select_weapon_id >= 12 then
        percent = 100
    elseif self.select_weapon_id == 11 then
        percent = 70
    elseif self.select_weapon_id <= 5 then
        percent = (self.select_weapon_id + 2) * sub_percent
    end
    self.list_view:jumpToPercentHorizontal(percent)

    self.root_node:setVisible(true)
end

function destiny_weapon_star_panel:RefreshResource()
    local fatecrystal = resource_logic:GetResourceNum(constants.RESOURCE_TYPE["fatecrystal"])
    self.resource_num_text:setString(tostring(fatecrystal))
end

function destiny_weapon_star_panel:ShowWeapon(weapon_id, is_upgrade)
    local weapon_star_info = destiny_logic:GetWeaponStarInfo(weapon_id)
    local weapon_star_conf = destiny_logic:GetWeaponStarConf(weapon_star_info.weapon_id, weapon_star_info.star_level)

    self:ShowWeaponExp(weapon_id, weapon_star_conf, weapon_star_info, is_upgrade)
    self:ShowWeaponInfo(weapon_id, weapon_star_conf)
    self:ShowCost(weapon_id, weapon_star_conf)

    destiny_logic.show_animation = false
end

function destiny_weapon_star_panel:ShowCost(weapon_id, weapon_star_conf)
    local is_actived = destiny_logic:IsWeaponActived(weapon_id)
    local max_star = constants["DESTINY_WEAPON_MAX_STAR_LEVEL"] or 12
    local rainbow_lv = constants["DESTINY_WEAPON_RAINBOW_LEVEL"] or 13
    local level = weapon_star_conf.level or 0
    local is_normal = is_actived and (level < max_star)

    self.upgrade_once_btn:setVisible(is_normal)
    self.upgrade_auto_btn:setVisible(is_normal)
    self.cost_icon:setVisible(is_normal)
    self.cost_text:setVisible(is_normal)

    if is_normal then
        self.cost_text:setString(weapon_star_conf.cost_num)
        if self.rainbow_panel then
            self.rainbow_panel:setVisible(false)
        end
        return
    end

    if not self.rainbow_panel then
        return
    end

    self.rainbow_panel:setVisible(true)
    if not is_actived then
        local unlock_map = constants["DESTINY_WEAPON_UNLOCK_STARS"] or {}
        local need_star = unlock_map[weapon_id]
        local total_star = destiny_logic:GetWeaponTotalStarInfo()
        if need_star then
            self.rb_lock_label:setString(string.format("总星级达到 %d★ 自动解锁（当前 %d★）", need_star, total_star))
        else
            self.rb_lock_label:setString("尚未获得该宿命武器")
        end
        self.rb_lock_label:setVisible(true)
        self.rb_cost_box:setVisible(false)
        self.rb_ascend_btn:setVisible(false)
        self.rb_max_badge:setVisible(false)
    elseif level >= rainbow_lv then
        self.rb_lock_label:setVisible(false)
        self.rb_cost_box:setVisible(false)
        self.rb_ascend_btn:setVisible(false)
        self.rb_max_badge:setVisible(true)
    else
        -- level == 12：展示 4 种宿命独立材料消耗 + 进阶彩虹按钮
        self.rb_lock_label:setVisible(false)
        self.rb_max_badge:setVisible(false)
        self.rb_cost_box:setVisible(true)
        self.rb_ascend_btn:setVisible(true)
        local costs = destiny_logic:GetRainbowCost(weapon_id)
        local all_ok = true
        for i = 1, 4 do
            local c = costs[i]
            if c then
                local own = resource_logic:GetResourceNum(c.id) or 0
                local ok = own >= c.num
                if not ok then all_ok = false end
                self.rb_cost_labels[i]:setString(string.format("%s %d/%d", c.name, own, c.num))
                self.rb_cost_labels[i]:setColor(panel_util:GetColor4B(ok and 0xa1e01b or 0xf87f26))
                self.rb_cost_labels[i]:setVisible(true)
            else
                self.rb_cost_labels[i]:setVisible(false)
            end
        end
        self.rb_ascend_btn:setColor(panel_util:GetColor4B(all_ok and 0xffb84d or 0x999999))
    end
end

function destiny_weapon_star_panel:ShowWeaponExp(weapon_id, weapon_star_conf, weapon_star_info, is_upgrade)
    self.exp_progress:stopAllActions()

    local rainbow_lv = constants["DESTINY_WEAPON_RAINBOW_LEVEL"] or 13
    local max_star = constants["DESTINY_WEAPON_MAX_STAR_LEVEL"] or 12
    local show_max_exp = weapon_star_conf.show_max_exp or 0

    if weapon_star_info.star_level >= rainbow_lv then
        self.weapon_exp_text:setString("彩虹品质 · 已满阶")
        self.exp_progress:setPercentage(100)
    elseif show_max_exp <= 0 then
        self.weapon_exp_text:setString("已满星 · 可进阶彩虹")
        self.exp_progress:setPercentage(100)
    else
        self.weapon_exp_text:setString(lang_constants:GetFormattedStr("destiny_weapon_exp", weapon_star_info.exp, show_max_exp))
        self.exp_progress:setPercentage(100 * weapon_star_info.exp / show_max_exp)
    end

    local lit_stars = math.min(weapon_star_info.star_level, max_star)
    for i,star_btn in ipairs(self.star_btn_list) do
        self.star_light_list[i]:setVisible(false)
        self.star_light_list[i]:stopAllActions()
        if i <= lit_stars then
            self.star_spine_list[i]:setVisible(true)
            self.star_spine_list[i]:setToSetupPose()
            if i == weapon_star_info.star_level and is_upgrade then
                self.star_spine_list[i]:setAnimation(0, "star_in", false)
                self.star_spine_list[i]:addAnimation(0, "star_loop", true)

                self.star_spine_list[i]:registerSpineEventHandler(function(event)
                    local animation_name = event.animation
                    if animation_name == "star_in" then
                        graphic:DispatchEvent("show_world_sub_panel", "destiny_weapon_star_info_panel", weapon_id)
                        destiny_logic.show_animation = false
                    end
                end, sp.EventType.ANIMATION_COMPLETE)
            else
                self.star_spine_list[i]:setAnimation(0, "star_loop", true)
            end
        else
            if i == weapon_star_info.star_level + 1 then
                self.star_light_list[i]:setVisible(true)
                self.star_light_list[i]:runAction(cc.RepeatForever:create(cc.Sequence:create(cc.ScaleTo:create(0.5,1.5), cc.ScaleTo:create(1,1.1))))
            end
            self.star_spine_list[i]:setVisible(false)
        end
    end
end

function destiny_weapon_star_panel:ShowWeaponInfo(weapon_id, weapon_star_conf)
    local weapon_config = destiny_skill_config[weapon_id]
    local skill_info = panel_util:GetSkillInfo(weapon_star_conf.skill_id)
    local rainbow_lv = constants["DESTINY_WEAPON_RAINBOW_LEVEL"] or 13
    local is_rb_view = (weapon_star_conf.level or 0) >= rainbow_lv

    if is_rb_view then
        self.weapon_name_text:setString("彩·" .. weapon_config["name"])
        self.weapon_name_text:setColor(panel_util:GetColor4B(0xffd966))
        self.weapon_star_level_text:setString("彩")
        self.weapon_star_level_text:setColor(panel_util:GetColor4B(0xffd966))
    else
        self.weapon_name_text:setString(weapon_config["name"])
        self.weapon_name_text:setColor(panel_util:GetColor4B(0xffffff))
        self.weapon_star_level_text:setString(weapon_star_conf.level)
        self.weapon_star_level_text:setColor(panel_util:GetColor4B(0xffffff))
    end
    self.weapon_icon_img:loadTexture(CheckTextureCache(weapon_config["icon"]), PLIST_TYPE)
    
    self.skill_name_text:setString(string.format(lang_constants:Get("mercenary_destiny_skill_name"), skill_info.name))
    self.skill_desc_text:setString(skill_info.desc)
    self.skill_desc_sview:jumpToTop()

    self.add_bp_text:setString("+" .. panel_util:ConvertUnit(weapon_star_conf.add_bp))

    self.weapon_spine:stopAllActions()
    self.weapon_spine:setColor(cc.c3b(255, 255, 255))
    if weapon_star_conf.level < 4 then
        self.weapon_spine:setVisible(false)
    elseif weapon_star_conf.level < 8 then
        self.weapon_spine:setAnimation(0, "b_light", true)
        self.weapon_spine:setVisible(true)
    elseif weapon_star_conf.level < 12 then
        self.weapon_spine:setAnimation(0, "g_light3", true)
        self.weapon_spine:setVisible(true)
    elseif weapon_star_conf.level < rainbow_lv then
        self.weapon_spine:setAnimation(0, "y_light2", true)
        self.weapon_spine:setVisible(true)
    else
        self.weapon_spine:setAnimation(0, "y_light2", true)
        self.weapon_spine:setVisible(true)
        -- 彩虹品质背后流光循环变色光环
        self.weapon_spine:runAction(cc.RepeatForever:create(cc.Sequence:create(
            cc.TintTo:create(0.7, 255, 120, 180),
            cc.TintTo:create(0.7, 130, 210, 255),
            cc.TintTo:create(0.7, 160, 255, 160),
            cc.TintTo:create(0.7, 255, 225, 110)
        )))
    end

    local weapon_star_info = destiny_logic:GetWeaponStarInfo(weapon_id)
    for i,star_light in ipairs(self.star_light_list) do
        if i == weapon_star_conf.level then
            star_light:setVisible(true)
            star_light:setScale(1.1)
        elseif i ~= weapon_star_info.star_level + 1 then
            star_light:setVisible(false)
        end
    end
end

function destiny_weapon_star_panel:RegisterEvent()
    graphic:RegisterEvent("update_resource_list", function(source)
        if not self.root_node:isVisible() then
            return
        end

        self:RefreshResource()
        if self.select_weapon_id then
            local info = destiny_logic:GetWeaponStarInfo(self.select_weapon_id)
            local conf = destiny_logic:GetWeaponStarConf(info.weapon_id, info.star_level)
            if conf then
                self:ShowCost(self.select_weapon_id, conf)
            end
        end
    end)

    graphic:RegisterEvent("weapon_upgrade_star_success", function(upgrade_info)
        if not self.root_node:isVisible() then
            return
        end

        if self.select_weapon_id ~= upgrade_info.weapon_id then
            return 
        end
        
        local weapon_star_info = destiny_logic:GetWeaponStarInfo(upgrade_info.weapon_id)
        local weapon_star_conf = destiny_logic:GetWeaponStarConf(upgrade_info.weapon_id, upgrade_info.star_level)
        local rainbow_lv = constants["DESTINY_WEAPON_RAINBOW_LEVEL"] or 13
        local is_rainbow_ascend = upgrade_info.is_upgrade and (weapon_star_info.star_level >= rainbow_lv)

        if is_rainbow_ascend then
            self.action_light_img:setVisible(true)
            self.action_exp_text:setString("彩虹进阶!")
            self.action_exp_text:setColor(panel_util:GetColor4B(0xffd966))
            self.upgrade_animation_node:setScale(1.4)
            self.time_line_action:gotoFrameAndPlay(0, 50, false)
            self.upgrade_animation_node:setVisible(true)
            self.weapon_exp_light:runAction(cc.Sequence:create(cc.FadeIn:create(0.35), cc.FadeOut:create(0.35)))
            self.exp_progress:runAction(cc.Sequence:create(
                cc.DelayTime:create(0.45),
                cc.CallFunc:create(function()
                    destiny_logic.show_animation = false
                    for _, sp in ipairs(self.weapon_sub_panels) do
                        sp:Show()
                    end
                    self.weapon_sub_panels[self.select_weapon_id]:Selected(true)
                    self:ShowWeapon(upgrade_info.weapon_id, false)
                    graphic:DispatchEvent("show_world_sub_panel", "destiny_weapon_star_info_panel", upgrade_info.weapon_id)
                end)
            ))
            return
        end

        self.action_light_img:setVisible(upgrade_info.is_crit)
        if upgrade_info.is_crit then
            self.action_exp_text:setString(lang_constants:Get("destiny_weapon_crit") .. "+" .. upgrade_info.upgrade_exp)
            self.action_exp_text:setColor(panel_util:GetColor4B(client_constants["TEXT_COLOR"]["yellow"]))
            self.upgrade_animation_node:setScale(1.5)
        else
            self.action_exp_text:setString("+" .. upgrade_info.upgrade_exp)
            self.action_exp_text:setColor(panel_util:GetColor4B(client_constants["TEXT_COLOR"]["write"]))
            self.upgrade_animation_node:setScale(1)
        end
        self.time_line_action:gotoFrameAndPlay(0, 50, false)
        self.upgrade_animation_node:setVisible(true)

        local show_max = (weapon_star_conf and weapon_star_conf.show_max_exp) or 1
        if show_max <= 0 then show_max = 1 end
        self.exp_progress:runAction(cc.Sequence:create( 
                                                    cc.ProgressTo:create(0.3, 100 * (upgrade_info.exp or 0) / show_max),
                                                    cc.CallFunc:create(function()
                                                        if upgrade_info.is_upgrade then
                                                            self.weapon_exp_light:runAction(cc.Sequence:create(cc.FadeIn:create(0.5),cc.FadeOut:create(0.5)))
                                                        end
                                                    end),
                                                    cc.DelayTime:create(upgrade_info.is_upgrade and 0.5 or 0),
                                                    cc.CallFunc:create(function()
                                                        destiny_logic.show_animation = false
                                                        if upgrade_info.is_upgrade then
                                                            for _, sp in ipairs(self.weapon_sub_panels) do
                                                                sp:Show()
                                                            end
                                                            self.weapon_sub_panels[self.select_weapon_id]:Selected(true)
                                                            self:ShowWeapon(upgrade_info.weapon_id, true)
                                                        elseif upgrade_info.upgrade_type == "auto" or upgrade_info.upgrade_type == 1 then
                                                            destiny_logic:UpgradeStar(upgrade_info.weapon_id, "auto")
                                                        end
                                                    end)
                                                    )
                                )

        self.weapon_exp_text:setString(lang_constants:GetFormattedStr("destiny_weapon_exp", upgrade_info.exp or 0, show_max))
    end)
end

function destiny_weapon_star_panel:RegisterWidgetEvent()
    self.close_btn:addTouchEventListener(function(sender, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            
            graphic:DispatchEvent("hide_world_sub_scene")
        end
    end)

    local view_weapon_info = function (widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            if not destiny_logic.show_animation then
                audio_manager:PlayEffect("click")
                
                self.weapon_sub_panels[self.select_weapon_id]:Selected(false)
                self.select_weapon_id = widget:getTag()
                self:ShowWeapon(self.select_weapon_id)
                self.weapon_sub_panels[self.select_weapon_id]:Selected(true)
            end
        end
    end

    for i,sub_panel in ipairs(self.weapon_sub_panels) do
        local root_node = sub_panel.root_node
        root_node:setTag(i)
        root_node:setTouchEnabled(true)
        root_node:addTouchEventListener(view_weapon_info)
    end

    self.upgrade_once_btn:addTouchEventListener(function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            
            destiny_logic:UpgradeStar(self.select_weapon_id, "once")
        end
    end)

    self.upgrade_auto_btn:addTouchEventListener(function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            
            destiny_logic:UpgradeStar(self.select_weapon_id, "auto")
        end
    end)

    local preview_weapon_info = function (widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            
            local star_level = widget:getTag()
            local weapon_star_conf = destiny_logic:GetWeaponStarConf(self.select_weapon_id, star_level)

            self:ShowWeaponInfo(self.select_weapon_id, weapon_star_conf)
        end
    end

    for i,star_btn in ipairs(self.star_btn_list) do
        star_btn:setTag(i)
        star_btn:setTouchEnabled(true)
        star_btn:addTouchEventListener(preview_weapon_info)
    end

    self.rule_btn:addTouchEventListener(function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            
            graphic:DispatchEvent("show_world_sub_panel", "destiny_weapon_star_rule_panel")
        end
    end)

    self.add_resource_btn:addTouchEventListener(function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            if not destiny_logic.show_animation then
                audio_manager:PlayEffect("click")
                
                local mode = client_constants.BATCH_MSGBOX_MODE.blood_store

                local goods_index = store_logic:GetResourceGoodsIndex(constants["RESOURCE_TYPE"]["fatecrystal"])
                if goods_index then
                    graphic:DispatchEvent("show_world_sub_panel", "store_msgbox", mode, goods_index)
                end
            end
        end
    end)

    self.weapon_icon_img:setTouchEnabled(true)
    self.weapon_icon_img:addTouchEventListener(function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            if not destiny_logic.show_animation then
                audio_manager:PlayEffect("click")

                self:ShowWeapon(self.select_weapon_id)
            end
        end
    end)

    if self.rb_ascend_btn then
        self.rb_ascend_btn:addTouchEventListener(function(widget, event_type)
            if event_type == ccui.TouchEventType.ended then
                if not destiny_logic.show_animation then
                    audio_manager:PlayEffect("click")
                    self:ShowRainbowConfirmDialog(self.select_weapon_id)
                end
            end
        end)
    end

    if self.rb_preview_btn then
        self.rb_preview_btn:addTouchEventListener(function(widget, event_type)
            if event_type == ccui.TouchEventType.ended then
                if not destiny_logic.show_animation then
                    audio_manager:PlayEffect("click")
                    local rb_lv = constants["DESTINY_WEAPON_RAINBOW_LEVEL"] or 13
                    local rb_conf = destiny_logic:GetWeaponStarConf(self.select_weapon_id, rb_lv)
                    if rb_conf then
                        self:ShowWeaponInfo(self.select_weapon_id, rb_conf)
                    end
                end
            end
        end)
    end
end

return destiny_weapon_star_panel
