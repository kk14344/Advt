-- 主界面「建议与问题反馈」1A 原生像素风格弹窗
-- 直接引导跳转玩家至腾讯问卷反馈表（国内三网直连），同时在卡面展示角色名/版本号/阵容战力摘要，
-- 并兼容展示此前本地 feedback_save.json 中的暂存记录。
local network = require "util.network"
local graphic = require "logic.graphic"
local json = require "util.json"
local pixel_kit = require "ui.pixel_kit"
local client_constants = require "util.client_constants"
local troop_logic = require "logic.troop"

local FONT = client_constants["FONT_FACE"]
local FEEDBACK_FORMATION_ID = 200
local CLIENT_PATCH_VER = "r10.7"
local FEEDBACK_FORM_URL = "https://wj.qq.com/s2/28860580/e044/"

local feedback_dialog = {
    dlg = nil,
    registered = false,
    last_state = nil,
}

function feedback_dialog:EnsureEvent()
    if self.registered then
        return
    end
    self.registered = true
    graphic:RegisterEvent("feedback_sync_ret", function(raw_str)
        self:OnServerResponse(raw_str)
    end)
end

function feedback_dialog:GetDiagSummaryText()
    local leader_name = "冒险家"
    local cur_bp = 0
    local team_cnt = 0
    pcall(function()
        if troop_logic.GetLeaderName then
            leader_name = tostring(troop_logic:GetLeaderName() or leader_name)
        end
        if troop_logic.GetTroopBP then
            cur_bp = tonumber(troop_logic:GetTroopBP()) or 0
        end
        if troop_logic.GetFormationMercenaryList then
            local list = troop_logic:GetFormationMercenaryList()
            team_cnt = type(list) == "table" and #list or 0
        end
    end)
    return string.format("当前版本：%s\n角色昵称：%s\n出战人数：%d 人   |   阵容战力：%d",
        CLIENT_PATCH_VER, leader_name, team_cnt, cur_bp)
end

function feedback_dialog:OnServerResponse(raw_str)
    local ok, data = pcall(json.decode, json, tostring(raw_str or ""))
    if not ok or type(data) ~= "table" then
        return
    end
    self.last_state = data
    self:RefreshDynamicViews()
end

function feedback_dialog:RefreshDynamicViews()
    if not self.dlg or tolua.isnull(self.dlg.overlay) then
        return
    end
    local st = self.last_state
    if self.history_lbl and not tolua.isnull(self.history_lbl) then
        local recent = st and st.recent
        if type(recent) == "table" and #recent > 0 then
            local lines = {}
            local st_map = { sent = "已上报", pending = "本地暂存", local_saved = "本地暂存" }
            for i = 1, math.min(3, #recent) do
                local it = recent[i]
                lines[#lines + 1] = string.format("#%d [%s] %s (%s)",
                    tonumber(it.id) or i, tostring(it.cat or ""), tostring(it.txt or ""),
                    st_map[it.st] or tostring(it.st or ""))
            end
            self.history_lbl:setString(table.concat(lines, "\n"))
        else
            self.history_lbl:setString("点击下方「前往填写问卷」即可在浏览器中直接提交，支持上传截图与详细描述。")
        end
    end
end

function feedback_dialog:Show(parent)
    if not parent or tolua.isnull(parent) then
        return
    end
    self:EnsureEvent()
    if self.dlg and not tolua.isnull(self.dlg.overlay) then
        self.dlg.Close()
    end

    local dlg = pixel_kit:CreateDialog(parent, {
        title = "建议与问题反馈",
        width = 566,
        height = 548,
        pos_y = 576,
        z_order = 260,
        on_close = function()
            self.dlg = nil
        end,
    })
    self.dlg = dlg

    local inner = dlg.inner
    local iw = dlg.inner_w
    local top_y = dlg.content_top

    -- 顶部通道说明
    local status_lbl = ccui.Text:create("官方腾讯问卷通道（国内直连秒开 · 作者实时查看）", FONT, 17)
    status_lbl:setPosition(iw * 0.5, top_y - 18)
    status_lbl:setColor(cc.c3b(161, 224, 27))
    inner:addChild(status_lbl)
    self.status_lbl = status_lbl

    -- 羊皮纸说明卡
    local cw = iw - 24
    local card = pixel_kit:CreatePaperCard(inner, {
        width = cw,
        height = 228,
        pos = cc.p(iw * 0.5, top_y - 156),
    })

    local guide_lbl = ccui.Text:create("欢迎反馈 Bug、数值建议或新玩法想法！\n点击下方绿色按钮将跳转至腾讯问卷填写提交：", FONT, 18)
    guide_lbl:setAnchorPoint(0, 1)
    guide_lbl:setPosition(20, 210)
    guide_lbl:setColor(cc.c3b(72, 46, 20))
    guide_lbl:ignoreContentAdaptWithSize(false)
    guide_lbl:setContentSize(cc.size(cw - 40, 52))
    card:addChild(guide_lbl)

    local diag_bg = ccui.Layout:create()
    diag_bg:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
    diag_bg:setBackGroundColor(cc.c3b(44, 32, 22))
    diag_bg:setBackGroundColorOpacity(235)
    diag_bg:setContentSize(cc.size(cw - 36, 102))
    diag_bg:setAnchorPoint(0.5, 0.5)
    diag_bg:setPosition(cw * 0.5, 96)
    card:addChild(diag_bg)

    local diag_lbl = ccui.Text:create(self:GetDiagSummaryText(), FONT, 16)
    diag_lbl:setAnchorPoint(0, 0.5)
    diag_lbl:setPosition(14, 51)
    diag_lbl:setColor(cc.c3b(255, 232, 164))
    diag_lbl:ignoreContentAdaptWithSize(false)
    diag_lbl:setContentSize(cc.size(cw - 64, 84))
    diag_bg:addChild(diag_lbl)

    local url_lbl = ccui.Text:create("问卷地址：" .. FEEDBACK_FORM_URL, FONT, 15)
    url_lbl:setPosition(cw * 0.5, 22)
    url_lbl:setColor(cc.c3b(128, 72, 24))
    card:addChild(url_lbl)

    -- 底部提示 / 历史记录卡
    local hist_bg = ccui.Layout:create()
    hist_bg:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
    hist_bg:setBackGroundColor(cc.c3b(32, 24, 17))
    hist_bg:setBackGroundColorOpacity(210)
    hist_bg:setContentSize(cc.size(iw - 24, 108))
    hist_bg:setAnchorPoint(0.5, 0.5)
    hist_bg:setPosition(iw * 0.5, top_y - 340)
    inner:addChild(hist_bg)

    local hist_title = ccui.Text:create("填写小贴士 / 过往记录：", FONT, 16)
    hist_title:setAnchorPoint(0, 0.5)
    hist_title:setPosition(14, 90)
    hist_title:setColor(cc.c3b(245, 206, 118))
    hist_bg:addChild(hist_title)

    local history_lbl = ccui.Text:create("点击下方「前往填写问卷」即可在浏览器中直接提交。", FONT, 15)
    history_lbl:setAnchorPoint(0, 1)
    history_lbl:setPosition(14, 72)
    history_lbl:setColor(cc.c3b(226, 214, 190))
    history_lbl:ignoreContentAdaptWithSize(false)
    history_lbl:setContentSize(cc.size(iw - 52, 66))
    hist_bg:addChild(history_lbl)
    self.history_lbl = history_lbl

    -- 底部主按钮
    inner:addChild(pixel_kit:CreateButton({
        style = "green",
        title = "前往填写问卷",
        font_size = 21,
        size = cc.size(230, 50),
        pos = cc.p(iw * 0.5 - 114, 34),
        on_click = function()
            pixel_kit:ShowToast("正在打开腾讯问卷反馈页面…", 0xa1e01b)
            pcall(function()
                cc.Application:getInstance():openURL(FEEDBACK_FORM_URL)
            end)
        end,
    }))

    inner:addChild(pixel_kit:CreateButton({
        style = "grey",
        title = "关 闭",
        font_size = 20,
        size = cc.size(160, 50),
        pos = cc.p(iw * 0.5 + 122, 34),
        on_click = function()
            dlg.Close()
        end,
    }))

    self:RefreshDynamicViews()
    network:Send({
        change_formation_name = { formation_id = FEEDBACK_FORMATION_ID, name = "__QUERY__" }
    })
end

return feedback_dialog
