local graphic = require "logic.graphic"
local panel_prototype = require "ui.panel"
local config_manager = require "logic.config_manager"
local audio_manager = require "util.audio_manager"

local constants = require "util.constants"
local client_constants = require "util.client_constants"

local ladder_logic = require "logic.ladder"
local time_logic = require "logic.time"
local troop_logic = require "logic.troop"
local arena_logic = require "logic.arena"

local panel_util = require "ui.panel_util"
local icon_template = require "ui.icon_panel"
local platform_manager = require "logic.platform_manager"

local MAX_RIVAL_NUM = 10
local MAX_CHALLEDGE_CD = 5 * 60

--对手信息的子panel
local rival_info_sub_panel = panel_prototype.New()
rival_info_sub_panel.__index = rival_info_sub_panel

function rival_info_sub_panel.New()
    local t = {}
    return setmetatable(t, rival_info_sub_panel)
end

function rival_info_sub_panel:Init(root_node)
    self.is_rival = is_rival
    self.root_node = root_node

    self.rank_num_text = root_node:getChildByName("rank_value")

    self.bp_text = root_node:getChildByName("bp_value")

    self.name_text = root_node:getChildByName("name")
    self.challenge_btn = root_node:getChildByName("challenge_btn")
    self.challenge_num_text = root_node:getChildByName("challenge_num")

    self.icon_panel = icon_template.New(nil, client_constants["ICON_TEMPLATE_MODE"]["no_text"])
    self.icon_panel:Init(root_node)

    self.gonghui_bg = root_node:getChildByName("gonghui_bg")
    self.deac_gonghui = root_node:getChildByName("deac_gonghui")
    self.bp_icon = root_node:getChildByName("bp_icon")

    -- [MOD r10.5] 永久隐藏单机版空白公会灰条，将战力图标与数值移至排名/ID 下方左对齐
    if self.gonghui_bg then
        self.gonghui_bg:setVisible(false)
    end
    if self.deac_gonghui then
        self.deac_gonghui:setString("")
        self.deac_gonghui:setVisible(false)
    end
    if self.bp_icon then
        self.bp_icon:setPosition(116, 40)
    end
    if self.bp_text then
        self.bp_text:setPosition(134, 40)
    end
end

function rival_info_sub_panel:ReLoadInfo(pos)
    local rival_info = ladder_logic:GetSingleRivalInfo(pos)
    if not rival_info then
        self.root_node:setVisible(false)
        return
    end
    self.root_node:setVisible(true)

    --  多语言名字
    local loacle = platform_manager:GetLocale()
    if rival_info["leader_name_"..loacle] then
        self.name_text:setString(rival_info["leader_name_"..loacle])
    else
        self.name_text:setString(rival_info.leader_name)
    end
    
    self.rank_num_text:setString(rival_info.rank)
    self.bp_text:setString(rival_info.battle_point)

    -- 前 10 名的顺序列表会包含自己的名次，自己的这一行不能挑战。
    if self.challenge_btn then
        self.challenge_btn:setVisible(rival_info.rank ~= ladder_logic:GetCurRank())
    end

    local template_id = rival_info.template_id
    self.icon_panel:Show(constants.REWARD_TYPE["mercenary"], template_id, nil, nil, false)
    self.icon_panel:SetPosition(60, 60)

    if self.gonghui_bg then
        self.gonghui_bg:setVisible(false)
    end
    if self.deac_gonghui then
        self.deac_gonghui:setString("")
        self.deac_gonghui:setVisible(false)
    end

end

local ladder_main_panel = panel_prototype.New()
function ladder_main_panel:Init()
    self.root_node = (require "util.helper"):Loader("ui/ladder_main_panel.csb")
    local root_node = self.root_node

    --reward
    local reward_bg_img = root_node:getChildByName("reward_bg")
    self.reward_num_text = reward_bg_img:getChildByName("num")

    --top
    local top_node = root_node:getChildByName("top")

    self.rank_num_text = top_node:getChildByName("rank_value")
    self.challenge_num_text = top_node:getChildByName("challenge_num")
    self.challenge_cd_text = top_node:getChildByName("cd")

    --rival
    self.list_view = root_node:getChildByName("list_view")
    -- 视口顶部与排名栏底边对齐，避免中间露出一截滚动行。
    self.list_view:setContentSize(cc.size(640, 770))
    -- 顶部排名栏压在列表上方，滚动的行从它后面穿过。
    top_node:setLocalZOrder(20)
    reward_bg_img:setLocalZOrder(20)
    local rival_template = root_node:getChildByName("template")

    self.rival_items = {}
    for i = 1, MAX_RIVAL_NUM do
        local rival_sub_panel = rival_info_sub_panel.New()
        rival_sub_panel:Init(rival_template:clone(), true)
        rival_sub_panel.challenge_btn:setTag(i)

        rival_sub_panel:Show()
        self.list_view:addChild(rival_sub_panel.root_node)
        self.rival_items[i] = rival_sub_panel
    end

    local margin_node = ccui.Widget:create()
    local size = rival_template:getContentSize()
    size.height = size.height / 2
    margin_node:setContentSize(size)
    self.list_view:addChild(margin_node)

    if self.list_view.requestRefreshView then
        self.list_view:requestRefreshView()
    end
    self.list_view:forceDoLayout()
    rival_template:setVisible(false)

    -- [PC PORT] Keep the bottom actions above the rival list so its rows
    -- cannot swallow taps on 世界排名/兑换奖励/阵容排列/返回.
    for _, name in ipairs({ "back_btn", "look_rule_btn", "top_ten_rank_btn",
        "exchange_reward_btn", "formation_btn" }) do
        local node = root_node:getChildByName(name)
        if node then
            node:setLocalZOrder(5)
        end
    end

    self:RegisterEvent()
    self:RegisterWidgetEvent()
end

function ladder_main_panel:Show()
    self:ReLoadInfo()
    self.list_view:getInnerContainer():setPosition(0, 0)
    self.root_node:setVisible(true)
end

function ladder_main_panel:ReLoadInfo()

    self.duration = time_logic:GetDurationToFixedTime(ladder_logic.challenge_cd)
    self.rank_num_text:setString(ladder_logic.cur_rank)
    self.challenge_num_text:setString(ladder_logic.challenge_num)

    for i = 1, MAX_RIVAL_NUM do
        self.rival_items[i]:ReLoadInfo(i)
    end

    local cur_rank_reward_num = 0
    local cur_rank = ladder_logic.cur_rank

    local reward_rank = constants.LADDER_REWARD_RANK

    for i = 1, #reward_rank do
        if cur_rank >= reward_rank[i] then
            cur_rank_reward_num = constants.LADDER_REWARD[reward_rank[i]]
        else
            break
        end
    end

    self.reward_num_text:setString(cur_rank_reward_num)
end

function ladder_main_panel:Update(elapsed_time)
    self.duration = self.duration - elapsed_time
    if self.duration > 0 then
        self.challenge_cd_text:setString(panel_util:GetTimeStr(self.duration, true))
    else
        self.challenge_cd_text:setString("0:00")
    end
end

function ladder_main_panel:RegisterEvent()
    --挑战
    graphic:RegisterEvent("ladder_update_rival", function(is_winner)
        -- 战斗过程中面板可能被隐藏；此时也要先刷新数据，
        -- 否则战斗结束重新显示时会继续显示旧的对手名次。
        self:ReLoadInfo()
    end)
end


function ladder_main_panel:RegisterWidgetEvent()

    --返回
    self.root_node:getChildByName("back_btn"):addTouchEventListener(function(sender, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            graphic:DispatchEvent("show_world_sub_scene", "pvp_sub_scene")
        end
    end)

    --查看排名赛奖品规则
    self.root_node:getChildByName("look_rule_btn"):addTouchEventListener(function(sender, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            graphic:DispatchEvent("show_world_sub_panel", "ladder_rule_msgbox")
        end
    end)

    --查看大陆前十名玩家信息
    self.root_node:getChildByName("top_ten_rank_btn"):addTouchEventListener(function(sender, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            ladder_logic:TopTenQuery()
        end
    end)

    --兑换奖励
    self.root_node:getChildByName("exchange_reward_btn"):addTouchEventListener(function(sender, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            arena_logic:QueryExchangeConfig()

            --graphic:DispatchEvent("show_world_sub_panel", "exchange_reward_msgbox")
        end
    end)

    --阵容
    self.root_node:getChildByName("formation_btn"):addTouchEventListener(function(sender, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            local trans_type = constants["SCENE_TRANSITION_TYPE"]["none"]
            local mode = client_constants["FORMATION_PANEL_MODE"]["multi"]
            graphic:DispatchEvent("show_world_sub_scene", "formation_sub_scene", trans_type, mode)
        end
    end)

    --挑战
    local challenge_rival = function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            local tag = widget:getTag()
            ladder_logic:ChallengeRival(tag)
        end
    end

    for i = 1, MAX_RIVAL_NUM do
        local challenge_btn = self.rival_items[i].challenge_btn
        if challenge_btn then
            challenge_btn:addTouchEventListener(challenge_rival)
        end
    end
end

return ladder_main_panel
