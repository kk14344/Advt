local login_logic = require "logic.login"
local audio_manager = require "util.audio_manager"
local panel_prototype = require "ui.panel"
local configuration = require "util.configuration"
local graphic = require "logic.graphic"
local network = require "util.network"

local platform_manager = require "logic.platform_manager"
local configuration = require "util.configuration"

local lang_constants = require "util.language_constants"
local spine_manager = require "util.spine_manager"
local client_constants = require "util.client_constants"

local PLIST_TYPE = ccui.TextureResType.plistType
local panel_util = require "ui.panel_util"
local reuse_scrollview = require "widget.reuse_scrollview"
local feedback_manager = require "logic.feedback_manager"

local SUB_PANEL_HEIGHT = 88
local MAX_ALL_SERVER_SUB_PANEL_NUM = 9
local MAX_SCROLL_VIEW_CONTENT_HEIGHT = 1
local WORLD_PANEL_ZORDER = 1000

local TARGET_PLATFORM = cc.Application:getInstance():getTargetPlatform()

-- 注册子面板
local register_panel = panel_prototype.New()
function register_panel:Init(root_node)
    self.root_node = root_node

    -- username输入框
    self.username_bg_img = self.root_node:getChildByName("username_bg")
    self.password_bg_img = self.root_node:getChildByName("password_bg")

    self.username_textfield = self.username_bg_img:getChildByName("textfield")
    self.pwd_textfield = self.password_bg_img:getChildByName("textfield")

    -- [PC PORT] keep the account fields in the game's UI font; the CSB defaults
    -- to a system font for TextField.
    self.username_textfield:setFontName("fonts/general.ttf")
    self.pwd_textfield:setFontName("fonts/general.ttf")

    local touch_size = {
        width = 508,
        height = 60
    }
    self.username_textfield:setTouchAreaEnabled(true)
    self.username_textfield:setTouchSize(touch_size)

    self.pwd_textfield:setTouchAreaEnabled(true)
    self.pwd_textfield:setTouchSize(touch_size)

    -- [PC PORT] ccui.TextField/EditBox do not reliably receive keyboard
    -- input on this Windows build, so the account form drives its two
    -- fields from a scene keyboard listener instead.  Clicks land on the
    -- background images (the text fields themselves stop swallowing them).
    self.username_textfield:setTouchEnabled(false)
    self.pwd_textfield:setTouchEnabled(false)
    self.username_bg_img:setTouchEnabled(true)
    self.password_bg_img:setTouchEnabled(true)

    self.input_name = ""
    self.input_pwd = ""
    self.active_field = "username"

    local select_field = function(field)
        return function(_, event_type)
            if event_type == ccui.TouchEventType.ended then
                self.active_field = field
                audio_manager:PlayEffect("click")
            end
        end
    end
    self.username_bg_img:addTouchEventListener(select_field("username"))
    self.password_bg_img:addTouchEventListener(select_field("password"))

    self:InstallKeyboardInput()

    self.close_btn = root_node:getChildByName("close_btn")

    self.title_text = root_node:getChildByName("title"):getChildByName("name")

    self.desc_texts = {}
    for i = 1, 4 do
        self.desc_texts[i] = root_node:getChildByName("desc" .. i)
    end

    self.switch_btn = root_node:getChildByName("btn1")
    self.login_btn = root_node:getChildByName("btn2")

    self.spine_node = sp.SkeletonAnimation:create("res/spine/choose_focus.json", "res/spine/choose_focus.atlas", 1.0)
    self.root_node:addChild(self.spine_node)

    self.spine_node:setVisible(false)
    self.focus_tracker = spine_manager:CreateFocusTracker(self.spine_node, "login_input_box")

    self.init_y = self.root_node:getPositionY()

    self:RegisterWidgetEvent()
end

-- [PC PORT] cc.KeyCode (generated from the Lua list) skips the aliases in
-- EventKeyboard::KeyCode, so its values after KEY_ALT are three lower than
-- the keyCode the engine really reports.  Use the real enum values here.
local KC_BACKSPACE = 7
local KC_TAB = 8
local KC_RETURN = 10
local KC_KP_ENTER = 35
local KC_ENTER = 164
local KC_0 = 76
local KC_CAPITAL_A = 93
local KC_MINUS = 73
local KC_PERIOD = 74
local KC_AT = 92
local KC_UNDERSCORE = 122
local KC_A = 124

local ACCOUNT_KEY_CHARS = {}
for i = 0, 25 do
    ACCOUNT_KEY_CHARS[KC_A + i] = string.char(97 + i)
    ACCOUNT_KEY_CHARS[KC_CAPITAL_A + i] = string.char(65 + i)
end
for i = 0, 9 do
    ACCOUNT_KEY_CHARS[KC_0 + i] = tostring(i)
end
ACCOUNT_KEY_CHARS[KC_MINUS] = "-"
ACCOUNT_KEY_CHARS[KC_PERIOD] = "."
ACCOUNT_KEY_CHARS[KC_UNDERSCORE] = "_"
ACCOUNT_KEY_CHARS[KC_AT] = "@"

function register_panel:InstallKeyboardInput()
    if self.keyboard_listener then
        return
    end
    local listener = cc.EventListenerKeyboard:create()
    listener:registerScriptHandler(function(keyCode)
        CCLOG("[account] key", keyCode)
        self:OnKeyPressed(keyCode)
    end, cc.Handler.EVENT_KEYBOARD_RELEASED)
    cc.Director:getInstance():getEventDispatcher():addEventListenerWithSceneGraphPriority(listener,
        self.root_node)
    self.keyboard_listener = listener
end

function register_panel:RefreshInputDisplay()
    CCLOG("[account] input name=" .. tostring(self.input_name) .. " pwd_len=" ..
        tostring(string.len(self.input_pwd or "")))
    self.username_textfield:setString(self.input_name or "")
    self.pwd_textfield:setString(string.rep("*", string.len(self.input_pwd or "")))
    if self.is_show_register then
        self.desc_texts[3]:setVisible((self.input_name or "") == "")
        self.desc_texts[4]:setVisible((self.input_pwd or "") == "")
    end
end

function register_panel:Submit()
    local name = self.input_name or ""
    local pwd = self.input_pwd or ""
    if self.is_show_register then
        login_logic:SignUp(name, pwd)
    else
        login_logic:SignIn(name, pwd)
    end
end

function register_panel:OnKeyPressed(keyCode)
    if not self.root_node:isVisible() then
        return
    end

    if keyCode == KC_BACKSPACE then
        if self.active_field == "password" then
            self.input_pwd = string.sub(self.input_pwd, 1, math.max(0, string.len(self.input_pwd) - 1))
        else
            self.input_name = string.sub(self.input_name, 1, math.max(0, string.len(self.input_name) - 1))
        end
    elseif keyCode == KC_TAB then
        self.active_field = self.active_field == "username" and "password" or "username"
    elseif keyCode == KC_RETURN or keyCode == KC_KP_ENTER or keyCode == KC_ENTER then
        self:Submit()
        return
    else
        local ch = ACCOUNT_KEY_CHARS[keyCode]
        if ch then
            if self.active_field == "password" then
                if string.len(self.input_pwd) < 20 then
                    self.input_pwd = self.input_pwd .. ch
                end
            else
                if string.len(self.input_name) < 20 then
                    self.input_name = self.input_name .. ch
                end
            end
        end
    end

    self:RefreshInputDisplay()
end

function register_panel:Show(is_show_register)
    if is_show_register then
        self.desc_texts[3]:setVisible(true)
        self.desc_texts[4]:setVisible(true)

        local title = lang_constants:Get("account_register_title")
        self.title_text:setString(title)
        self.login_btn:setTitleText(title)
        self.switch_btn:setTitleText(lang_constants:Get("account_switch1"))

        self.input_name = ""
        self.input_pwd = ""

    else
        local name, pwd = login_logic:GetUsernameAndPwd()
        self.input_name = name or ""
        self.input_pwd = pwd or ""

        self.desc_texts[3]:setVisible(false)
        self.desc_texts[4]:setVisible(false)

        local title = lang_constants:Get("account_login_title")
        self.title_text:setString(title)
        self.login_btn:setTitleText(title)
        self.switch_btn:setTitleText(lang_constants:Get("account_switch2"))
    end

    if self.username_textfield:getAttachWithIME() then
        self.username_textfield:setAttachWithIME(false)
    end

    if self.pwd_textfield:getAttachWithIME() then
        self.pwd_textfield:setAttachWithIME(false)
    end

    self.username_bg_img:setScale(1, 1)
    self.password_bg_img:setScale(1, 1)
    self.focus_tracker.root_node:setVisible(false)

    self.is_show_register = is_show_register
    self.active_field = "username"
    self:RefreshInputDisplay()

    self.root_node:setPositionY(self.init_y)
    -- [PC PORT] raise the account dialog above the login screen's other
    -- full-screen helpers; otherwise its buttons can lose the touch hit-test.
    self.root_node:setLocalZOrder(5000)
    self.root_node:setVisible(true)
end

function register_panel:Update(elapsed_time)
    if not self.root_node:isVisible() then
        return
    end

    self.focus_tracker:Update()
end

function register_panel:RegisterWidgetEvent()
    self.login_btn:addTouchEventListener(function(sender, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            self:Submit()
        end
    end)

    self.switch_btn:addTouchEventListener(function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            self:Show(not self.is_show_register)
        end
    end)

    self.close_btn:addTouchEventListener(function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            self:Hide()
        end
    end)

    local click_textfield_method = function(widget, event_type)
        local tag = widget:getTag()

        if event_type == ccui.TextFiledEventType.attach_with_ime then
            if self.is_show_register then
                local text = self.desc_texts[tag]
                text:setVisible(false)
            end

            local locator_img
            if tag == 3 then
                locator_img = self.username_bg_img
                self.password_bg_img:setScale(1, 1)
            else
                locator_img = self.password_bg_img
                self.username_bg_img:setScale(1, 1)
            end

            local x, y = locator_img:getPosition()
            self.focus_tracker:Bind("login_input", x, y, locator_img)

            self.root_node:setPositionY(self.init_y + 220)

        elseif event_type == ccui.TextFiledEventType.detach_with_ime then
            if (self.focus_tracker.widget and self.focus_tracker.widget:getTag() == tag) then
                self.focus_tracker:Hide()
                self.root_node:setPositionY(self.init_y)
            end
        end
    end

    self.username_textfield:addEventListener(click_textfield_method)
    self.pwd_textfield:addEventListener(click_textfield_method)

    self.username_textfield:setTag(3)
    self.pwd_textfield:setTag(4)
    self.username_bg_img:setTag(3)
    self.password_bg_img:setTag(4)
end

-- 服务列表子面板
local server_sub_panel = panel_prototype.New()
server_sub_panel.__index = server_sub_panel

function server_sub_panel.New()
    return setmetatable({}, server_sub_panel)
end

function server_sub_panel:Init(root_node)
    self.root_node = root_node

    self.cur_name_text = root_node:getChildByName("name")
    self.cur_icon_img = root_node:getChildByName("icon")
    self.cur_status_text = root_node:getChildByName("status")
end

function server_sub_panel:Load(server_info)
    self.root_node:setTag(server_info.id)
    local locale = platform_manager:GetLocale()
    if server_info["name_" .. locale] then
        self.cur_name_text:setString(server_info["name_" .. locale])
    else
        self.cur_name_text:setString(server_info.name)
    end

    if server_info.status then
        local author_text = ""
        if server_info["author_" .. locale] then
            author_text = server_info["author_" .. locale]
        elseif server_info.author then
            author_text = server_info.author
        end
        self.cur_status_text:setString(string.format(lang_constants:Get("server_author"), author_text))

        if server_info.status == 4 then
            self.cur_icon_img:loadTexture(CheckTextureCache("login/red_soul_crystal.png"), PLIST_TYPE)

        else
            self.cur_icon_img:loadTexture(CheckTextureCache("login/green_soul_crystal.png"), PLIST_TYPE)
        end
    end
end

-- 服务器列表弹窗
local server_list_panel = panel_prototype.New()

function server_list_panel:Init(root_node, box_shadow_img, server_node)
    self.root_node = root_node

    self.box_shadow_img = box_shadow_img
    self.box_shadow_img:setTouchEnabled(true)
    server_sub_panel:Init(server_node)

    self.cur_server_sub_panel = cur_server_sub_panel

    self.recommand_server_tab = self.root_node:getChildByName("tab1")
    self.recommand_server_tab:setTouchEnabled(true)

    self.all_server_tab = self.root_node:getChildByName("tab2")
    self.all_server_tab:setTouchEnabled(true)

    self.template = self.root_node:getChildByName("template")
    self.template:setVisible(false)
    self.recommand_server_node = self.root_node:getChildByName("server_node1")
    self.all_server_sview = self.root_node:getChildByName("server_sview1")

    self:RegisterWidgetEvent()

    -- 新服
    self.new_server_sub_panels = {}
    for i = 1, 2 do
        local sub_panel = server_sub_panel.New()
        sub_panel:Init(self.template:clone())
        sub_panel.root_node:setVisible(false)
        sub_panel.root_node:setPosition(300, 686 - (i - 1) * SUB_PANEL_HEIGHT)
        sub_panel.root_node:addTouchEventListener(self.select_method)
        self.recommand_server_node:addChild(sub_panel.root_node)
        self.new_server_sub_panels[i] = sub_panel
    end

    -- 登录过的服务器
    self.logined_server_sub_panels = {}
    for i = 1, 5 do
        local sub_panel = server_sub_panel.New()
        sub_panel:Init(self.template:clone())
        sub_panel.root_node:setVisible(false)
        sub_panel.root_node:addTouchEventListener(self.select_method)
        sub_panel.root_node:setPosition(300, 464 - (i - 1) * SUB_PANEL_HEIGHT)
        self.logined_server_sub_panels[i] = sub_panel
        self.recommand_server_node:addChild(sub_panel.root_node)
    end

    self.all_server_sub_panels = {}
    self.all_server_sub_panel_num = 0
    self.total_server_num = 0

    self.all_server_sview:setLocalZOrder(100)

    self.reuse_scrollview = reuse_scrollview.New(self, self.all_server_sview, self.all_server_sub_panels,
        SUB_PANEL_HEIGHT)

    self.reuse_scrollview:RegisterMethod(function(self)
        return server_list_panel.total_server_num
    end, function(self, sub_panel, is_up)
        local index = is_up and self.data_offset + self.sub_panel_num or self.data_offset + 1
        sub_panel:Load(self.parent_panel.server_list[index])
    end)

    -- id 哈希表
    self.server_id_hash = {}
end

-- 创建子sub_panel
function server_list_panel:CreateServerSubPanel()
    local num = math.min(MAX_ALL_SERVER_SUB_PANEL_NUM, self.total_server_num)

    if self.all_server_sub_panel_num >= num then
        return
    end

    for i = self.all_server_sub_panel_num + 1, num do
        local sub_panel = server_sub_panel.New()
        sub_panel:Init(self.template:clone())

        self.all_server_sub_panels[i] = sub_panel
        self.all_server_sview:addChild(sub_panel.root_node)
        sub_panel.root_node:addTouchEventListener(self.select_method)

        sub_panel.root_node:setPositionX(260)
    end

    self.all_server_sub_panel_num = num
end

function server_list_panel:Show()
    self:ShowSubPanel(1)
    -- 新服
    self:NewServerList()
    -- 登录过的服务器
    self:LoginedServerList()
    -- 所有服务器
    self:AllServerList()

    self.box_shadow_img:setVisible(true)
    self.root_node:setVisible(true)
end

-- 初始化server_list_panel 信息
function server_list_panel:InitServerListInfo()

    local last_server_id, server_list = login_logic:GetServerList()
    for i = 1, #server_list do
        local server_info = server_list[i]
        self.server_id_hash[server_info.id] = server_info
    end
    self.last_server_id = last_server_id
    self.server_list = server_list
end

-- load当前server_info
function server_list_panel:LoadCurServerInfo()
    if self.last_server_id then
        if self.server_id_hash[self.last_server_id] then
            server_sub_panel:Load(self.server_id_hash[self.last_server_id])
            self.server_id = self.last_server_id
        else
            server_sub_panel:Load(self.server_list[1])
            self.server_id = self.server_list[1].id
        end
    else
        server_sub_panel:Load(self.server_list[1])
        self.server_id = self.server_list[1].id
    end
end

function server_list_panel:AllServerList()
    self.total_server_num = #self.server_list
    local width, height = 640, 0
    local height = math.max(self.total_server_num * SUB_PANEL_HEIGHT, self.reuse_scrollview.sview_height)

    self:CreateServerSubPanel()

    for i = 1, self.all_server_sub_panel_num do
        local sub_panel = self.all_server_sub_panels[i]
        sub_panel:Load(self.server_list[i])
        sub_panel.root_node:setPositionY(height - (i - 1) * SUB_PANEL_HEIGHT - 60)
        sub_panel.root_node:setVisible(true)
    end

    self.reuse_scrollview:Show(height, 0)

    self.server_id = self.last_server_id
end

-- 新服
function server_list_panel:NewServerList()
    local new_num = 0
    for i = 1, #self.server_list do
        if self.server_list[i].status == 1 then
            new_num = new_num + 1
            self.new_server_sub_panels[new_num]:Load(self.server_list[i])
            self.new_server_sub_panels[new_num].root_node:setVisible(true)
        end

        if new_num == 2 then
            break
        end
    end
end

-- 登录过的服务器
function server_list_panel:LoginedServerList()
    local logined_list = configuration:GetLoginedServerList()

    for i = 1, 5 do
        if i <= #logined_list then
            if self.server_id_hash[logined_list[i]] then
                self.logined_server_sub_panels[i]:Load(self.server_id_hash[logined_list[i]])
                self.logined_server_sub_panels[i].root_node:setVisible(true)
            else
                self.logined_server_sub_panels[i].root_node:setVisible(false)
            end
        else
            self.logined_server_sub_panels[i].root_node:setVisible(false)
        end
    end

end

-- 显示面板
function server_list_panel:ShowSubPanel(sub_panel_type)
    if sub_panel_type == 1 then
        self.recommand_server_tab:setColor(panel_util:GetColor4B("0xffffff"))
        self.all_server_tab:setColor(panel_util:GetColor4B("0x7f7f7f"))

        self.recommand_server_node:setVisible(true)
        self.all_server_sview:setVisible(false)

        self.recommand_server_tab:setLocalZOrder(101)
        self.all_server_tab:setLocalZOrder(100)

    else
        self.recommand_server_tab:setColor(panel_util:GetColor4B("0x7f7f7f"))
        self.all_server_tab:setColor(panel_util:GetColor4B("0xffffff"))

        self.recommand_server_node:setVisible(false)
        self.all_server_sview:setVisible(true)

        self.recommand_server_tab:setLocalZOrder(100)
        self.all_server_tab:setLocalZOrder(101)

    end
end

function server_list_panel:RegisterWidgetEvent()
    self.select_method = function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")

            local server_id = widget:getTag()
            self.server_id = server_id
            self.box_shadow_img:setVisible(false)

            self:Hide()
            for i = 1, self.total_server_num do
                local server_info = self.server_list[i]
                if server_info.id == server_id then
                    server_sub_panel:Load(server_info)
                    break
                end
            end
        end
    end

    self.root_node:getChildByName("close_btn"):addTouchEventListener(function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            self.box_shadow_img:setVisible(false)
            server_list_panel:Hide()
        end
    end)

    self.recommand_server_tab:addTouchEventListener(function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            self:ShowSubPanel(1)
        end
    end)

    self.all_server_tab:addTouchEventListener(function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            self:ShowSubPanel(2)
        end
    end)
end

local login_panel = panel_prototype.New()
function login_panel:Init()
    local helper = require "util.helper"
    self.root_node = (require "util.helper"):Loader("ui/login_panel.csb")

    self.download_apk_panel = require "ui.download_apk_panel"
    self.download_apk_panel:Init()
    self.root_node:addChild(self.download_apk_panel:GetRootNode())
    self.download_apk_panel:Hide()

    self.cur_version_text = self.root_node:getChildByName("version")
    -- 版本号统一由登录页左上角 version_label 显示
    self.cur_version_text:setVisible(false)

    -- [UI 美化] 顶部居中原生暗木铭牌：免费游玩与交流群提示，不遮挡晶石与主视觉
    local notice_bg = ccui.ImageView:create("login/floating_layerbg.png", PLIST_TYPE)
    if notice_bg then
        notice_bg:setScale9Enabled(true)
        notice_bg:setCapInsets(cc.rect(18, 18, 34, 34))
        notice_bg:setContentSize(cc.size(416, 36))
        notice_bg:setAnchorPoint(cc.p(0.5, 0.5))
        notice_bg:setPosition(cc.p(320, 1110))
        notice_bg:setOpacity(210)
        self.root_node:addChild(notice_bg, 5)
        self.free_notice_bg = notice_bg
    end
    self.free_notice_line1 = ccui.Text:create("免费单机游玩 · 交流群 605940868",
        "fonts/general.ttf", 18)
    self.free_notice_line1:setAnchorPoint(cc.p(0.5, 0.5))
    self.free_notice_line1:setPosition(cc.p(320, 1110))
    self.free_notice_line1:setTextColor(cc.c4b(255, 238, 196, 255))
    self.free_notice_line1:enableOutline(cc.c4b(34, 22, 10, 255), 2)
    self.root_node:addChild(self.free_notice_line1, 6)
    self.frm = 0
    -- 登录按钮
    self.bottom_node = self.root_node:getChildByName("bottom")
    self.wechat_btn = self.bottom_node:getChildByName("wechat_btn")
    self.guest_btn = self.bottom_node:getChildByName("guest_btn")
    self.exit_btn = self.bottom_node:getChildByName("exit_btn")

    if self.exit_btn ~= nil then
        self.exit_btn:setVisible(false)
        helper:AddClick(self.exit_btn, function()
            PlatformSDK.signOut()
        end)
    end

    self.login_btn = self.bottom_node:getChildByName("login_btn")
    self.login_btn_base_y = self.login_btn:getPositionY()
    self.login_btn:setVisible(false)

    -- [UI 美化] 右上角整合为单个原生像素金框「存档管理」按钮，点击弹出原生木框菜单
    self.save_mgr_btn = ccui.Button:create(
        'login/buttonbg_1.png',
        'login/buttonbg_1.png',
        'login/buttonbg_1.png',
        PLIST_TYPE
    )
    self.save_mgr_btn:setScale9Enabled(true)
    self.save_mgr_btn:setCapInsets(cc.rect(24, 18, 185, 38))
    self.save_mgr_btn:setContentSize(cc.size(138, 50))
    self.save_mgr_btn:setAnchorPoint(cc.p(0.5, 0.5))
    self.save_mgr_btn:setTitleText("存档管理")
    self.save_mgr_btn:setTitleFontName(client_constants["FONT_FACE"])
    self.save_mgr_btn:setTitleFontSize(22)
    self.save_mgr_btn:setTitleColor(cc.c3b(0x2b, 0x1d, 0x0e))
    -- bottom_node 位于 y=25，按钮中心屏幕坐标约为 (556, 1070)
    self.save_mgr_btn:setPosition(cc.p(556, 1045))
    self.save_mgr_btn:addTouchEventListener(function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            self:ShowSaveManagerPanel()
        end
    end)
    self.bottom_node:addChild(self.save_mgr_btn, 10)

    local channel_info = platform_manager:GetChannelInfo()
    self.wechat_btn:setVisible(false)
    self.wechat_btn:getChildByName("Image_1"):setVisible(false)

    local node1 = self.root_node:getChildByName("copyright_1")
    node1:setScale(0.75, 0.75)
    local btn_beian = node1:getChildByName("btn")
    helper:AddClick(btn_beian, function()
        cc.Application:getInstance():openURL("https://beian.miit.gov.cn")
    end)

    register_panel:Init(self.root_node:getChildByName("register_node"))

    local server_node = self.root_node:getChildByName("server_node")

    self.back_btn = server_node:getChildByName("back_btn")
    self.enter_btn = server_node:getChildByName("enter_btn")
    self.view_list_img = server_node:getChildByName("current_server_bg")

    local news_bg_img = server_node:getChildByName("news_bg")
    self.notice_sview = news_bg_img:getChildByName("scrollview")
    self.notice_text = self.notice_sview:getChildByName("desc")
    self.notice_title = news_bg_img:getChildByName("title")

    self.notice_title:setString(lang_constants:Get("game_notice_title"))

    self.notice_sview:setInnerContainerSize(cc.size(560, 200))

    -- 拥有切换账户和用户中心按钮的渠道需要使用
    self.change_user_btn = server_node:getChildByName("account_btn")
    if self.change_user_btn then
        self.change_user_btn:setVisible(false)
    end
    self.user_center_btn = server_node:getChildByName("usercenter_btn")
    if self.user_center_btn then
        self.user_center_btn:setVisible(false)
    end

    server_node:setVisible(false)
    self.server_node = server_node

    local box_shadow_img = self.root_node:getChildByName("box_shadow")

    server_list_panel:Init(self.root_node:getChildByName("server_msgbox"), box_shadow_img, server_node)
    server_list_panel:Hide()

    self.loading_node = self.root_node:getChildByName("loading")
    self.loading_node:setVisible(false)

    self.rotation = 0
    self.percent_img = self.loading_node:getChildByName("percent_icon")

    local channel_info = platform_manager:GetChannelInfo()
    local copyright2 = self.root_node:getChildByName("copyright2")
    if copyright2 then
        if channel_info.show_copyright then
            copyright2:setVisible(true)
        else
            copyright2:setVisible(false)
        end
    end

    self.locale_panel = nil

    self:RegisterEvent()
    self:RegisterWidgetEvent()

    -- local copyright_sprite = cc.Sprite:create("res/ui/copyright.png")
    -- self.root_node:addChild(copyright_sprite)
    -- copyright_sprite:setPosition(310, 33)
    -- copyright_sprite:setScale(0.75, 0.75)
    self.bottom_node:setPosition(0, 25)
    self.server_node:setPosition(0, 25)

    self.age_pic = self.root_node:getChildByName("age_pic")
    self.age_pic:setContentSize(70, 100)
    self.age_pic:setPositionX(50)
    self.age_pic:setPositionY(1020)
    helper:SetImage(self.age_pic, "res/ui/12yishang.png")
    helper:AddClick(self.age_pic, function()
        if self.age_panel == nil then
            self.age_panel = require "ui.login_panel_age_panel"
            self.age_panel:Init()
            self.age_panel:Hide()
            self.root_node:addChild(self.age_panel.root_node)
        end
        self.age_panel:Show()
    end)

end

function login_panel:ShowPrivacyPanel()
    if self.privacy_panel == nil then
        self.privacy_panel = require "ui.login_panel_privacy_msgbox"
        self.privacy_panel:Init()
        self.privacy_panel:Hide()
        self.root_node:addChild(self.privacy_panel.root_node)
    end
    self.privacy_panel:Show()
end

function login_panel:ShowBottom()
    self.root_node:setVisible(true)
    self.bottom_node:setVisible(true)
    self.loading_node:setVisible(false)
    self.server_node:setVisible(false)

    self.cur_version_text:setString(lang_constants:GetFormattedStr("version_desc", configuration:GetResourceVersion()) .. "  [aam-v19]")
    -- 版本号改由全局右上角版本号显示，这里隐藏避免重复
    self.cur_version_text:setVisible(false)

    local channel_info = platform_manager:GetChannelInfo()
    local account_type = channel_info.account_type

    CCLOG(" ShowBottom channel_info :", channel_info, account_type)

    self.login_btn:setVisible(false)
    self.guest_btn:setVisible(false)
    self.wechat_btn:setVisible(false)

    if TARGET_PLATFORM == cc.PLATFORM_OS_WINDOWS or TARGET_PLATFORM == cc.PLATFORM_OS_MAC then
        self.guest_btn:setVisible(true)
    else
        self.wechat_btn:setVisible(true)
    end
    self.wechat_btn:setTitleText(lang_constants:Get("leiting_login_desc"))
    self.guest_btn:setTitleText(lang_constants:Get("leiting_login_desc"))

    -- [PC PORT] Local account entry: only 账号登录 is offered.  It is centered
    -- and enlarged, and opens the original account panel; there is no guest
    -- login on this build.
    local is_local_account = channel_info.local_account or channel_info.is_debug
    if is_local_account then
        self.login_btn:setVisible(true)
        self.login_btn:setTitleText(lang_constants:Get("account_local_login"))
        -- Sit a little higher so the enlarged button does not crowd the fine
        -- print at the bottom of the login screen.
        self.login_btn:setPosition(320, self.login_btn_base_y + 40)
        self.login_btn:setScale(1.45)
        self.guest_btn:setVisible(false)
        self.wechat_btn:setVisible(false)
    end

    if self.save_mgr_panel then
        self.save_mgr_panel:setVisible(false)
    end

    register_panel:Hide()
    server_list_panel:Hide()
    -- self:AutoSignin()
    self.account_type = account_type
    if not login_logic.is_user_login and not is_local_account then
        self:GameSignIn(platform_manager:GetAccountPlatformType(account_type))
    end

end

-- [UI 美化] 原生木框羊皮纸风格「存档管理」弹窗（含 提取 / 载入 / 回滚 / 删除，接入 pixel_kit 返回键栈）
function login_panel:ShowSaveManagerPanel()
    audio_manager:PlayEffect("click")
    -- 打开存档管理时取消自动进服倒计时，避免操作中途被切走
    if self.root_node then
        self.root_node:stopActionByTag(9901)
    end
    local pixel_kit = require "ui.pixel_kit"
    if not self.save_mgr_panel then
        local layer = ccui.Layout:create()
        layer:setContentSize(cc.size(640, 1136))
        layer:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
        layer:setBackGroundColor(cc.c3b(0, 0, 0))
        layer:setBackGroundColorOpacity(155)
        layer:setTouchEnabled(true)

        local function close_save_mgr()
            pixel_kit:PopOverlay(layer)
            layer:setVisible(false)
        end
        self._close_save_mgr = close_save_mgr

        layer:addTouchEventListener(function(_, event_type)
            if event_type == ccui.TouchEventType.ended then
                audio_manager:PlayEffect("click")
                close_save_mgr()
            end
        end)

        local box = ccui.ImageView:create("login/box_bg.png", PLIST_TYPE)
        box:setScale9Enabled(true)
        box:setCapInsets(cc.rect(50, 56, 20, 8))
        box:setContentSize(cc.size(486, 536))
        box:setPosition(cc.p(320, 580))
        box:setTouchEnabled(true)
        layer:addChild(box, 2)

        local title_bg = ccui.ImageView:create("login/top_tab.png", PLIST_TYPE)
        title_bg:setPosition(cc.p(243, 518))
        box:addChild(title_bg, 3)

        local title_txt = pixel_kit:CreateLabel("存档管理", {
            font_size = 28,
            text_color = cc.c4b(255, 255, 255, 255),
            pos = cc.p(132, 28),
            outline_color = cc.c4b(36, 22, 10, 255),
            outline_size = 3,
        })
        title_bg:addChild(title_txt, 1)

        local close_btn = ccui.Button:create("login/close1_normal.png", "login/close1_press.png", "login/close1_normal.png", PLIST_TYPE)
        close_btn:setPosition(cc.p(464, 514))
        close_btn:addTouchEventListener(function(_, event_type)
            if event_type == ccui.TouchEventType.ended then
                audio_manager:PlayEffect("click")
                close_save_mgr()
            end
        end)
        box:addChild(close_btn, 4)

        local tip_bg = ccui.ImageView:create("login/paper_bg1.png", PLIST_TYPE)
        tip_bg:setScale9Enabled(true)
        tip_bg:setCapInsets(cc.rect(30, 18, 196, 32))
        tip_bg:setContentSize(cc.size(426, 86))
        tip_bg:setPosition(cc.p(243, 428))
        box:addChild(tip_bg, 2)

        local tip_txt = pixel_kit:CreateLabel("备份目录：MXYWKsave 与 Download/MXYWKsave\n兼容 v1/v2 存档 · 导入前自动快照防丢失\nAndroid 11+ 亦可在启动页使用系统文件选择器导入", {
            font_size = 16,
            align = cc.TEXT_ALIGNMENT_CENTER,
            valign = cc.VERTICAL_TEXT_ALIGNMENT_CENTER,
            pos = cc.p(213, 43),
            text_color = cc.c4b(46, 32, 16, 255),
            outline = false,
        })
        tip_bg:addChild(tip_txt, 1)

        local function makeMenuBtn(tex, label, y, cb)
            local btn = pixel_kit:CreateButton({
                texture = tex,
                cap_insets = cc.rect(24, 18, 185, 38),
                size = cc.size(366, 62),
                pos = cc.p(243, y),
                title = label,
                font_size = 24,
                title_color = 0x20160b,
                outline = false,
                silent = true,
                on_click = function()
                    close_save_mgr()
                    cb()
                end,
            })
            box:addChild(btn, 3)
            return btn
        end

        self.export_save_btn = makeMenuBtn("login/buttonbg_1.png", "存档提取（导出校验备份）", 332, function()
            self:ShowSaveTransferConfirm("export")
        end)
        self.import_save_btn = makeMenuBtn("login/buttonbg_3.png", "存档载入（兼容自动检索）", 252, function()
            self:ShowSaveTransferConfirm("import")
        end)
        self.rollback_save_btn = makeMenuBtn("login/buttonbg_1.png", "撤销导入（恢复上次快照）", 172, function()
            self:ShowSaveTransferConfirm("rollback")
        end)
        self.delete_save_btn = makeMenuBtn("login/buttonbg_2.png", "删除当前存档", 92, function()
            self:ShowDeleteSaveConfirm()
        end)

        self.root_node:addChild(layer, 900)
        self.save_mgr_panel = layer
    end
    self.save_mgr_panel:setVisible(true)
    pixel_kit:PushOverlay(self.save_mgr_panel, self._close_save_mgr)
end

-- [PC PORT] 删除存档用的确认/结果弹窗（登录界面没有 world_scene 的通用弹窗）
function login_panel:GetDeleteMsgbox()
    if not self.delete_msgbox then
        self.delete_msgbox = require "ui.simple_msgbox"
        self.delete_msgbox:Init()
        self.root_node:addChild(self.delete_msgbox:GetRootNode(), 1000)
    end
    return self.delete_msgbox
end

function login_panel:ShowDeleteSaveConfirm()
    audio_manager:PlayEffect("click")
    local box = self:GetDeleteMsgbox()
    box.close1_btn:setVisible(true)
    box.close2_btn:setVisible(true)
    box:Show("删除存档",
        "确定要删除当前存档吗？删除后需要重新创建角色，且无法恢复。",
        "确定删除", "取消", function()
            local name, pwd = login_logic:GetUsernameAndPwd()
            if not name or name == "" or not pwd or pwd == "" then
                name, pwd = "local_player", "local123"
            end
            self:SetLoadingTime(10)
            login_logic:BeginDeleteSave(name, pwd)
        end)
end

function login_panel:ShowSaveTransferConfirm(mode)
    audio_manager:PlayEffect("click")
    local box = self:GetDeleteMsgbox()
    box.close1_btn:setVisible(true)
    box.close2_btn:setVisible(true)
    local title, msg
    if mode == "export" then
        title = "存档提取"
        msg = "将导出含 SHA-256 校验与角色资料的完整存档至 MXYWKsave、Download/MXYWKsave 及应用目录，确定继续吗？"
    elseif mode == "rollback" then
        title = "撤销上次导入"
        msg = "将把进度恢复至最近一次导入前自动生成的快照备份，确定继续吗？"
    else
        title = "存档载入"
        msg = "将自动检索 MXYWKsave / Download/MXYWKsave 中最新有效存档（兼容 v1/v2），导入前会自动备份当前进度，确定继续吗？"
    end
    box:Show(title, msg, "确定", "取消", function()
            local name, pwd = login_logic:GetUsernameAndPwd()
            if not name or name == "" or not pwd or pwd == "" then
                name, pwd = "local_player", "local123"
            end
            self:SetLoadingTime(10)
            login_logic:BeginSaveTransfer(mode, name, pwd)
        end)
end

function login_panel:GameSignIn(account_type)
    if configuration:GetVal("privacy_xiao7") ~= true then
        self:ShowPrivacyPanel()
        return
    end
    PlatformSDK.showSignIn(account_type)
end

function login_panel:AutoSignin()
    local channel_info = platform_manager:GetChannelInfo()
    if channel_info.auto_signin then
        local signin_type = channel_info.account_type
        self:GameSignIn(platform_manager:GetAccountPlatformType(signin_type))
    end
end

function login_panel:HideAllSubPanel()
    self.root_node:setVisible(true)
    self.bottom_node:setVisible(false)
    self.loading_node:setVisible(false)
    self.server_node:setVisible(false)

    self.cur_version_text:setString("Version" .. configuration:GetVersion() .. "  [aam-v19]")
    self.cur_version_text:setVisible(false)

    register_panel:Hide()
    server_list_panel:Hide()
end

function login_panel:SetLoadingTime(time)
    self.loading_time = time
    self.loading_node:setVisible(true)
end

function login_panel:Update(elapsed_time)
    if self.loading_node:isVisible() then
        self.rotation = self.rotation + elapsed_time * 180
        self.loading_time = self.loading_time - elapsed_time

        self.percent_img:setRotation(self.rotation)

        if self.loading_time <= 0 then
            self.loading_node:setVisible(false)
        end
    end

    register_panel:Update(elapsed_time)
    self.download_apk_panel:UpdatePercentIcon(elapsed_time)
    self.frm = self.frm + elapsed_time
    if self.download_start == true then
        if self.frm > 0.1 then
            self.frm = self.frm - 0.1
            if PlatformSDK.queryDownaloadState ~= nil then
                PlatformSDK.queryDownaloadState()
            end
        end
    end

end

function login_panel:AuthSuccess()
    register_panel:Hide()

    server_list_panel:InitServerListInfo()
    server_list_panel:LoadCurServerInfo()

    self.server_node:setVisible(true)
    -- [PC PORT] the local account API has no global notice; fall back to the
    -- original in-game tip pool instead of leaving the login banner blank.
    local notice_str = login_logic:GetGlobalNotice()
    if notice_str == nil or notice_str == "" then
        notice_str = lang_constants:GetTip("main_sub_scene")
    end
    self.notice_text:setString(notice_str)

    self.bottom_node:setVisible(false)

    -- [PC PORT] standalone builds only have the local server, enter it automatically (0.5s; cancelled if Save Manager opens).
    local TARGET = cc.Application:getInstance():getTargetPlatform()
    if TARGET == cc.PLATFORM_OS_WINDOWS or TARGET == cc.PLATFORM_OS_ANDROID then
        self.root_node:stopActionByTag(9901)
        local auto_act = cc.Sequence:create(cc.DelayTime:create(0.5), cc.CallFunc:create(function()
            if self.save_mgr_panel and self.save_mgr_panel:isVisible() then
                return
            end
            local sid = server_list_panel.server_id or 1
            if login_logic:UserLogin(sid) then
                self:SetLoadingTime(5)
            end
        end))
        auto_act:setTag(9901)
        self.root_node:runAction(auto_act)
    end
end

function login_panel:ShowLogin()
    -- local channel_info = platform_manager:GetChannelInfo()
    -- if channel_info.account_type then
    --     --木七七
    --     register_panel:Show(false)
    -- else
    --     --其他平台登录
    --     local account_type = channel_info.signin[1]
    --     if account_type and platform_manager:HasAccountPlatform(account_type) then
    --         self:GameSignIn(platform_manager:GetAccountPlatformType(account_type))
    --     end
    -- end
end

function login_panel:ShowLocalePanel()
    local sub_panel = self.locale_panel

    if not sub_panel then
        sub_panel = require("ui.locale_panel")
        sub_panel.__name = name

        sub_panel:Init(true)
        self.root_node:addChild(sub_panel:GetRootNode(), WORLD_PANEL_ZORDER)

        sub_panel:GetRootNode():setVisible(false)
        self.locale_panel = sub_panel
    end

    sub_panel:Show()
end

function login_panel:RegisterEvent()

    graphic:RegisterEvent("agreePrivacy_over", function()
        -- if self.account_type ~= nil then
        --     self:GameSignIn(platform_manager:GetAccountPlatformType(self.account_type))
        -- end
    end)

    graphic:RegisterEvent("show_auth_result", function(result)
        local scene = cc.Director:getInstance():getRunningScene()
        if scene and scene.__name == "login" and result == "platform_auth_success" then
            self:AuthSuccess()
        end

        self.loading_node:setVisible(false)
        graphic:DispatchEvent("show_prompt_panel", result)

    end)

    -- 服务端删除存档结果
    graphic:RegisterEvent("delete_save_result", function(success)
        self.loading_node:setVisible(false)
        local box = self:GetDeleteMsgbox()
        box.close1_btn:setVisible(false)
        box.close2_btn:setVisible(false)
        local desc = success
            and "当前存档已删除，可以重新开始游戏并创建新角色。"
            or "当前存档删除失败，请稍后重试。"
        box:Show(success and "提示" or "删除失败", desc, "确定", "", function()
            network:Disconnect()
            self:ShowBottom()
        end)
    end)

    -- 服务端存档提取/载入/回滚结果
    graphic:RegisterEvent("save_transfer_result", function(success, mode)
        self.loading_node:setVisible(false)
        local box = self:GetDeleteMsgbox()
        box.close1_btn:setVisible(false)
        box.close2_btn:setVisible(false)
        local title, desc
        if mode == "export" then
            title = success and "存档提取成功" or "存档提取失败"
            desc = success
                and "完整校验存档已导出至 MXYWKsave 与 Download/MXYWKsave/save_backup.json。"
                or "存档提取失败，请检查存储空间或使用启动页「导出存档…」系统选择器。"
        elseif mode == "rollback" then
            title = success and "已恢复导入前快照" or "暂无可恢复快照"
            desc = success
                and "进度已回滚至上次导入前的自动备份，直接点击「开始游戏」即可生效。"
                or "未找到导入前的自动回滚快照。"
        else
            title = success and "存档载入成功" or "存档载入失败"
            desc = success
                and "存档校验通过并已载入（旧进度已自动快照备份），直接点击「开始游戏」即可生效！"
                or "未找到有效存档或文件损坏，请将 save_backup.json 放入 MXYWKsave 或 Download/MXYWKsave，或在启动页使用「导入存档…」直接选取文件。"
        end
        box:Show(title, desc, "确定", "", function()
            network:Disconnect()
            self:ShowBottom()
        end)
    end)

    graphic:RegisterEvent("show_login_result", function(result)
        if result == "invalid_pwd" then
            graphic:DispatchEvent("show_prompt_panel", "account_not_exist")

        elseif result == "register_first" then
            graphic:DispatchEvent("show_prompt_panel", "account_not_exist")

        elseif result == "invalid_char" then
            graphic:DispatchEvent("show_prompt_panel", "account_register_invalid_char")

        elseif result == "auth_failure" then
            graphic:DispatchEvent("show_prompt_panel", "platform_auth_failed")

        elseif result == "server_is_busy" then
            graphic:DispatchEvent("show_prompt_panel", "account_server_is_busy")

        elseif result == "forbidden_create" then
            graphic:DispatchEvent("show_prompt_panel", "account_forbid_create")
        end

        self.loading_node:setVisible(false)
    end)

    graphic:RegisterEvent("DowloadApk", function(event_data, value)
        local helper = require "util.helper"
        if event_data == "download_start" then
            self.download_apk_panel:Show()
            self.download_apk_panel:ShowDownload(helper.update_version_string)
            self.download_start = true
        end
        if event_data == "download_progress" then
            self.download_apk_panel:UpdateDownloadProgress(value)
        end
        if event_data == "download_success" then
            self.download_start = nil
        end

    end)

end

-- 注册控件相关事件
function login_panel:RegisterWidgetEvent()
    local helper = require "util.helper"
    local channel_info = platform_manager:GetChannelInfo()

    helper:AddClick(self.login_btn, function()
        if channel_info.local_account or channel_info.is_debug then
            -- [PC PORT] 开始游戏：不再弹出账号登录框。优先用上次保存的账号
            -- 直接进入游戏；没有保存过则使用固定的本地账号。
            local name, pwd = login_logic:GetUsernameAndPwd()
            if not name or name == "" or not pwd or pwd == "" then
                name, pwd = "local_player", "local123"
            end
            login_logic:SignIn(name, pwd)
        end
    end)

    -- 微信登录
    helper:AddClick(self.wechat_btn, function()
        register_panel:Hide()
        self:SetLoadingTime(5)
        local account_type = channel_info.account_type
        if account_type then
            self:GameSignIn(platform_manager:GetAccountPlatformType(account_type))
        end
    end)

    -- 游客登录
    helper:AddClick(self.guest_btn, function()
        register_panel:Hide()
        if TARGET_PLATFORM == cc.PLATFORM_OS_WINDOWS or TARGET_PLATFORM == cc.PLATFORM_OS_MAC then
            -- graphic:DispatchEvent("show_auth_result", "platform_auth_success")
            -- login_logic:SignInAsGuest()
            _G["CONFIGURATION"] = require "util.configuration"
            local open_id = CONFIGURATION:GetOpenID()
            if open_id == nil or open_id == "" then
                open_id = "mac" .. math.random(1, 1000)
            end
            CONFIGURATION:SetOpenID(open_id)
            graphic:DispatchEvent("finish_waiting", "finished")
            graphic:DispatchEvent("show_auth_result", "platform_auth_success")

        end
    end)

    -- 返回账号登录
    helper:AddClick(self.back_btn, function()
        PlatformSDK.signOut()
        server_list_panel:Hide()
        self.server_node:setVisible(false)
        self.bottom_node:setVisible(true)
        -- self:ShowLogin()
    end)

    self.back_btn:setVisible(channel_info.switch_account and not _G["AUTH_MODE"])

    -- 进入游戏
    helper:AddClick(self.enter_btn, function()
        if TARGET_PLATFORM == cc.PLATFORM_OS_WINDOWS or TARGET_PLATFORM == cc.PLATFORM_OS_MAC then
        else
        end
        print("=============>")
        if login_logic:UserLogin(server_list_panel.server_id) then
            self:SetLoadingTime(5)
        end
    end)

    -- 显示服务器列表
    self.view_list_img:addTouchEventListener(function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            server_list_panel:Show()
        end
    end)

    if self.change_user_btn then
        self.change_user_btn:addTouchEventListener(function(widget, event_type)
            if event_type == ccui.TouchEventType.ended then
                audio_manager:PlayEffect("click")

                local channel_info = platform_manager:GetChannelInfo()
                if channel_info.login_has_change_user then
                    if channel_info.meta_channel == "txwy" or channel_info.meta_channel == "txwy_dny" then
                        PlatformSDK.signOut()
                    end
                end
            end
        end)
    end

    if self.user_center_btn then
        self.user_center_btn:addTouchEventListener(function(widget, event_type)
            if event_type == ccui.TouchEventType.ended then
                audio_manager:PlayEffect("click")
                local channel_info = platform_manager:GetChannelInfo()
                if channel_info.login_has_user_center_ex then
                    platform_manager:ShowUserCenterEx()
                end
            end
        end)
    end

    -- 切换语言按钮
    if self.language_btn then
        self.language_btn:addTouchEventListener(function(widget, event_type)
            -- if event_type ~= ccui.TouchEventType.ended then
            --     return
            -- end
            -- audio_manager:PlayEffect("click")
            -- self:ShowLocalePanel()
        end)
    end

    if self.customer_btn then
        self.customer_btn:addTouchEventListener(function(widget, event_type)

            if event_type ~= ccui.TouchEventType.ended then
                return
            end

            audio_manager:PlayEffect("click")
            feedback_manager:ShowFeedback(true)
        end)
    end
end

return login_panel
