local config_manager = require "logic.config_manager"
local constants = require "util.constants"
local audio_manager = require "util.audio_manager"

local graphic = require "logic.graphic"
local troop_logic = require "logic.troop"
local campaign_logic = require "logic.campaign"

local client_constants = require "util.client_constants"
local lang_constants = require "util.language_constants"

local config_manager = require "logic.config_manager"
local helper = require "util.helper"

local panel_prototype = require "ui.panel"
local panel_util = require "ui.panel_util"
local SORT_TYPE = client_constants["SORT_TYPE"]
local SORT_RANGE = client_constants["SORT_RANGE"]

local PLIST_TYPE = ccui.TextureResType.plistType
local mercenary_library_config = config_manager.mercenary_library_config

local MERCENARY_BG_SPRITE = client_constants["MERCENARY_BG_SPRITE"]
local SUB_PANEL_HEIGHT = 124 --佣兵显示的初始位置x
local MERCENARY_GENRE_TEXT = client_constants["MERCENARY_GENRE_TEXT"]
local MERCENARY_GENRE_COLOR = client_constants["MERCENARY_GENRE_COLOR"]

local animation_manager = require "util.animation_manager"
local rainbow_visual = require "util.rainbow_visual"
local MERCENARY_TEMPLATE_SOURCE = client_constants["MERCENARY_TEMPLATE_PANEL_SOURCE"]["list"]

local MERCENARY_FILETER_DESC = {
    [1] = lang_constants:Get("mercenary_library_quality1"),
    [2] = lang_constants:Get("mercenary_library_quality2"),
    [3] = lang_constants:Get("mercenary_library_quality3"),
    [4] = lang_constants:Get("mercenary_library_quality4"),
    [5] = lang_constants:Get("mercenary_library_quality5"),
    [6] = lang_constants:Get("mercenary_library_quality6"),
    [7] = lang_constants:Get("mercenary_library_quality7"),
}

--佣兵子面板
local mercenary_sub_panel = panel_prototype.New()
mercenary_sub_panel.__index = mercenary_sub_panel

function mercenary_sub_panel.New()
    return setmetatable({}, mercenary_sub_panel)
end

function mercenary_sub_panel:Init(root_node)
    self.root_node = root_node
    self.role_img = self.root_node:getChildByName("icon")
    self.fire_num_text = self.root_node:getChildByName("value")
    self.txt_bg_img = self.root_node:getChildByName("txtbg")
    self.genre_text = self.root_node:getChildByName("genre_desc")
    panel_util:SetTextOutline(self.genre_text)

    self.star_node = root_node:getChildByName("star")
    self.star_lbl = self.star_node:getChildByName("value")

    self.root_node:setCascadeColorEnabled(true)
    self.role_img:ignoreContentAdaptWithSize(true)
    self.role_img:setScale(2, 2)
    -- [FIX] 方案A图层顺序：底框 < 彩虹特效(z=1) < 角色(z=5) < 星级/流派/数量(z=10..12)
    self.role_img:setLocalZOrder(5)
    if self.star_node then self.star_node:setLocalZOrder(11) end
    if self.genre_text then self.genre_text:setLocalZOrder(12) end
    if self.txt_bg_img then self.txt_bg_img:setLocalZOrder(10) end
    if self.fire_num_text then self.fire_num_text:setLocalZOrder(12) end

    -- [MOD r10.6] 移除原版蓝环 colorful_hero_general.csb（避免 40+ 次 CSB 解析且彻底消除廉价蓝环），
    -- 改由 rainbow_visual 按需挂载方案 3 皇家鎏金虹纹 + 星样 3 银金星冠托座
    self.effect_node = nil
    self.effect_action = nil
end

--加载佣兵信息
function mercenary_sub_panel:Show(template_info)
    self.root_node:loadTexture(CheckTextureCache(MERCENARY_BG_SPRITE[template_info.quality]), PLIST_TYPE)
    self.role_img:loadTexture(
        CheckTextureCache(client_constants["MERCENARY_ROLE_IMG_PATH"] .. template_info.sprite .. ".png"), PLIST_TYPE)
    self.genre_text:setString(lang_constants:Get(MERCENARY_GENRE_TEXT[template_info.genre]))
    self.genre_text:setColor(panel_util:GetColor4B(MERCENARY_GENRE_COLOR[template_info.genre]))

    local count = troop_logic:GetMercenaryLibraryCount(template_info.ID)
    local is_dimmed = (count == nil)

    if count then
        self.txt_bg_img:setVisible(true)
        self.fire_num_text:setVisible(true)

        self.fire_num_text:setString(count)
        self.root_node:setColor(panel_util:GetColor4B(0xffffff))
    else
        self.txt_bg_img:setVisible(false)
        self.fire_num_text:setVisible(false)
        self.root_node:setColor(panel_util:GetColor4B(0x9A9A9A))
    end

    self.template_id = template_info.ID
    self.root_node:setVisible(true)

    local q = template_info.quality or 0
    if q >= 21 then
        rainbow_visual:ApplyToCard(self.root_node, q, {
            role_img = self.role_img,
            legacy_star_node = self.star_node,
            dimmed = is_dimmed,
            intensity = 0.75,
        })
    else
        rainbow_visual:ClearCard(self.root_node, { role_img = self.role_img })
        local star = q - 30 + 1
        if star > 0 then
            self.star_node:setVisible(true)
            self.star_lbl:setString(star)
        else
            self.star_node:setVisible(false)
        end
    end
end

local mercenary_library_panel = panel_prototype.New()
function mercenary_library_panel:Init()
    self.root_node = (require "util.helper"):Loader("ui/mercenary_library_panel.csb")
    local root_node = self.root_node

    --底部
    local bottom_bar = root_node:getChildByName("bottom_bar")
    self.cur_mercenary_num_text = bottom_bar:getChildByName("value")
    self.cur_mercenary_num_desc_text = bottom_bar:getChildByName("num_desc")
    self.cur_mercenary_num_desc_text:setAnchorPoint(0, 0.5)

    self.back_btn = root_node:getChildByName("back_btn")

    self.scroll_view = self.root_node:getChildByName("scroll_view")
    self.mercenary_template = self.scroll_view:getChildByName("rolebg")
    self.mercenary_template:setVisible(false)

    -- [PC PORT] Guard against a 0x0 ScrollView on some CSB versions.
    local sv_size = self.scroll_view:getContentSize()
    if sv_size.width < 2 or sv_size.height < 2 then
        self.scroll_view:setContentSize(cc.size(600, 700))
    end
    -- [PC PORT] The CSB anchor is (0, 1), so y=1032 is the TOP edge of the
    -- viewport (the list spans 209..1032).  This 3.4 runtime does not render
    -- the clipped inner container for a top-left anchored ScrollView, so the
    -- page looked empty.  Re-anchor to the bottom-left without moving the box.
    self.scroll_view:setAnchorPoint(cc.p(0, 0))
    self.scroll_view:setPosition(0, 209)

    self.sview_height = self.scroll_view:getContentSize().height
    self.sview_width = self.scroll_view:getContentSize().width

    self.sort_btn = bottom_bar:getChildByName("sort_btn")
    self.sort_desc_text = self.sort_btn:getChildByName("desc")
    if self.sort_desc_text then
        self.sort_desc_text:setPositionY(self.sort_desc_text:getPositionY() + 4)
    end

    self.head_sub_panel_y = 0
    self.tail_sub_panel_y = 0
    self.head_sub_panel_index = 0
    self.mercenary_offset = 0
    self.sub_panel_row = 0

    self.mercenary_sub_panels = {}
    self.mercenary_num = 0

    self.already_filter_merceanrys = false
    self.mercenary_filters = { {}, {}, {}, {}, {}, {}, {} }
    self.collect_mercenary_num = 0

    self.show_detail_panel = false
    self:RegisterWidgetEvent()

    self.root_node:PlayAnimation("exit")

    self.name_desc = helper:getChild(self.root_node, "search_btn.name_desc")
    self.name_desc:setVisible(false)
    self.name_textfield = helper:getChild(self.root_node, "search_btn.name_bg.name_textfield")
    self.name_textfield:addEventListener(function(sender, event_type)
        if event_type == ccui.TextFiledEventType.attach_with_ime then
            self.name_desc:setVisible(false)
            -- local x, y = self.name_bg_img:getPosition()
            -- self.focus_tracker:Bind("create_input", x, y, self.name_bg_img)
            -- self.root_node:setPositionY(self.init_y + 220)
        elseif event_type == ccui.TextFiledEventType.detach_with_ime then
            -- self.focus_tracker:Hide()
            -- self.root_node:setPositionY(self.init_y)
        elseif event_type == ccui.TextFiledEventType.insert_text then
            self:MercenaryFilter(self:GetSearchText())
        elseif event_type == ccui.TextFiledEventType.delete_backward then
            self:MercenaryFilter(self:GetSearchText())
        end
    end)

    self.edit_box = helper:ReplaceEditBox(self.name_textfield, "chat_text_placeholder", "bg/weaponbox_infobg2_d.png", 1)
    self.edit_box:setMaxLength(10)
    self.edit_box:registerScriptEditBoxHandler(function(eventType)
        if eventType == "began" then
        elseif eventType == "ended" then
            self:MercenaryFilter(self.edit_box:getString())
        elseif eventType == "changed" then
            self:MercenaryFilter(self.edit_box:getString())
        elseif eventType == "return" then
            self:MercenaryFilter(self.edit_box:getString())
        end
    end)

    self.ok_btn = helper:getChild(self.root_node, "search_btn.ok_btn")
    helper:AddClick(self.ok_btn, function()
        self.root_node:PlayAnimation("exit", function()
            self.name_desc:setVisible(false)
            self:MercenaryFilter(self:GetSearchText())
            self.edit_box:setVisible(false)
        end)
    end)

    self.search_btn = helper:getChild(self.root_node, "bottom_bar.search_btn")
    helper:AddClick(self.search_btn, function()
        self.root_node:PlayAnimation("click")
        self.name_textfield:setString("")
        self.edit_box:setVisible(true)
        self.edit_box:setString("")
    end)

    self:RegisterEvent()
end

-- [PC PORT] ReplaceEditBox puts the real input text in edit_box; the original
-- TextField stays hidden and never receives what the player typed.
function mercenary_library_panel:GetSearchText()
    if self.edit_box then
        return self.edit_box:getString() or ""
    end
    return self.name_textfield:getString() or ""
end

function mercenary_library_panel:MercenaryFilter(filter_name)
    local sort_type = self.sort_type or SORT_TYPE["quality"]
    local sort_range = self.sort_range or SORT_RANGE["all"]
    if filter_name ~= nil and string.len(filter_name) > 0 then
        self:ResetScrollViewAndContent(sort_type, sort_range, filter_name)
    else
        self:ResetScrollViewAndContent(sort_type, sort_range)
    end
end

function mercenary_library_panel:CreateMercenarySubPanels()
    local cur_row = math.min(client_constants["MERCENARY_MAX_PANEL_ROW"], self.cur_mercenary_row)
    if self.sub_panel_row >= cur_row then
        return
    end

    local source = MERCENARY_TEMPLATE_SOURCE
    local begin_x = client_constants["MERCENARY_SUB_PANEL_BEGIN_X"]
    local begin_y = self.height + client_constants["MERCENARY_FIRST_SUB_PANEL_OFFSET"]
    --绑定事件
    for row = self.sub_panel_row + 1, cur_row do
        self.mercenary_sub_panels[row] = {}

        local y = begin_y - (row - 1) * 124
        for col = 1, 5 do
            local sub_panel = mercenary_sub_panel.New()
            sub_panel:Init(self.mercenary_template:clone())
            local tag = (row - 1) * 5 + col

            local x = begin_x + (col - 1) * 124

            sub_panel.root_node:setPosition(x, y)
            sub_panel.root_node:setTag(tag)
            sub_panel.root_node:setVisible(true)
            sub_panel.root_node:setTouchEnabled(true)
            -- [PC PORT] Let drags that start on a card bubble up to the
            -- ScrollView; otherwise the card swallows them and the list
            -- cannot be dragged from anywhere but the 12px gaps.
            if sub_panel.root_node.setPropagateTouchEvents then
                sub_panel.root_node:setPropagateTouchEvents(true)
            end
            sub_panel.root_node:addTouchEventListener(self.view_mercenary_method)

            self.scroll_view:addChild(sub_panel.root_node)

            self.mercenary_sub_panels[row][col] = sub_panel
        end
    end

    self.sub_panel_row = cur_row
end

function mercenary_library_panel:Show()
    local sort_type = self.sort_type or SORT_TYPE["quality"]
    local sort_range = self.sort_range or SORT_RANGE["all"]

    self:ResetScrollViewAndContent(sort_type, sort_range)
    self.root_node:setVisible(true)
end

function mercenary_library_panel:Hide()
    self.root_node:PlayAnimation("exit", function()
        self.name_desc:setVisible(false)
        self:MercenaryFilter(self:GetSearchText())
        self.edit_box:setVisible(false)
    end)
end

function mercenary_library_panel:CalcCollectNum(template_id)
    if troop_logic:GetMercenaryLibraryCount(template_id) then
        self.collect_mercenary_num = self.collect_mercenary_num + 1
    end
end

--将佣兵根据品质不同，筛选
function mercenary_library_panel:FilterMercenary(filter_name)
    local mercenary_num = 0
    local list = {}
    local has_name_filter = filter_name ~= nil and string.len(filter_name) > 0
    self.collect_mercenary_num = 0

    for i, mercenary in pairs(mercenary_library_config) do
        local in_range = false
        if self.sort_range <= SORT_RANGE["quality6"] then
            in_range = mercenary.quality == self.sort_range
        elseif self.sort_range == SORT_RANGE["all"] then --全体佣兵排序
            in_range = true
        elseif self.sort_range == SORT_RANGE["rainbow"] then --彩虹/EX佣兵排序
            in_range = mercenary.quality >= 21
        elseif self.sort_range == SORT_RANGE["campaign"] then --合战佣兵排序
            in_range = campaign_logic:CheckSpecialMercenary(mercenary, true)
        end

        -- [PC PORT] Search and quality filter used to be applied in two separate
        -- passes.  The second pass counted every matching name again (ignoring
        -- the selected quality), inflating 搜集进度 and showing wrong results.
        if in_range and (not has_name_filter or
            string.find(mercenary.name or "", filter_name, 1, true)) then
            mercenary_num = mercenary_num + 1
            list[mercenary_num] = mercenary
            self:CalcCollectNum(mercenary.ID)
        end
    end

    self.mercenary_list = list
    self.mercenary_num = mercenary_num
end

function mercenary_library_panel:ResetScrollViewAndContent(sort_type, sort_range, filter_name)
    self.sort_type = sort_type
    self.sort_range = sort_range

    self:FilterMercenary(filter_name)

    if sort_type == SORT_TYPE["quality"] then
        table.sort(self.mercenary_list, function(mercenary1, mercenary2)
            if mercenary1.quality == mercenary2.quality then
                return mercenary1.ID > mercenary2.ID
            else
                return mercenary1.quality > mercenary2.quality
            end
        end)
    elseif sort_type == SORT_TYPE["genre"] then
        table.sort(self.mercenary_list, function(mercenary1, mercenary2)
            if mercenary1.genre == mercenary2.genre then
                if mercenary1.quality == mercenary2.quality then
                    return mercenary1.ID > mercenary2.ID
                else
                    return mercenary1.quality > mercenary2.quality
                end
            else
                return mercenary1.genre < mercenary2.genre
            end
        end)
    end

    self.cur_mercenary_row = math.ceil(self.mercenary_num / 5)

    local height = math.max(self.cur_mercenary_row * SUB_PANEL_HEIGHT, self.sview_height)
    self.height = height

    self:CreateMercenarySubPanels()

    self.scroll_view:getInnerContainer():setPositionY(self.sview_height - height)
    --setInnerContainerSize会触发scrolling事件
    self.scroll_view:setInnerContainerSize(cc.size(self.sview_width, height))

    self:LoadMercenaryInfo()

    self.sort_desc_text:setString(lang_constants:Get("mercenary_sort_type" .. sort_type))

    self.cur_mercenary_num_text:setString(self.collect_mercenary_num .. "/" .. self.mercenary_num)
end

function mercenary_library_panel:SetHeadSubPanel(index)
    if index > self.sub_panel_row then
        self.head_sub_panel_index = 1
    elseif index < 1 then
        self.head_sub_panel_index = self.sub_panel_row
    else
        self.head_sub_panel_index = index
    end

    if self.sub_panel_row == 0 then
        return
    end

    self.head_sub_panel_y = self.sview_height -
        self.mercenary_sub_panels[self.head_sub_panel_index][1].root_node:getPositionY()
end

function mercenary_library_panel:LoadMercenaryInfo()
    self.mercenary_offset = 0
    self.scroll_view:getInnerContainer():setPositionY(self.sview_height - self.height)

    local begin_y = self.height + client_constants["MERCENARY_FIRST_SUB_PANEL_OFFSET"]
    for row = 1, self.sub_panel_row do
        if row <= self.cur_mercenary_row then
            --设定位置和加载信息
            local y = begin_y - (row - 1) * 124
            self:ShowSingleRowMercenary(row, row, y)
        else
            --隐藏
            for col = 1, 5 do
                self.mercenary_sub_panels[row][col]:Hide()
            end
        end
    end

    self:SetHeadSubPanel(1)
end

function mercenary_library_panel:ShowSingleRowMercenary(mercenary_row, sub_panel_row, pos_y)
    for col = 1, 5 do
        local tag = self:CalcMercenaryIndex(mercenary_row, col)

        local sub_panel = self.mercenary_sub_panels[sub_panel_row][col]
        local mercenary = self.mercenary_list[tag]

        if tag <= self.mercenary_num then
            sub_panel:Show(mercenary)
        else
            sub_panel.root_node:setVisible(false)
        end

        if pos_y then
            sub_panel.root_node:setPositionY(pos_y)
        end
    end
end

--根据row, col 返回index
function mercenary_library_panel:CalcMercenaryIndex(row, col)
    return (row - 1) * 5 + col
end

--根据索引值返回row , index
function mercenary_library_panel:CalcRowAndCol(index)
    local row = math.ceil(index / 5)
    local col = index - (row - 1) * 5
    return row, col
end

function mercenary_library_panel:RegisterWidgetEvent()
    --查看某一佣兵信息
    self.view_mercenary_method = function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            local index = widget:getTag()

            if index > self.mercenary_num then
                return
            end

            local row, col = self:CalcRowAndCol(index)
            self.cur_sub_panel = self.mercenary_sub_panels[row][col]
            self.cur_template_id = self.cur_sub_panel.template_id

            if not self.cur_template_id then
                return
            end

            local mode = client_constants["MERCENARY_DETAIL_MODE"]["library"]
            graphic:DispatchEvent("show_world_sub_panel", "mercenary_detail_panel", mode, self.cur_template_id)
        end
    end

    self.scroll_view:addEventListener(function(lview, event_type)
        -- CCLOG("scrolling.....",event_type)

        if event_type == ccui.ScrollViewEventType.scrolling or event_type == ccui.ScrollViewEventType.containerMoved then
            local y = self.scroll_view:getInnerContainer():getPositionY()
            -- CCLOG("scrolling.....",y)

            if y >= self.head_sub_panel_y + SUB_PANEL_HEIGHT * 0.5 then
                if self.mercenary_offset + self.sub_panel_row >= self.cur_mercenary_row then

                else
                    self.mercenary_offset = self.mercenary_offset + 1
                    local last_sub_panel_index = self.sub_panel_row
                    if self.head_sub_panel_index ~= 1 then
                        last_sub_panel_index = self.head_sub_panel_index - 1
                    end

                    --重新设定位置
                    local y = self.mercenary_sub_panels[last_sub_panel_index][1].root_node:getPositionY() -
                        SUB_PANEL_HEIGHT

                    --重新load info
                    self:ShowSingleRowMercenary(self.mercenary_offset + self.sub_panel_row, self.head_sub_panel_index, y)

                    self:SetHeadSubPanel(self.head_sub_panel_index + 1)
                end
            elseif y < self.head_sub_panel_y - SUB_PANEL_HEIGHT * 0.5 then
                if self.mercenary_offset == 0 then

                else
                    self.mercenary_offset = self.mercenary_offset - 1

                    local last_sub_panel_index = self.sub_panel_row
                    if self.head_sub_panel_index ~= 1 then
                        last_sub_panel_index = self.head_sub_panel_index - 1
                    end

                    --重新设定位置
                    local y = self.mercenary_sub_panels[self.head_sub_panel_index][1].root_node:getPositionY() +
                        SUB_PANEL_HEIGHT
                    --重新load info
                    self:ShowSingleRowMercenary(self.mercenary_offset + 1, last_sub_panel_index, y)
                    self:SetHeadSubPanel(self.head_sub_panel_index - 1)
                end
            end
        end
    end)

    --显示排序面板
    self.sort_btn:addTouchEventListener(function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            local source = client_constants["SORT_PANEL_SOURCE"]["library"]
            graphic:DispatchEvent("show_world_sub_panel", "mercenary_sort_panel", source, self.sort_type, self
                .sort_range, function(sort_type, sort_range)
                    self:ResetScrollViewAndContent(sort_type, sort_range, self:GetSearchText())
                end)
        end
    end)


    --返回
    self.back_btn:addTouchEventListener(function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            graphic:DispatchEvent("hide_world_sub_scene")
            self.root_node:PlayAnimation("exit", function()
                self.name_desc:setVisible(false)
                self:MercenaryFilter(self:GetSearchText())
                self.edit_box:setVisible(false)
            end)
        end
    end)
end

function mercenary_library_panel:RegisterEvent()
    --图书馆招募成功
    graphic:RegisterEvent("library_recruit_success", function(template_id)
        if not self.root_node:isVisible() then
            return
        end

        for i = 1, self.sub_panel_row do
            local item_row = 0
            if i < self.head_sub_panel_index then
                item_row = self.mercenary_offset + (self.sub_panel_row - self.head_sub_panel_index) + i + 1
            else
                item_row = self.mercenary_offset + i - self.head_sub_panel_index + 1
            end

            self:ShowSingleRowMercenary(item_row, i)
        end
    end)

    --图书馆中有新的佣兵
    graphic:RegisterEvent("library_new_mercenary", function(mercenary)
        if not self.root_node:isVisible() then
            return
        end

        -- [PC PORT] Rebuild the visible list so a newly discovered mercenary
        -- shows its unlocked card immediately and 搜集进度 is recalculated.
        self:ResetScrollViewAndContent(self.sort_type or SORT_TYPE["quality"],
            self.sort_range or SORT_RANGE["all"], self:GetSearchText())
    end)
end

return mercenary_library_panel
