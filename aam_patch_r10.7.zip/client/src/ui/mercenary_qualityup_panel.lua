-- [MOD r10.3] 佣兵升星/进阶 · 方案 A：1A 原生像素羊皮纸单页一体化升星工作台
-- 顶部常驻库存条（彩虹碎片 102 / 升星石 108 / 灵魂碎片 3）+ 上半区实时对比与一键升星 + 下半区可滚动筛选选人池；
-- 兼容既有入口与事件（mercenary_qualityup_sub_scene / mercenary_quality_up_choose / mercenary_quality_up_success）。
local constants = require "util.constants"
local audio_manager = require "util.audio_manager"
local config_manager = require "logic.config_manager"
local graphic = require "logic.graphic"
local troop_logic = require "logic.troop"
local resource_logic = require "logic.resource"
local client_constants = require "util.client_constants"
local panel_prototype = require "ui.panel"
local panel_util = require "ui.panel_util"
local pixel_kit = require "ui.pixel_kit"
local helper = require "util.helper"

local PLIST_TYPE = ccui.TextureResType.plistType
local FONT = client_constants["FONT_FACE"]
local RES_SOUL = constants.RESOURCE_TYPE["soul_chip"] or 3
local RES_CONTRACT = constants.RESOURCE_TYPE["contract_stone"] or 35
local RES_RAINBOW = constants.RESOURCE_TYPE["rainbow_soul_chip"] or 102
local RES_STAR = constants.RESOURCE_TYPE["hight_rainbow_soul_chip"] or 108

local FILTERS = {
    { key = "ready", label = "可升星" },
    { key = "owned", label = "已拥有" },
    { key = "step1", label = "0★→1★" },
    { key = "step2", label = "1★→2★" },
    { key = "all",   label = "全部" },
}

local function IsMercenaryInAnyFormation(instance_id)
    if not instance_id then
        return false
    end
    for _, form in pairs(troop_logic.formations or {}) do
        if type(form) == "table" then
            for _, m in ipairs(form) do
                if m and m.instance_id == instance_id then
                    return true
                end
            end
        end
    end
    return false
end

local function QualityLabel(q)
    q = tonumber(q) or 0
    if q == 31 then return "彩★★" end
    if q == 30 then return "彩★" end
    if q == 21 then return "彩0★" end
    if q == 6 then return "闪金" end
    return "Q" .. tostring(q)
end

local meta = panel_prototype.New()

function meta:Init()
    self.root_node = helper:Loader("ui/mercenary_qualityup_panel.csb")
    self.back_btn = self.root_node:getChildByName("back_btn")
    self.info_btn = self.root_node:getChildByName("btn_info")
    self.quality_up_btn = self.root_node:getChildByName("btn_qualityup")
    self.txt_quality_up_desc = self.root_node:getChildByName("desc_qualityup")
    self.template_up = self.root_node:getChildByName("template_up")
    self.template_upinfo = self.root_node:getChildByName("template_upinfo")

    -- 隐藏原版旧控件，改由 1A 单页工作台统一接管
    for _, old in ipairs({ self.quality_up_btn, self.txt_quality_up_desc, self.template_up, self.template_upinfo }) do
        if old then old:setVisible(false) end
    end

    self.cur_filter = "owned"
    self.selected_template_id = nil
    self.selected_instance_id = nil
    self.selected_inst_idx = 1

    self:BuildWorkbenchUI()
    self:RegisterWidgetEvent()
    self:RegisterEvent()
end

function meta:BuildWorkbenchUI()
    -- 全屏暗木质背景容器（避免旧 CSB 残留穿帮）
    local layer = ccui.Layout:create()
    layer:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
    layer:setBackGroundColor(cc.c3b(42, 33, 25))
    layer:setBackGroundColorOpacity(255)
    layer:setContentSize(cc.size(640, 1136))
    layer:setPosition(0, 0)
    self.root_node:addChild(layer, 40)
    self.wb_layer = layer

    -- 顶部标题栏（避开全局顶部资源 HUD 区域 y=1068..1136，置于 y=1008..1064）
    local top_bar = ccui.Layout:create()
    top_bar:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
    top_bar:setBackGroundColor(cc.c3b(62, 46, 32))
    top_bar:setBackGroundColorOpacity(255)
    top_bar:setContentSize(cc.size(640, 56))
    top_bar:setPosition(0, 1008)
    layer:addChild(top_bar, 5)

    local title_lbl = ccui.Text:create("佣兵升星工坊", FONT, 25)
    title_lbl:setPosition(320, 28)
    title_lbl:setColor(cc.c3b(255, 228, 130))
    panel_util:SetTextOutline(title_lbl)
    top_bar:addChild(title_lbl)

    -- 顶部返回 & 规则按钮
    top_bar:addChild(pixel_kit:CreateButton({
        style = "grey",
        title = "返 回",
        font_size = 17,
        size = cc.size(96, 38),
        pos = cc.p(62, 28),
        on_click = function()
            graphic:DispatchEvent("hide_world_sub_scene")
        end,
    }))
    top_bar:addChild(pixel_kit:CreateButton({
        style = "gold",
        title = "规 则",
        font_size = 17,
        size = cc.size(96, 38),
        pos = cc.p(578, 28),
        on_click = function()
            graphic:DispatchEvent("show_world_sub_panel", "mercenary_qualityup_rule_msgbox")
        end,
    }))

    -- 隐藏旧 back_btn / info_btn 防止误触双响应
    if self.back_btn then self.back_btn:setVisible(false) end
    if self.info_btn then self.info_btn:setVisible(false) end

    -- 常驻材料库存条 (y = 969..1003)
    local stock_bar = ccui.Layout:create()
    stock_bar:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
    stock_bar:setBackGroundColor(cc.c3b(30, 22, 16))
    stock_bar:setBackGroundColorOpacity(240)
    stock_bar:setContentSize(cc.size(616, 34))
    stock_bar:setAnchorPoint(0.5, 0.5)
    stock_bar:setPosition(320, 986)
    layer:addChild(stock_bar, 5)

    self.stock_lbl = ccui.Text:create("", FONT, 16)
    self.stock_lbl:setPosition(308, 17)
    self.stock_lbl:setColor(cc.c3b(255, 226, 136))
    stock_bar:addChild(self.stock_lbl)

    -- =====================================================================
    -- 上半区：羊皮纸预览与升星操作卡 (y = 529..963, 高度 434)
    -- =====================================================================
    local cw = 616
    local card = pixel_kit:CreatePaperCard(layer, {
        width = cw,
        height = 434,
        pos = cc.p(320, 746),
        z_order = 5,
    })
    self.preview_card = card

    -- 未选中时的空状态提示
    self.empty_tip_lbl = ccui.Text:create("请在下方列表点击一名佣兵，实时查看升星条件与消耗", FONT, 20)
    self.empty_tip_lbl:setPosition(cw * 0.5, 220)
    self.empty_tip_lbl:setColor(cc.c3b(104, 68, 30))
    card:addChild(self.empty_tip_lbl)

    -- 详情内容节点
    local detail_node = cc.Node:create()
    card:addChild(detail_node, 2)
    self.detail_node = detail_node

    -- 左右头像框 + 箭头
    local function make_portrait(x)
        local bg = ccui.Layout:create()
        bg:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
        bg:setBackGroundColor(cc.c3b(44, 32, 22))
        bg:setBackGroundColorOpacity(235)
        bg:setContentSize(cc.size(96, 96))
        bg:setAnchorPoint(0.5, 0.5)
        bg:setPosition(x, 368)
        detail_node:addChild(bg)
        local img = ccui.ImageView:create()
        img:setPosition(48, 48)
        img:setScale(1.65)
        bg:addChild(img)
        local nm = ccui.Text:create("", FONT, 17)
        nm:setPosition(x, 306)
        panel_util:SetTextOutline(nm)
        detail_node:addChild(nm)
        return img, nm
    end
    self.left_icon, self.left_name = make_portrait(148)
    self.right_icon, self.right_name = make_portrait(468)

    local arrow_lbl = ccui.Text:create("==> 升星 ==>", FONT, 20)
    arrow_lbl:setPosition(cw * 0.5, 376)
    arrow_lbl:setColor(cc.c3b(166, 92, 16))
    detail_node:addChild(arrow_lbl)

    -- 多实例切换按钮（同模板拥有多只时显示）
    self.switch_inst_btn = pixel_kit:CreateButton({
        style = "gold",
        title = "切换实例",
        font_size = 14,
        size = cc.size(124, 30),
        pos = cc.p(cw * 0.5, 336),
        on_click = function()
            self:SwitchNextInstance()
        end,
    })
    detail_node:addChild(self.switch_inst_btn)

    -- 宝具四维对比条
    self.stats_cmp_lbl = ccui.Text:create("", FONT, 16)
    self.stats_cmp_lbl:setPosition(cw * 0.5, 278)
    self.stats_cmp_lbl:setColor(cc.c3b(62, 42, 18))
    detail_node:addChild(self.stats_cmp_lbl)

    -- 4 项前置条件条（觉醒 / 宝具 / 武具 / 契约）
    local cond_bg = ccui.Layout:create()
    cond_bg:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
    cond_bg:setBackGroundColor(cc.c3b(42, 31, 21))
    cond_bg:setBackGroundColorOpacity(225)
    cond_bg:setContentSize(cc.size(cw - 28, 56))
    cond_bg:setAnchorPoint(0.5, 0.5)
    cond_bg:setPosition(cw * 0.5, 228)
    detail_node:addChild(cond_bg)

    self.cond_labels = {}
    local cond_w = (cw - 28) / 4
    for i = 1, 4 do
        local lbl = ccui.Text:create("", FONT, 16)
        lbl:setPosition(cond_w * (i - 0.5), 37)
        cond_bg:addChild(lbl)
        self.cond_labels[i] = lbl
    end
    self.form_status_lbl = ccui.Text:create("", FONT, 15)
    self.form_status_lbl:setPosition((cw - 28) * 0.5, 14)
    cond_bg:addChild(self.form_status_lbl)

    -- 消耗明细区（灵魂石可点击去合成 + 资源明细）
    local cost_bg = ccui.Layout:create()
    cost_bg:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
    cost_bg:setBackGroundColor(cc.c3b(52, 38, 26))
    cost_bg:setBackGroundColorOpacity(225)
    cost_bg:setContentSize(cc.size(cw - 28, 106))
    cost_bg:setAnchorPoint(0.5, 0.5)
    cost_bg:setPosition(cw * 0.5, 138)
    detail_node:addChild(cost_bg)

    local cost_title = ccui.Text:create("升星材料消耗（点击灵魂石可快捷合成）：", FONT, 15)
    cost_title:setAnchorPoint(0, 0.5)
    cost_title:setPosition(12, 91)
    cost_title:setColor(cc.c3b(255, 224, 138))
    cost_bg:addChild(cost_title)

    self.soul_btns = {}
    local sb_w = 182
    for i = 1, 3 do
        local sbtn = pixel_kit:CreateButton({
            style = "grey",
            title = "",
            font_size = 14,
            size = cc.size(sb_w, 34),
            pos = cc.p(12 + sb_w * 0.5 + (i - 1) * (sb_w + 10), 60),
            on_click = function()
                local tid = self.soul_btn_tids and self.soul_btn_tids[i]
                if tid and tid > 0 then
                    graphic:DispatchEvent("show_world_sub_panel", "mercenary_soul_stone_panel", tid, "craft")
                end
            end,
        })
        cost_bg:addChild(sbtn)
        self.soul_btns[i] = sbtn
    end

    self.res_cost_lbl = ccui.Text:create("", FONT, 15)
    self.res_cost_lbl:setPosition((cw - 28) * 0.5, 22)
    self.res_cost_lbl:setColor(cc.c3b(242, 232, 206))
    cost_bg:addChild(self.res_cost_lbl)

    -- 主升星按钮 + 快捷详情按钮
    self.do_up_btn = pixel_kit:CreateButton({
        style = "green",
        title = "立 即 升 星",
        font_size = 21,
        size = cc.size(260, 48),
        pos = cc.p(cw * 0.5 - 76, 44),
        on_click = function()
            self:OnClickStarUp()
        end,
    })
    detail_node:addChild(self.do_up_btn)

    self.open_detail_btn = pixel_kit:CreateButton({
        style = "gold",
        title = "去培养/查看",
        font_size = 17,
        size = cc.size(144, 48),
        pos = cc.p(cw * 0.5 + 150, 44),
        on_click = function()
            if self.selected_instance_id then
                local mode = client_constants["MERCENARY_DETAIL_MODE"]["formation"]
                graphic:DispatchEvent("show_world_sub_panel", "mercenary_detail_panel", mode, self.selected_instance_id)
            end
        end,
    })
    detail_node:addChild(self.open_detail_btn)

    -- =====================================================================
    -- 下半区：筛选标签 + 原生可滚动多列选人池 (避开底部导航栏 y=0..138)
    -- =====================================================================
    self.filter_btns = {}
    local fw = 114
    local fgap = 8
    local fx0 = 320 - (5 * fw + 4 * fgap) * 0.5 + fw * 0.5
    for idx, f in ipairs(FILTERS) do
        local btn = pixel_kit:CreateButton({
            style = f.key == self.cur_filter and "gold" or "grey",
            title = f.label,
            font_size = 16,
            size = cc.size(fw, 38),
            pos = cc.p(fx0 + (idx - 1) * (fw + fgap), 504),
            on_click = function()
                self.cur_filter = f.key
                self:RefreshFilterButtons()
                self:RebuildRosterList()
            end,
        })
        layer:addChild(btn, 6)
        self.filter_btns[idx] = btn
    end

    local list_bg = ccui.Layout:create()
    list_bg:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
    list_bg:setBackGroundColor(cc.c3b(30, 22, 16))
    list_bg:setBackGroundColorOpacity(235)
    list_bg:setContentSize(cc.size(616, 336))
    list_bg:setPosition(12, 142)
    layer:addChild(list_bg, 5)

    local sv = ccui.ScrollView:create()
    sv:setDirection(ccui.ScrollViewDir.vertical)
    sv:setBounceEnabled(true)
    sv:setContentSize(cc.size(608, 328))
    sv:setPosition(4, 4)
    list_bg:addChild(sv)
    self.roster_sv = sv
end

function meta:EvaluateEntry(template_id)
    local conf = config_manager.mercenary_quality_config[template_id]
    if not conf or tonumber(conf.open) ~= 1 or not conf.af_ID then
        return nil
    end
    local cur_cfg = config_manager.mercenary_config[template_id]
    local next_cfg = config_manager.mercenary_config[conf.af_ID]
    if not cur_cfg or not next_cfg then
        return nil
    end
    local owned_list = troop_logic:GetMercenaryListByTempId(template_id) or {}
    -- 按培养度优先排序：未上阵且条件达标排最前
    table.sort(owned_list, function(a, b)
        local ai = IsMercenaryInAnyFormation(a.instance_id) and 1 or 0
        local bi = IsMercenaryInAnyFormation(b.instance_id) and 1 or 0
        if ai ~= bi then return ai < bi end
        local as = (a.wakeup or 0) + (a.artifact_lv or 0) + (a.weapon_lv or 0) + (a.contract_lv or 0) * 10
        local bs = (b.wakeup or 0) + (b.artifact_lv or 0) + (b.weapon_lv or 0) + (b.contract_lv or 0) * 10
        if as ~= bs then return as > bs end
        return (a.instance_id or 0) < (b.instance_id or 0)
    end)

    -- 检查材料是否充足
    local mat_ok = true
    for i = 1, 3 do
        local stid = tonumber(conf["soul_type" .. i]) or 0
        local snum = tonumber(conf["soul_num" .. i]) or 0
        if stid > 0 and snum > 0 then
            if (troop_logic:GetMercenaryLibraryCount(stid) or 0) < snum then
                mat_ok = false
            end
        end
    end
    local res_checks = {
        { RES_SOUL, tonumber(conf.soul_chip) or 0 },
        { RES_RAINBOW, tonumber(conf.rainbow_soul_chip) or 0 },
        { RES_STAR, tonumber(conf.hight_rainbow_soul_chip) or 0 },
        { RES_CONTRACT, tonumber(conf.contract_stone) or 0 },
    }
    for _, rc in ipairs(res_checks) do
        if rc[2] > 0 and (resource_logic:GetResourceNum(rc[1]) or 0) < rc[2] then
            mat_ok = false
        end
    end

    local best_inst = owned_list[1]
    local cond_ok = false
    local in_form = false
    if best_inst then
        in_form = IsMercenaryInAnyFormation(best_inst.instance_id)
        cond_ok = (tonumber(best_inst.wakeup) or 0) >= (tonumber(conf.wakeup_lv) or 0)
            and (tonumber(best_inst.artifact_lv) or 0) >= (tonumber(conf.artifavt_lv) or 0)
            and (tonumber(best_inst.weapon_lv) or 0) >= (tonumber(conf.forge_lv) or 0)
            and (tonumber(best_inst.contract_lv) or 0) >= (tonumber(conf.contract_lv) or 0)
    end

    local ready = (best_inst ~= nil) and (not in_form) and cond_ok and mat_ok
    return {
        template_id = template_id,
        conf = conf,
        cur_cfg = cur_cfg,
        next_cfg = next_cfg,
        owned_list = owned_list,
        owned_count = #owned_list,
        cond_ok = cond_ok,
        mat_ok = mat_ok,
        in_form = in_form,
        ready = ready,
    }
end

function meta:CollectEntries()
    local all = {}
    for tid, _ in pairs(config_manager.mercenary_quality_config or {}) do
        if type(tid) == "number" then
            local e = self:EvaluateEntry(tid)
            if e then
                all[#all + 1] = e
            end
        end
    end
    local filtered = {}
    for _, e in ipairs(all) do
        local keep = true
        if self.cur_filter == "ready" then
            keep = e.ready
        elseif self.cur_filter == "owned" then
            keep = e.owned_count > 0
        elseif self.cur_filter == "step1" then
            keep = (e.next_cfg.quality == 30 or e.next_cfg.quality == 21)
        elseif self.cur_filter == "step2" then
            keep = (e.next_cfg.quality == 31)
        end
        if keep then
            filtered[#filtered + 1] = e
        end
    end
    table.sort(filtered, function(a, b)
        local ar = a.ready and 4 or (a.owned_count > 0 and a.cond_ok and 3 or (a.owned_count > 0 and 2 or 1))
        local br = b.ready and 4 or (b.owned_count > 0 and b.cond_ok and 3 or (b.owned_count > 0 and 2 or 1))
        if ar ~= br then return ar > br end
        if a.cur_cfg.quality ~= b.cur_cfg.quality then return a.cur_cfg.quality > b.cur_cfg.quality end
        return a.template_id < b.template_id
    end)
    return filtered, all
end

function meta:RefreshStockBar()
    local rb = resource_logic:GetResourceNum(RES_RAINBOW) or 0
    local st = resource_logic:GetResourceNum(RES_STAR) or 0
    local sc = resource_logic:GetResourceNum(RES_SOUL) or 0
    local cs = resource_logic:GetResourceNum(RES_CONTRACT) or 0
    self.stock_lbl:setString(string.format("彩虹碎片：%d   |   升星石：%d   |   灵魂碎片：%d   |   契约石：%d", rb, st, sc, cs))
end

function meta:RefreshFilterButtons()
    for idx, f in ipairs(FILTERS) do
        pixel_kit:ApplyButtonStyle(self.filter_btns[idx], f.key == self.cur_filter and "gold" or "grey")
    end
end

function meta:RebuildRosterList()
    local entries = self:CollectEntries()
    self.roster_entries = entries
    self.roster_sv:removeAllChildren()

    if #entries == 0 then
        local empty = ccui.Text:create("当前筛选条件下暂无可升星佣兵，可切换顶部「全部」查看图鉴", FONT, 18)
        empty:setPosition(304, 170)
        empty:setColor(cc.c3b(190, 174, 148))
        self.roster_sv:addChild(empty)
        self.roster_sv:setInnerContainerSize(cc.size(608, 328))
        return
    end

    local cols = 4
    local cell_w, cell_h = 144, 126
    local rows = math.max(1, math.ceil(#entries / cols))
    local inner_h = math.max(328, rows * cell_h + 14)
    self.roster_sv:setInnerContainerSize(cc.size(608, inner_h))

    for idx, e in ipairs(entries) do
        local r = math.floor((idx - 1) / cols)
        local col = (idx - 1) % cols
        local cx = 8 + col * (cell_w + 5) + cell_w * 0.5
        local cy = inner_h - 8 - r * cell_h - cell_h * 0.5
        local is_sel = (self.selected_template_id == e.template_id)

        local bg = ccui.Layout:create()
        bg:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
        if is_sel then
            bg:setBackGroundColor(cc.c3b(126, 94, 32))
        elseif e.ready then
            bg:setBackGroundColor(cc.c3b(44, 78, 38))
        elseif e.owned_count > 0 then
            bg:setBackGroundColor(cc.c3b(64, 48, 34))
        else
            bg:setBackGroundColor(cc.c3b(42, 34, 28))
        end
        bg:setBackGroundColorOpacity(240)
        bg:setContentSize(cc.size(cell_w, cell_h - 6))
        bg:setAnchorPoint(0.5, 0.5)
        bg:setPosition(cx, cy)
        bg:setTouchEnabled(true)
        bg:addTouchEventListener(function(_, et)
            if et == ccui.TouchEventType.ended then
                audio_manager:PlayEffect("click")
                self.selected_template_id = e.template_id
                self.selected_inst_idx = 1
                self.selected_instance_id = e.owned_list[1] and e.owned_list[1].instance_id or nil
                self:RefreshPreview()
                self:RebuildRosterList()
            end
        end)
        self.roster_sv:addChild(bg)

        local frame = CheckTextureCache(client_constants["MERCENARY_ROLE_IMG_PATH"] .. tostring(e.cur_cfg.sprite) .. ".png")
        local img = ccui.ImageView:create()
        pcall(function() img:loadTexture(frame, PLIST_TYPE) end)
        img:setPosition(cell_w * 0.5, 76)
        img:setScale(1.3)
        if e.owned_count == 0 then
            img:setOpacity(115)
        end
        bg:addChild(img)

        -- 左上星阶标记
        local stag = ccui.Text:create(QualityLabel(e.cur_cfg.quality) .. "→" .. QualityLabel(e.next_cfg.quality), FONT, 12)
        stag:setAnchorPoint(0, 0.5)
        stag:setPosition(6, cell_h - 16)
        stag:setColor(cc.c3b(255, 224, 122))
        bg:addChild(stag)

        -- 名称
        local nm = ccui.Text:create(tostring(e.cur_cfg.name), FONT, 14)
        nm:setPosition(cell_w * 0.5, 34)
        nm:setColor(e.owned_count > 0 and cc.c3b(255, 246, 220) or cc.c3b(160, 150, 136))
        bg:addChild(nm)

        -- 状态角标
        local status_txt, status_col
        if e.ready then
            status_txt, status_col = "可立即升星", cc.c3b(161, 224, 27)
        elseif e.owned_count > 0 and e.in_form then
            status_txt, status_col = "上阵中(需下阵)", cc.c3b(245, 211, 31)
        elseif e.owned_count > 0 and e.cond_ok then
            status_txt, status_col = "缺升星材料", cc.c3b(248, 146, 56)
        elseif e.owned_count > 0 then
            status_txt, status_col = string.format("培养中(x%d)", e.owned_count), cc.c3b(242, 180, 96)
        else
            status_txt, status_col = "未拥有", cc.c3b(136, 128, 116)
        end
        local st_lbl = ccui.Text:create(status_txt, FONT, 13)
        st_lbl:setPosition(cell_w * 0.5, 14)
        st_lbl:setColor(status_col)
        bg:addChild(st_lbl)
    end
end

function meta:SwitchNextInstance()
    if not self.selected_template_id then return end
    local list = troop_logic:GetMercenaryListByTempId(self.selected_template_id) or {}
    if #list <= 1 then return end
    self.selected_inst_idx = (self.selected_inst_idx % #list) + 1
    self.selected_instance_id = list[self.selected_inst_idx].instance_id
    self:RefreshPreview()
end

function meta:RefreshPreview()
    self:RefreshStockBar()
    local e = self.selected_template_id and self:EvaluateEntry(self.selected_template_id) or nil
    if not e then
        self.empty_tip_lbl:setVisible(true)
        self.detail_node:setVisible(false)
        return
    end
    self.empty_tip_lbl:setVisible(false)
    self.detail_node:setVisible(true)

    -- 确认当前选中实例
    local inst = nil
    if self.selected_instance_id then
        inst = troop_logic:GetMercenaryInfo(self.selected_instance_id)
        if inst and inst.template_id ~= e.template_id then
            inst = nil
        end
    end
    if not inst and e.owned_count > 0 then
        self.selected_inst_idx = math.max(1, math.min(e.owned_count, self.selected_inst_idx or 1))
        inst = e.owned_list[self.selected_inst_idx]
        self.selected_instance_id = inst and inst.instance_id or nil
    end

    -- 头像与名称
    local lf = CheckTextureCache(client_constants["MERCENARY_ROLE_IMG_PATH"] .. tostring(e.cur_cfg.sprite) .. ".png")
    local rf = CheckTextureCache(client_constants["MERCENARY_ROLE_IMG_PATH"] .. tostring(e.next_cfg.sprite) .. ".png")
    pcall(function() self.left_icon:loadTexture(lf, PLIST_TYPE) end)
    pcall(function() self.right_icon:loadTexture(rf, PLIST_TYPE) end)
    self.left_name:setString(tostring(e.cur_cfg.name))
    self.left_name:setColor(panel_util:GetColor4B(client_constants["TEXT_QUALITY_COLOR"][e.cur_cfg.quality] or 0xffffff))
    self.right_name:setString(tostring(e.next_cfg.name))
    self.right_name:setColor(panel_util:GetColor4B(client_constants["TEXT_QUALITY_COLOR"][e.next_cfg.quality] or 0xffffff))

    if e.owned_count > 1 then
        self.switch_inst_btn:setVisible(true)
        self.switch_inst_btn:setTitleText(string.format("切换实例 %d/%d", self.selected_inst_idx, e.owned_count))
    else
        self.switch_inst_btn:setVisible(false)
    end

    -- 宝具四维变化
    local function fmt_delta(lbl, a, b)
        a, b = tonumber(a) or 0, tonumber(b) or 0
        local d = b - a
        return d > 0 and string.format("%s %d→%d(+%d)", lbl, a, b, d) or string.format("%s %d", lbl, b)
    end
    self.stats_cmp_lbl:setString(table.concat({
        fmt_delta("先攻", e.cur_cfg.artifact_speed, e.next_cfg.artifact_speed),
        fmt_delta("防御", e.cur_cfg.artifact_defense, e.next_cfg.artifact_defense),
        fmt_delta("闪避", e.cur_cfg.artifact_dodge, e.next_cfg.artifact_dodge),
        fmt_delta("王者", e.cur_cfg.artifact_authority, e.next_cfg.artifact_authority),
    }, "   "))

    -- 4 项条件
    local conf = e.conf
    local reqs = {
        { "觉醒", inst and inst.wakeup or 0, tonumber(conf.wakeup_lv) or 0 },
        { "宝具", inst and inst.artifact_lv or 0, tonumber(conf.artifavt_lv) or 0 },
        { "武具", inst and inst.weapon_lv or 0, tonumber(conf.forge_lv) or 0 },
        { "契约", inst and inst.contract_lv or 0, tonumber(conf.contract_lv) or 0 },
    }
    local cond_ok = (inst ~= nil)
    for i = 1, 4 do
        local cur_v = tonumber(reqs[i][2]) or 0
        local need_v = tonumber(reqs[i][3]) or 0
        local ok = (inst ~= nil) and (cur_v >= need_v)
        if not ok then cond_ok = false end
        self.cond_labels[i]:setString(string.format("%s %d/%d", reqs[i][1], cur_v, need_v))
        self.cond_labels[i]:setColor(ok and cc.c3b(161, 224, 27) or cc.c3b(248, 127, 38))
    end

    local in_form = inst and IsMercenaryInAnyFormation(inst.instance_id) or false
    if not inst then
        self.form_status_lbl:setString("尚未拥有该佣兵（可前往图鉴或心愿祈愿池获取）")
        self.form_status_lbl:setColor(cc.c3b(210, 195, 165))
    elseif in_form then
        self.form_status_lbl:setString("当前正在阵容上阵中 · 请先在阵容界面下阵后再升星")
        self.form_status_lbl:setColor(cc.c3b(245, 211, 31))
    elseif cond_ok then
        self.form_status_lbl:setString("全部培养条件已达标 · 可直接消耗材料升星")
        self.form_status_lbl:setColor(cc.c3b(161, 224, 27))
    else
        self.form_status_lbl:setString("部分培养条件未达标 · 可点右侧「去培养/查看」补齐")
        self.form_status_lbl:setColor(cc.c3b(248, 146, 56))
    end

    -- 灵魂石与资源消耗
    self.soul_btn_tids = {}
    local mat_ok = true
    for i = 1, 3 do
        local stid = tonumber(conf["soul_type" .. i]) or 0
        local snum = tonumber(conf["soul_num" .. i]) or 0
        local btn = self.soul_btns[i]
        if stid > 0 and snum > 0 then
            local mc = config_manager.mercenary_config[stid]
            local have = troop_logic:GetMercenaryLibraryCount(stid) or 0
            local ok = have >= snum
            if not ok then mat_ok = false end
            self.soul_btn_tids[i] = stid
            btn:setVisible(true)
            btn:setTitleText(string.format("%s魂 %d/%d", mc and mc.name or tostring(stid), have, snum))
            pixel_kit:ApplyButtonStyle(btn, ok and "green" or "orange")
        else
            self.soul_btn_tids[i] = 0
            btn:setVisible(false)
        end
    end

    local res_parts = {}
    local res_defs = {
        { RES_SOUL, "灵魂碎片", tonumber(conf.soul_chip) or 0 },
        { RES_RAINBOW, "彩虹碎片", tonumber(conf.rainbow_soul_chip) or 0 },
        { RES_STAR, "升星石", tonumber(conf.hight_rainbow_soul_chip) or 0 },
        { RES_CONTRACT, "契约石", tonumber(conf.contract_stone) or 0 },
    }
    for _, rd in ipairs(res_defs) do
        if rd[3] > 0 then
            local have = resource_logic:GetResourceNum(rd[1]) or 0
            local ok = have >= rd[3]
            if not ok then mat_ok = false end
            res_parts[#res_parts + 1] = string.format("%s %d/%d%s", rd[2], have, rd[3], ok and "" or "(不足)")
        end
    end
    self.res_cost_lbl:setString(#res_parts > 0 and table.concat(res_parts, "   ") or "无额外资源消耗")
    self.res_cost_lbl:setColor(mat_ok and cc.c3b(176, 236, 98) or cc.c3b(255, 168, 92))

    self.cur_can_star_up = (inst ~= nil) and (not in_form) and cond_ok and mat_ok
    self.cur_block_reason = (not inst and "尚未拥有该佣兵")
        or (in_form and "该佣兵正在上阵中，请先下阵后再升星")
        or (not cond_ok and "培养条件尚未全部达标")
        or (not mat_ok and "升星材料不足（可点击上方灵魂石快捷合成）")
        or nil
    pixel_kit:ApplyButtonStyle(self.do_up_btn, self.cur_can_star_up and "green" or "grey")
    self.do_up_btn:setTitleText(self.cur_can_star_up and "立 即 升 星" or (in_form and "需 先 下 阵" or "条 件 不 足"))
    self.open_detail_btn:setVisible(inst ~= nil)
    self.do_up_btn:setPositionX(inst ~= nil and (616 * 0.5 - 76) or (616 * 0.5))
end

function meta:OnClickStarUp()
    if not self.cur_can_star_up or not self.selected_instance_id then
        pixel_kit:ShowToast(self.cur_block_reason or "暂不满足升星条件", 0xf87f26)
        return
    end
    troop_logic:DoQualityUp(self.selected_instance_id)
end

function meta:SelectQualityUpMercenary(instance_id)
    local inst = instance_id and troop_logic:GetMercenaryInfo(instance_id) or nil
    if inst then
        self.selected_template_id = inst.template_id
        self.selected_instance_id = inst.instance_id
        local list = troop_logic:GetMercenaryListByTempId(inst.template_id) or {}
        self.selected_inst_idx = 1
        for i, m in ipairs(list) do
            if m.instance_id == inst.instance_id then
                self.selected_inst_idx = i
                break
            end
        end
    end
    self:RefreshFilterButtons()
    self:RebuildRosterList()
    self:RefreshPreview()
end

function meta:Show(cur_mercenary)
    self.root_node:setVisible(true)
    if cur_mercenary then
        self.cur_filter = "owned"
        self:SelectQualityUpMercenary(cur_mercenary)
        return
    end
    -- 自动默认选中第一名可升星或已拥有的佣兵，零空屏！
    local owned_entries, all_entries = self:CollectEntries()
    if #owned_entries == 0 and self.cur_filter ~= "all" then
        self.cur_filter = "all"
        owned_entries = all_entries
    end
    if not self.selected_template_id and owned_entries[1] then
        self.selected_template_id = owned_entries[1].template_id
        self.selected_instance_id = owned_entries[1].owned_list[1] and owned_entries[1].owned_list[1].instance_id or nil
        self.selected_inst_idx = 1
    end
    self:RefreshFilterButtons()
    self:RebuildRosterList()
    self:RefreshPreview()
end

function meta:RegisterWidgetEvent()
end

function meta:RegisterEvent()
    graphic:RegisterEvent("mercenary_quality_up_choose", function(instance_id)
        self:SelectQualityUpMercenary(instance_id)
    end)

    graphic:RegisterEvent("mercenary_quality_up_success", function(mercenary_id)
        -- 升星成功后优先停留该佣兵并自动切入下一星阶（支持 0★→1★→2★ 连续升星）
        local upgraded = troop_logic:GetMercenaryInfo(mercenary_id)
        if upgraded and config_manager.mercenary_quality_config[upgraded.template_id] then
            self:SelectQualityUpMercenary(mercenary_id)
        else
            self.selected_template_id = nil
            self.selected_instance_id = nil
            self:Show()
        end
        graphic:DispatchEvent("show_world_sub_panel", "mercenary_get_template", mercenary_id)
    end)

    for _, ev in ipairs({ "update_resource_list", "craft_soul_stone_success2", "library_recruit_success" }) do
        graphic:RegisterEvent(ev, function()
            if self.root_node and self.root_node:isVisible() then
                self:RebuildRosterList()
                self:RefreshPreview()
            end
        end)
    end
end

return meta
