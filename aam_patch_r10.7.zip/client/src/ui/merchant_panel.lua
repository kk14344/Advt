local panel_prototype = require "ui.panel"
local panel_util = require "ui.panel_util"
local pixel_kit = require "ui.pixel_kit"

local constants = require "util.constants"
local client_constants = require "util.client_constants"
local audio_manager = require "util.audio_manager"
local lang_constants = require "util.language_constants"

local graphic = require "logic.graphic"
local resource_logic = require "logic.resource"
local merchant_logic = require "logic.merchant"
local time_logic = require "logic.time"
local icon_template = require "ui.icon_panel"
local platform_manager = require "logic.platform_manager"
local feature_config = require "logic.feature_config"

local REWARD_TYPE = constants["REWARD_TYPE"]
local RESOURCE_TYPE = constants["RESOURCE_TYPE"]
local jump_logic = require 'logic.jump'
local JUMP_CONST = client_constants["JUMP_CONST"] 

local PLIST_TYPE = ccui.TextureResType.plistType

local RANDOM_KEY_ICON = client_constants["RANDOM_KEY_ICON"]
local RANDOM_KEY_QUALITY = 5
local RANDOM_KEY_NAME = lang_constants:Get("random_key_name")
local RANDOM_KEY_DESC = lang_constants:Get("random_key_desc")

local DARK_TAB_SHOW = constants.MERCHANT_TYPE["DARK"]
local WHITE_TAB_SHOW = constants.MERCHANT_TYPE["WHITE"]

local TAB_NOT_CLICKED_COLOR = 0x7F7F7F
local TAB_CLICKED_COLOR = 0xFFFFFF

local order_sub_panel = panel_prototype.New()
order_sub_panel.__index = order_sub_panel

function order_sub_panel.New()
    return setmetatable({}, order_sub_panel)
end

function order_sub_panel:Init(root_node, merchant_type)
    self.root_node = root_node
    self.merchant_type = merchant_type
    self.need_icon_panels = {}
    self.order_id = nil 

    for i = 1, 2 do
        local icon_panel = icon_template.New()
        icon_panel:Init(root_node)
        self.need_icon_panels[i] = icon_panel
        self.need_icon_panels[i].root_node:setScale(0.5, 0.5)
    end
    self.need_icon_panels[1].root_node:setPosition(50, 34)
    self.need_icon_panels[2].root_node:setPosition(90, 34)

    self.reward_icon_panel = icon_template.New()
    self.reward_icon_panel:Init(root_node)
    self.reward_icon_panel.root_node:setScale(0.5, 0.5)
    self.reward_icon_panel.root_node:setPosition(176, 34)

    self.exchange_btn = root_node:getChildByName("exchange_btn")
    self:RegisterWidgetEvent()
end

function order_sub_panel:Show(order_info)
    -- 每个订单有一个列表记录该订单缺少的资源 
    self.less_resources = {} 
    self.cost_list = {}
    for i = 1, 2 do
        local resource_type = order_info["need_type" .. i]

        if resource_type and resource_type ~= 0 then
            -- 资源跳转
            if not resource_logic:CheckResourceNum(resource_type, order_info["need_num" .. i], false,true) then
                local less_cost = {}
                less_cost["resourceId"] = resource_type
                less_cost["costNum"] = order_info["need_num" .. i]
                table.insert(self.less_resources,less_cost)  
            end
            
            local cost = {}
            cost["resourceId"] = resource_type
            cost["costNum"] = order_info["need_num" .. i]
            table.insert(self.cost_list,cost)

            self.need_icon_panels[i]:Show(REWARD_TYPE["resource"], resource_type, order_info["need_num" .. i], true)
        else
            self.need_icon_panels[i].root_node:setVisible(false)
        end
    end

    local reward_info = order_info.reward_info[1]
    self.reward_icon_panel:Show(reward_info.reward_type , reward_info.param1, reward_info.param2)

    self.root_node:setVisible(true)
end

function order_sub_panel:GetOrderId()
    return self.order_id 
end

function order_sub_panel:SetOrderId(id)
    self.order_id = id
end

function order_sub_panel:SetVisible(flag)
    self.root_node:setVisible(flag)
end

function order_sub_panel:SetAnchorPoint(point)
    self.root_node:setAnchorPoint(point)
end  

function order_sub_panel:SetPosition(x, y)
    self.root_node:setPosition(x, y)
end

function order_sub_panel:SetButtonColor(color)
    self.exchange_btn:setColor(panel_util:GetColor4B(color))
end

function order_sub_panel:SetButtonTitle(title_name)
    self.exchange_btn:setTitleText(title_name)
end

function order_sub_panel:RegisterWidgetEvent()
    self.exchange_btn:addTouchEventListener(function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")

            local merchant_types = self.merchant_type
            if self.merchant_type == constants.MERCHANT_TYPE["dark1"] or self.merchant_type == constants.MERCHANT_TYPE["dark2"] or self.merchant_type == constants.MERCHANT_TYPE["dark3"] then
                 merchant_types = constants.MERCHANT_TYPE["DARK"]
            end

            --  如果资源缺失列表中元素大于0 而且开关打开  还有必须是在表中配置过的,如果没有配置过的话,则走原来的流程
            -- if feature_config:IsFeatureOpen("resource_jump") and #self.less_resources > 0 and jump_logic:GetJumpResources()[self.less_resources[1]] then  
            --     graphic:DispatchEvent("show_jump_panel",self.less_resources[1])  
            -- else
            if merchant_logic:IsExchange(self.order_id, self.merchant_type) then
                if self.merchant_type == constants.MERCHANT_TYPE["WHITE"] then
                    --血钻兑换
                    local mode = client_constants.CONFIRM_MSGBOX_MODE["merchant_exchange"]
                    graphic:DispatchEvent("show_world_sub_panel", "confirm_msgbox", mode, self.order_id, self.cost_list)
                else
                    -- [PC PORT] Pass the complete cost list so the client can
                    -- deduct every required resource after a successful trade.
                    merchant_logic:Exchange(self.order_id, self.merchant_type, self.cost_list)
                end
            end
                
            -- end
        end
    end)
end

local merchant_tab = panel_prototype.New()
merchant_tab.__index = merchant_tab

function merchant_tab.New()
    return setmetatable({}, merchant_tab)
end

function merchant_tab:Init(parent_node, merchant_type)
    self.merchant_type = merchant_type
    self.exchange_btn = nil
    self.duration = 0
    if self.merchant_type == DARK_TAB_SHOW then 
       self.root_node = parent_node:getChildByName("black_tab")
       self.bottom_node = parent_node:getChildByName("bonus_node_b")
       self.exchange_btn = self.bottom_node:getChildByName("ext_exchange_btn")
       self.bottom_node:getChildByName("bonus_icon_a"):setVisible(false)
       self.bottom_node:getChildByName("bonus_icon_b"):setVisible(false)
       self.exchange_btn:setTouchEnabled(true)
    elseif self.merchant_type == WHITE_TAB_SHOW then 
       self.root_node = parent_node:getChildByName("white_tab")
       self.bottom_node = parent_node:getChildByName("bonus_node_w")
    end

    self.root_node:setTag(self.merchant_type)
    self.root_node:setTouchEnabled(true)
    self.root_node:setCascadeColorEnabled(true)

    self.tab_text = self.root_node:getChildByName("name")
    self.tab_text:setCascadeColorEnabled(true)
    self.back_btn = self.bottom_node:getChildByName("back_btn")
    self.back_btn:setTouchEnabled(true)
    self.refresh_btn = self.bottom_node:getChildByName("refresh_btn")
    self.reset_time_text = self.refresh_btn:getChildByName("refresh_time")
    self.refresh_btn:setTouchEnabled(true)

    self:RegisterWidgetEvent()
end

function merchant_tab:Update(time)
    self.duration = self.duration - time
    self:SetTimeText()
end

function merchant_tab:SetDurationTime(time)
    self.duration = time
end

function merchant_tab:SetTimeText()
    self.reset_time_text:setString(panel_util:GetTimeStr(self.duration))
end

function merchant_tab:SetTabColor(color)
    self.root_node:setColor(panel_util:GetColor4B(color))
    panel_util:SetTextPureColor(self.tab_text, color)
end

function merchant_tab:Show()
    self.root_node:setVisible(true)
    self.bottom_node:setVisible(true)
end
        
function merchant_tab:SetBottomVisible(flag)
    self.bottom_node:setVisible(flag)
end

function merchant_tab:GetBottomNode()
    return self.bottom_node
end

function merchant_tab:SetExchangeButtonVisible(flag)
    if self.exchange_btn then
       self.exchange_btn:setVisible(flag)
    end
end

function merchant_tab:SetExchangeButtonColor(color)
    if self.exchange_btn then
       self.exchange_btn:setColor(panel_util:GetColor4B(color))
    end
end

function merchant_tab:Clear()
    self.root_node:removeAllChildren()
    self.bottom_node:removeAllChildren()
end

function merchant_tab:Hide()
    self.root_node:setVisible(false)
    self.bottom_node:setVisible(false)
end

function merchant_tab:RegisterWidgetEvent()
    --重置时间
    self.refresh_btn:addTouchEventListener(function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            local mode = client_constants["CONFIRM_MSGBOX_MODE"]["refresh_order"]
            graphic:DispatchEvent("show_world_sub_panel", "confirm_msgbox", mode, self.merchant_type)
        end
    end)

    if self.exchange_btn then
        --获取额外奖励
        self.exchange_btn:addTouchEventListener(function(widget, event_type)
            if event_type == ccui.TouchEventType.ended then
                audio_manager:PlayEffect("click")
                if not merchant_logic:CanCollectSoulChip() then
                    graphic:DispatchEvent("show_prompt_panel", "merchant_finish_all_order_first")
                else
                    merchant_logic:CollectSoulChip()
                end
            end
        end)
    end

    -- 返回
    self.back_btn:addTouchEventListener(function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            graphic:DispatchEvent("hide_world_sub_scene")
        end
    end)

end

local merchant_panel = panel_prototype.New()

function merchant_panel:Init()
    self.root_node = (require "util.helper"):Loader("ui/merchant_panel.csb")
    self.scroll_view = self.root_node:getChildByName("scrollview")
    self.dark_bonus_panels = {}
    self.tab_node = { [DARK_TAB_SHOW] = {}, [WHITE_TAB_SHOW] = {}}
    self.order_sub_panels = {[DARK_TAB_SHOW] = {}, [WHITE_TAB_SHOW] = {}}
   
    for i = 1, #self.tab_node do 
        self.tab_node[i] = merchant_tab.New()
        self.tab_node[i]:Init(self.root_node, i)
    end
    
    self.tab_node[DARK_TAB_SHOW]:SetTabColor(TAB_CLICKED_COLOR)

    self.tab_node[WHITE_TAB_SHOW]:SetTabColor(TAB_NOT_CLICKED_COLOR)
    self.tab_node[WHITE_TAB_SHOW]:SetBottomVisible(false)
    self.scroll_view:setVisible(false)

    self.show_tab = DARK_TAB_SHOW

    local begin_x = 492
    for i = 1, 2 do
        local sub_panel = icon_template.New()
        sub_panel:Init(self.tab_node[DARK_TAB_SHOW]:GetBottomNode())
        sub_panel.root_node:setPosition(begin_x + (i - 1) * 83, 536)
        self.dark_bonus_panels[i] = sub_panel
    end

    local order_panel = self.root_node:getChildByName("order_bg")
    local order_panel_init_x, order_panel_init_y = order_panel:getPosition()
    order_panel:setVisible(false)
    local scroll_view_size = self.scroll_view:getContentSize()
    local scroll_view_half_width = scroll_view_size.width/2

    for tab_i = 1, #self.tab_node do 
       for i = 1, 3 do
          self.order_sub_panels[tab_i][i] = order_sub_panel.New()
          self.order_sub_panels[tab_i][i]:Init(order_panel:clone(), tab_i)

          if tab_i == DARK_TAB_SHOW then
            self.order_sub_panels[tab_i][i]:SetPosition(order_panel_init_x, order_panel_init_y - (i-1) * 188)
            self.root_node:addChild(self.order_sub_panels[tab_i][i]:GetRootNode())

          elseif tab_i == WHITE_TAB_SHOW then
            self.order_sub_panels[tab_i][i]:SetAnchorPoint(cc.p(0.5, 1))
            self.order_sub_panels[tab_i][i]:SetPosition(scroll_view_half_width, scroll_view_size.height - (i-1) * 188)
            self.scroll_view:addChild(self.order_sub_panels[tab_i][i]:GetRootNode())
          end
       end
    end

    --r2界面要隐藏按钮上的bonus图标
    local merchant_panel_hide_button_icon=platform_manager:GetChannelInfo().merchant_panel_hide_button_icon
    if merchant_panel_hide_button_icon then
        local get_btn_icon = self.root_node:getChildByName("bonus_node_b"):getChildByName("ext_exchange_btn"):getChildByName("bonus_1")
        get_btn_icon:setVisible(false)
        local bonus_icon = self.root_node:getChildByName("bonus_node_b"):getChildByName("bonus")
        bonus_icon:setVisible(false)
    end

    self:BuildWhiteAutoControls()

    self:RegisterEvent()
    self:RegisterWidgetEvent()
end

function merchant_panel:BuildWhiteAutoControls()
    local white_tab = self.tab_node[WHITE_TAB_SHOW]
    local bottom = white_tab:GetBottomNode()

    local back_x, btn_y = white_tab.back_btn:getPosition()
    local ref_x = white_tab.refresh_btn:getPositionX()
    local mid_x = (back_x + ref_x) * 0.5

    self.one_click_buy_btn = pixel_kit:CreateButton({
        style = "green",
        title = "一键全买",
        size = cc.size(138, 54),
        pos = cc.p(mid_x - 74, btn_y),
        font_size = 21,
        on_click = function()
            if self.auto_state.running then
                self:StopAutoBuy("已手动停止", true)
            else
                self:StartAutoBuy("buy_once", 0)
            end
        end,
    })
    bottom:addChild(self.one_click_buy_btn, 10)

    self.auto_loop_btn = pixel_kit:CreateButton({
        style = "gold",
        title = "自动刷购",
        size = cc.size(138, 54),
        pos = cc.p(mid_x + 74, btn_y),
        font_size = 21,
        on_click = function()
            if self.auto_state.running then
                self:StopAutoBuy("已手动停止", true)
            else
                self:ShowAutoBuyInputDialog()
            end
        end,
    })
    bottom:addChild(self.auto_loop_btn, 10)

    -- 自动刷购实时进度条（运行时浮于底部按钮上方）
    self.auto_status_bg, self.auto_status_lbl = pixel_kit:CreateStatusBanner(bottom, {
        width = 560,
        height = 38,
        pos = cc.p(320, btn_y + 54),
        font_size = 19,
        color = 0xffdf73,
        visible = false,
        z_order = 12,
    })

    self.auto_state = {
        running = false,
        mode = nil,
        target_refreshes = 0,
        refreshed = 0,
        bought = 0,
        spent_bd = 0,
        waiting_rsp = false,
        wait_elapsed = 0,
        cooldown = 0,
    }
end

function merchant_panel:UpdateAutoBuyUI()
    local st = self.auto_state
    if not st or not self.auto_loop_btn then
        return
    end
    if st.running then
        self.auto_status_bg:setVisible(true)
        if st.mode == "auto_loop" then
            self.auto_loop_btn:setTitleText(string.format("停止(%d/%d)", st.refreshed, st.target_refreshes))
            self.auto_status_lbl:setString(string.format("自动刷购中：刷新 %d/%d · 购入 %d 件 · 耗 %d 血钻",
                st.refreshed, st.target_refreshes, st.bought, st.spent_bd))
        else
            self.auto_loop_btn:setTitleText("停止购买")
            self.auto_status_lbl:setString(string.format("一键全买中：已购 %d 件 · 耗 %d 血钻", st.bought, st.spent_bd))
        end
        pixel_kit:ApplyButtonStyle(self.auto_loop_btn, "orange")
        pixel_kit:ApplyButtonStyle(self.one_click_buy_btn, "grey")
    else
        self.auto_status_bg:setVisible(false)
        self.auto_loop_btn:setTitleText("自动刷购")
        pixel_kit:ApplyButtonStyle(self.auto_loop_btn, "gold")
        pixel_kit:ApplyButtonStyle(self.one_click_buy_btn, "green")
    end
end

function merchant_panel:StartAutoBuy(mode, target_refreshes)
    if self.show_tab ~= WHITE_TAB_SHOW then
        return
    end
    local st = self.auto_state
    st.running = true
    st.mode = mode
    st.target_refreshes = math.max(0, math.floor(tonumber(target_refreshes) or 0))
    st.refreshed = 0
    st.bought = 0
    st.spent_bd = 0
    st.waiting_rsp = false
    st.wait_elapsed = 0
    st.cooldown = 0.05
    merchant_logic.auto_silent = true
    self:UpdateAutoBuyUI()
end

function merchant_panel:StopAutoBuy(reason, show_summary)
    local st = self.auto_state
    if not st or not st.running then
        merchant_logic.auto_silent = false
        return
    end
    local summary = {
        reason = reason or "自动刷购完成",
        mode = st.mode,
        refreshed = st.refreshed,
        bought = st.bought,
        spent_bd = st.spent_bd,
    }
    st.running = false
    st.waiting_rsp = false
    merchant_logic.auto_silent = false
    self:UpdateAutoBuyUI()
    if show_summary and self.root_node:isVisible() then
        self:ShowAutoSummaryDialog(summary)
    end
end

function merchant_panel:StepAutoBuy()
    local st = self.auto_state
    if not st or not st.running or st.waiting_rsp then
        return
    end
    if self.show_tab ~= WHITE_TAB_SHOW or not self.root_node:isVisible() then
        self:StopAutoBuy("已离开神秘商店", false)
        return
    end

    local order_num = merchant_logic:GetOrderNum(WHITE_TAB_SHOW) or 0
    for i = 1, order_num do
        local order_info = merchant_logic:GetOrderInfo(i, WHITE_TAB_SHOW)
        if order_info and not order_info.is_done then
            local cost_list = {}
            for k = 1, 2 do
                local rtype = order_info["need_type" .. k]
                local rnum = order_info["need_num" .. k]
                if rtype and rtype ~= 0 and rnum and rnum > 0 then
                    table.insert(cost_list, { resourceId = rtype, costNum = rnum })
                end
            end
            local ok = merchant_logic:Exchange(order_info.order_id, WHITE_TAB_SHOW, cost_list)
            if ok then
                st.waiting_rsp = true
                st.wait_elapsed = 0
            else
                self:StopAutoBuy("血钻不足，已自动停止", true)
            end
            return
        end
    end

    -- 当前页 3 单全部买完
    if st.mode == "buy_once" then
        self:StopAutoBuy("当前商品已全部购入", true)
        return
    end

    if st.refreshed >= st.target_refreshes then
        self:StopAutoBuy("已完成设定的刷新次数", true)
        return
    end

    local ok = merchant_logic:Reset(WHITE_TAB_SHOW)
    if ok then
        st.waiting_rsp = true
        st.wait_elapsed = 0
    else
        self:StopAutoBuy("血钻不足，无法继续刷新", true)
    end
end

function merchant_panel:ShowAutoBuyInputDialog()
    if self.auto_input_dlg and self.auto_input_dlg.Close then
        self.auto_input_dlg:Close()
        self.auto_input_dlg = nil
    end

    local dlg = pixel_kit:CreateDialog(self.root_node, {
        title = "神秘商店 · 自动刷购",
        width = 556,
        height = 468,
        z_order = 200,
        on_close = function()
            self.auto_input_dlg = nil
        end,
    })
    self.auto_input_dlg = dlg
    local inner = dlg.inner
    local iw = dlg.inner_w
    local top_y = dlg.content_top

    -- 1A 原生羊皮纸内卡
    local paper_h = top_y - 72
    pixel_kit:CreatePaperCard(inner, {
        width = iw,
        height = paper_h,
        pos = cc.p(iw * 0.5, 68 + paper_h * 0.5),
        z_order = 1,
    })

    inner:addChild(pixel_kit:CreateLabel(
        "每轮自动全买当前商品并刷新（背包满自动转邮件）\n请输入自定义刷新次数 (1 ~ 9999)",
        {
            font_size = 17,
            color = 0x5b4827,
            align = cc.TEXT_ALIGNMENT_CENTER,
            pos = cc.p(iw * 0.5, top_y - 42),
            outline = false,
        }
    ), 2)

    local function readCnt(tf)
        local raw = string.gsub(tf:getString() or "", "%D", "")
        return tonumber(raw) or 50
    end
    local stepper = pixel_kit:CreateStepper(inner, {
        pos = cc.p(iw * 0.5, top_y - 116),
        height = 48,
        btn_width = 48,
        box_width = 160,
        gap = 10,
        value = "50",
        placeholder = "请输入次数",
        max_length = 4,
        font_size = 24,
        on_minus = function(tf)
            local v = math.max(1, readCnt(tf) - 10)
            tf:setString(tostring(v))
        end,
        on_plus = function(tf)
            local v = math.min(9999, readCnt(tf) + 10)
            tf:setString(tostring(v))
        end,
    })
    local tf = stepper.tf

    local presets = { 10, 50, 100, 500 }
    for idx, val in ipairs(presets) do
        inner:addChild(pixel_kit:CreateButton({
            style = "gold",
            title = val .. "次",
            font_size = 19,
            size = cc.size(102, 42),
            pos = cc.p(iw * 0.5 + (idx - 2.5) * 112, top_y - 190),
            on_click = function()
                tf:setString(tostring(val))
            end,
        }), 3)
    end

    inner:addChild(pixel_kit:CreateButton({
        style = "grey",
        title = "取 消",
        font_size = 22,
        size = cc.size(168, 52),
        pos = cc.p(iw * 0.28, 30),
        on_click = function()
            dlg:Close()
        end,
    }), 3)

    inner:addChild(pixel_kit:CreateButton({
        style = "green",
        title = "开始刷购",
        font_size = 22,
        size = cc.size(188, 52),
        pos = cc.p(iw * 0.70, 30),
        on_click = function()
            local raw = string.gsub(tf:getString() or "", "%D", "")
            local count = tonumber(raw) or 0
            if count < 1 then
                count = 1
            elseif count > 9999 then
                count = 9999
            end
            dlg:Close()
            self:StartAutoBuy("auto_loop", count)
        end,
    }), 3)
end

function merchant_panel:ShowAutoSummaryDialog(summary)
    if self.auto_summary_dlg and self.auto_summary_dlg.Close then
        self.auto_summary_dlg:Close()
        self.auto_summary_dlg = nil
    end

    local dlg = pixel_kit:CreateDialog(self.root_node, {
        title = summary.mode == "buy_once" and "一键全买汇总" or "自动刷购汇总",
        width = 500,
        height = 380,
        z_order = 210,
        on_close = function()
            self.auto_summary_dlg = nil
        end,
    })
    self.auto_summary_dlg = dlg
    local inner = dlg.inner
    local iw = dlg.inner_w
    local top_y = dlg.content_top

    local paper_h = top_y - 72
    pixel_kit:CreatePaperCard(inner, {
        width = iw,
        height = paper_h,
        pos = cc.p(iw * 0.5, 68 + paper_h * 0.5),
        z_order = 1,
    })

    local body = string.format("%s\n\n刷新次数：%d 次\n购入商品：%d 件\n累计消耗：%d 血钻",
        summary.reason or "完成",
        summary.refreshed or 0,
        summary.bought or 0,
        summary.spent_bd or 0)
    inner:addChild(pixel_kit:CreateLabel(body, {
        font_size = 20,
        color = 0x2b1f0e,
        align = cc.TEXT_ALIGNMENT_CENTER,
        pos = cc.p(iw * 0.5, 68 + paper_h * 0.5),
        outline = false,
    }), 2)

    inner:addChild(pixel_kit:CreateButton({
        style = "gold",
        title = "确 定",
        font_size = 23,
        size = cc.size(184, 52),
        pos = cc.p(iw * 0.5, 30),
        on_click = function()
            dlg:Close()
        end,
    }), 3)
end

function merchant_panel:SetDarkOrdersVisible(flag)
    for i = 1, #self.order_sub_panels[DARK_TAB_SHOW] do 
        self.order_sub_panels[DARK_TAB_SHOW][i]:SetVisible(flag)
    end
end

function merchant_panel:LoadTab(new_tab)
    local new_tab = new_tab or 0

    if new_tab > 0 then 
       if self.auto_state and self.auto_state.running and new_tab ~= WHITE_TAB_SHOW then
           self:StopAutoBuy("已切换标签页", false)
       end
       self:SwitchTabShow(false)
       self.show_tab = new_tab
    end

    self:LoadInfo()
    self:SwitchTabShow(true)
end

function merchant_panel:SwitchTabShow(flag)
    local tab_color = TAB_NOT_CLICKED_COLOR
    if flag then 
        tab_color = TAB_CLICKED_COLOR
    end

    if self.show_tab == DARK_TAB_SHOW then 
        self:SetDarkOrdersVisible(flag)

    elseif self.show_tab == WHITE_TAB_SHOW then 
        self.scroll_view:setVisible(flag)
    end

    self.tab_node[self.show_tab]:SetTabColor(tab_color)
    self.tab_node[self.show_tab]:SetBottomVisible(flag)
end

function merchant_panel:Show()
    self:LoadTab()
    self.root_node:setVisible(true)
end

function merchant_panel:LoadInfo()
    local order_num = merchant_logic:GetOrderNum(self.show_tab)

    --订单
    for i = 1, 3 do
        local sub_panel = self.order_sub_panels[self.show_tab][i]
        if i <= order_num then
            local order_info = merchant_logic:GetOrderInfo(i, self.show_tab)
            sub_panel:Show(order_info)
            sub_panel:SetOrderId(order_info.order_id)
        
            if order_info.is_done then
                sub_panel:SetButtonColor(0x7f7f7f)
                sub_panel:SetButtonTitle(lang_constants:Get("merchant_order_btn2"))
            else
                sub_panel:SetButtonColor(0xffffff)
                sub_panel:SetButtonTitle(lang_constants:Get("merchant_order_btn1"))
            end
        else
            sub_panel:Hide()
        end
    end

    if self.show_tab == DARK_TAB_SHOW then 
        --额外奖励
        if platform_manager:GetChannelInfo().merchant_show_reward_box then
            self.dark_bonus_panels[1]:Load(REWARD_TYPE["resource"], 'icon/festival/chest.png', RANDOM_KEY_QUALITY, 1,RANDOM_KEY_NAME, RANDOM_KEY_DESC, false)
        else
            if merchant_logic.chest_key_id == 0 then
                self.dark_bonus_panels[1]:Load(REWARD_TYPE["resource"], RANDOM_KEY_ICON, RANDOM_KEY_QUALITY, 1,RANDOM_KEY_NAME, RANDOM_KEY_DESC, false)
            else
                self.dark_bonus_panels[1]:Show(REWARD_TYPE["resource"], merchant_logic.chest_key_id, merchant_logic.chest_key_num, false, false)
            end
        end

        if merchant_logic.extra_soul_chip_num > 0 then
            self.dark_bonus_panels[2]:Show(REWARD_TYPE["resource"], RESOURCE_TYPE["soul_chip"], merchant_logic.extra_soul_chip_num, false, false)
        else
            self.dark_bonus_panels[2].root_node:setVisible(false)
        end
        self.tab_node[DARK_TAB_SHOW]:SetExchangeButtonVisible(true) 

        self:UpdateExtra()
    end

    --更新刷新时间
    self.tab_node[self.show_tab]:SetDurationTime(merchant_logic:GetResetTime(self.show_tab) - time_logic:Now())
    self.tab_node[self.show_tab]:SetTimeText()
end

function merchant_panel:UpdateExtra()
    if merchant_logic.has_collected_soul_chip then
        self.tab_node[DARK_TAB_SHOW]:SetExchangeButtonVisible(false)
        self.tab_node[DARK_TAB_SHOW]:SetExchangeButtonColor(0x7f7f7f)  
    else
        self.tab_node[DARK_TAB_SHOW]:SetExchangeButtonVisible(true) 
        self.tab_node[DARK_TAB_SHOW]:SetExchangeButtonColor(0xffffff) 
    end
end

function merchant_panel:Hide()
    if self.auto_state and self.auto_state.running then
        self:StopAutoBuy("已关闭界面", false)
    end
    self.root_node:setVisible(false)
end

function merchant_panel:Update(elapsed_time)
    self.tab_node[self.show_tab]:Update(elapsed_time)
    local st = self.auto_state
    if st and st.running then
        if st.waiting_rsp then
            st.wait_elapsed = (st.wait_elapsed or 0) + elapsed_time
            if st.wait_elapsed > 5.0 then
                self:StopAutoBuy("请求超时，已自动停止", true)
            end
        else
            st.cooldown = (st.cooldown or 0) - elapsed_time
            if st.cooldown <= 0 then
                st.cooldown = 0.18
                self:StepAutoBuy()
            end
        end
    end
end

function merchant_panel:RegisterWidgetEvent()
    -- tab
    local tab_touch_event = function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            
            local tab_type = widget:getTag()
            self:LoadTab(tab_type)
        end
    end
    
    for i = 1, #self.tab_node do 
        self.tab_node[i]:GetRootNode():addTouchEventListener(tab_touch_event)
    end
end

function merchant_panel:RegisterEvent()
    graphic:RegisterEvent("update_merchant_info", function(update_type, order_id, merchant_type)
        if not self.root_node:isVisible() then
            return
        end

        self:LoadInfo()

        if update_type == "order" then
            for i = 1, 3 do
                if self.order_sub_panels[merchant_type][i]:GetOrderId() == order_id then
                    self.order_sub_panels[merchant_type][i]:SetButtonColor(0x7f7f7f) 
                    self.order_sub_panels[merchant_type][i]:SetButtonTitle(lang_constants:Get("merchant_order_btn2"))
                end
            end

            self:UpdateExtra()
        elseif update_type == "extra" then
            --已经领取完额外奖励
            self:UpdateExtra()
        end
    end)

    graphic:RegisterEvent("update_resource_list", function()
        if not self.root_node:isVisible() then
            return
        end
        self:RefreshResource()
    end)

    graphic:RegisterEvent("merchant_auto_step_done", function(action, ok, spent_bd, result)
        local st = self.auto_state
        if not st or not st.running then
            return
        end
        st.waiting_rsp = false
        st.wait_elapsed = 0
        if ok then
            st.spent_bd = st.spent_bd + (tonumber(spent_bd) or 0)
            if action == "exchange" then
                st.bought = st.bought + 1
            elseif action == "reset" then
                st.refreshed = st.refreshed + 1
            end
            st.cooldown = 0.18
            self:UpdateAutoBuyUI()
        else
            local reason = "操作中止"
            if result == "not_enough_resource" then
                reason = "血钻不足，已自动停止"
            elseif result == "not_enough_all_num" then
                reason = "今日刷新次数已达上限"
            end
            self:StopAutoBuy(reason, true)
        end
    end)
end

function merchant_panel:RefreshResource()
    if self.order_sub_panels then
        for _index,order in pairs(self.order_sub_panels[DARK_TAB_SHOW]) do
            if order.need_icon_panels then
                for k,v in pairs(order.need_icon_panels) do
                    local resourceType = v:GetIconResourceType()
                    if resource_logic:IsResourceUpdated(resourceType) then
                        v:SetTextStatus(resourceType)
                    end
                end
            end
        end
    end
end

return merchant_panel
