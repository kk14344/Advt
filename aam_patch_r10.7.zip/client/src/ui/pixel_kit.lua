-- 统一原生像素风 UI 组件库（方案 1A 原版复刻精修版）
-- 100% 复用 res/ui/ui.plist 原生九宫格资产：
--   外框 bg/box_bg.png (精确 50/56 切片) + 内卡 bg/paper_bg1.png + 关闭键 button/close1_normal.png
--   全站统一同轮廓按钮家族：绿 buttonbg_4 / 金 buttonbg_5 / 橙 buttonbg_6 / 灰 buttonbg_12
--   同系加减步进器 CreateStepper (- / 数值框 / + 严格同高对齐)
local client_constants = require "util.client_constants"
local audio_manager = require "util.audio_manager"
local panel_util = require "ui.panel_util"

local PLIST_TYPE = ccui.TextureResType.plistType
local FONT_FACE = client_constants["FONT_FACE"]

local pixel_kit = {}

-- 物理返回键拦截栈：每个元素 { node = cc.Node, close = function() }
pixel_kit._overlay_stack = {}

-- 全站统一像素按钮样式表（零 setColor 脏色染色，四色同形同立体底边）
local BUTTON_STYLES = {
    green = {
        texture = "button/buttonbg_4.png",
        cap_insets = cc.rect(24, 18, 79, 36),
        title_color = 0x191308,
        outline = false,
    },
    gold = {
        texture = "button/buttonbg_5.png",
        cap_insets = cc.rect(24, 18, 79, 36),
        title_color = 0x1f1608,
        outline = false,
    },
    orange = {
        texture = "button/buttonbg_6.png",
        cap_insets = cc.rect(24, 18, 79, 36),
        title_color = 0xfff9ec,
        outline = true,
        outline_color = cc.c4b(77, 27, 6, 255),
        outline_size = 1,
    },
    grey = {
        texture = "button/buttonbg_12.png",
        cap_insets = cc.rect(28, 18, 177, 36),
        title_color = 0x1d1a15,
        outline = false,
    },
}

pixel_kit.BUTTON_STYLES = BUTTON_STYLES

function pixel_kit:PushOverlay(node, close_fn)
    if not node then
        return
    end
    self:PopOverlay(node)
    table.insert(self._overlay_stack, { node = node, close = close_fn })
end

function pixel_kit:PopOverlay(node)
    for i = #self._overlay_stack, 1, -1 do
        local entry = self._overlay_stack[i]
        if entry.node == node or not entry.node or tolua.isnull(entry.node) then
            table.remove(self._overlay_stack, i)
        end
    end
end

function pixel_kit:ClearOverlays()
    self._overlay_stack = {}
end

-- 返回 true 表示已消费本次物理返回键事件
function pixel_kit:HandleBackKey()
    for i = #self._overlay_stack, 1, -1 do
        local entry = self._overlay_stack[i]
        if not entry.node or tolua.isnull(entry.node) then
            table.remove(self._overlay_stack, i)
        elseif entry.node:isVisible() then
            table.remove(self._overlay_stack, i)
            if type(entry.close) == "function" then
                pcall(entry.close)
            else
                pcall(function() entry.node:setVisible(false) end)
            end
            return true
        end
    end
    return false
end

-- 兼容 ccui.Text 与 cc.Label（如 Button:getTitleRenderer()）的安全描边 / 清除描边
function pixel_kit:ApplyOutline(label, color_c4b, size)
    if not label then
        return
    end
    color_c4b = color_c4b or cc.c4b(0, 0, 0, 255)
    size = size or 2
    if label.getVirtualRenderer then
        local vr = label:getVirtualRenderer()
        if vr and vr.enableOutline then
            vr:enableOutline(color_c4b, size)
            return
        end
    end
    if label.enableOutline then
        label:enableOutline(color_c4b, size)
    end
end

function pixel_kit:ClearOutline(label)
    if not label then
        return
    end
    if label.getVirtualRenderer then
        local vr = label:getVirtualRenderer()
        if vr and vr.disableEffect then
            vr:disableEffect()
            return
        end
    end
    if label.disableEffect then
        label:disableEffect()
    end
end

function pixel_kit:CreateLabel(text, opts)
    opts = opts or {}
    local lbl = ccui.Text:create(text or "", opts.font or FONT_FACE, opts.font_size or 22)
    if opts.color then
        lbl:setColor(panel_util:GetColor4B(opts.color))
    elseif opts.text_color then
        lbl:setTextColor(opts.text_color)
    end
    if opts.align then
        lbl:setTextHorizontalAlignment(opts.align)
    end
    if opts.valign then
        lbl:setTextVerticalAlignment(opts.valign)
    end
    if opts.size then
        lbl:ignoreContentAdaptWithSize(false)
        lbl:setContentSize(opts.size)
    end
    if opts.anchor then
        lbl:setAnchorPoint(opts.anchor)
    end
    if opts.pos then
        lbl:setPosition(opts.pos)
    end
    if opts.outline == true or (opts.outline ~= false and not opts.no_outline) then
        self:ApplyOutline(lbl, opts.outline_color or cc.c4b(0, 0, 0, 255), opts.outline_size or 2)
    end
    return lbl
end

-- 动态切换按钮原生语义样式（green / gold / orange / grey），保持统一形状与字色
function pixel_kit:ApplyButtonStyle(btn, style_name)
    if not btn or tolua.isnull(btn) then
        return
    end
    local st = BUTTON_STYLES[style_name or "gold"] or BUTTON_STYLES.gold
    btn:loadTextures(st.texture, st.texture, st.texture, PLIST_TYPE)
    btn:setScale9Enabled(true)
    if st.cap_insets then
        btn:setCapInsets(st.cap_insets)
    end
    btn:setColor(cc.c3b(255, 255, 255))
    btn:setTitleColor(panel_util:GetColor4B(st.title_color))
    local tr = btn:getTitleRenderer()
    if st.outline then
        self:ApplyOutline(tr, st.outline_color or cc.c4b(0, 0, 0, 255), st.outline_size or 1)
    else
        self:ClearOutline(tr)
    end
end

function pixel_kit:CreateButton(opts)
    opts = opts or {}
    local st = opts.style and BUTTON_STYLES[opts.style] or nil
    local tex = opts.texture or (st and st.texture) or BUTTON_STYLES.gold.texture
    local tex_press = opts.texture_press or tex
    local cap = opts.cap_insets or (st and st.cap_insets) or BUTTON_STYLES.gold.cap_insets

    local btn = ccui.Button:create(tex, tex_press, tex, opts.res_type or PLIST_TYPE)
    btn:setScale9Enabled(opts.scale9 ~= false)
    if cap then
        btn:setCapInsets(cap)
    end
    if opts.size then
        btn:setContentSize(opts.size)
    end
    if opts.pos then
        btn:setPosition(opts.pos)
    end
    if opts.anchor then
        btn:setAnchorPoint(opts.anchor)
    end
    btn:setTitleFontName(opts.font or FONT_FACE)
    btn:setTitleFontSize(opts.font_size or 22)
    btn:setTitleText(opts.title or "")

    local title_color = opts.title_color or (st and st.title_color) or 0x1f1608
    btn:setTitleColor(panel_util:GetColor4B(title_color))

    if opts.bg_color then
        btn:setColor(panel_util:GetColor4B(opts.bg_color))
    else
        btn:setColor(cc.c3b(255, 255, 255))
    end

    local use_outline
    if opts.outline ~= nil then
        use_outline = opts.outline
    elseif st ~= nil then
        use_outline = st.outline == true
    else
        use_outline = false
    end
    if use_outline then
        self:ApplyOutline(
            btn:getTitleRenderer(),
            opts.outline_color or (st and st.outline_color) or cc.c4b(0, 0, 0, 255),
            opts.outline_size or (st and st.outline_size) or 1
        )
    else
        self:ClearOutline(btn:getTitleRenderer())
    end

    if type(opts.on_click) == "function" then
        btn:addTouchEventListener(function(sender, event_type)
            if event_type == ccui.TouchEventType.ended then
                if opts.silent ~= true then
                    audio_manager:PlayEffect("click")
                end
                opts.on_click(sender)
            end
        end)
    end
    return btn
end

-- 原生羊皮纸内卡（bg/paper_bg1.png，精确对齐 confirm_msgbox.csb 九宫格）
function pixel_kit:CreatePaperCard(parent, opts)
    opts = opts or {}
    local w = opts.width or 440
    local h = opts.height or 200
    local card = ccui.ImageView:create("bg/paper_bg1.png", PLIST_TYPE)
    card:setScale9Enabled(true)
    card:setCapInsets(cc.rect(30, 18, 196, 32))
    card:setContentSize(cc.size(w, h))
    if opts.anchor then
        card:setAnchorPoint(opts.anchor)
    end
    if opts.pos then
        card:setPosition(opts.pos)
    end
    if parent then
        parent:addChild(card, opts.z_order or 1)
    end
    return card
end

-- 统一风格加减步进器：[- 金色方键] [深底数字框（支持点按输入）] [+ 金色方键]，三者严格同高对齐
function pixel_kit:CreateStepper(parent, opts)
    opts = opts or {}
    local h = opts.height or 48
    local btn_w = opts.btn_width or h
    local box_w = opts.box_width or 106
    local gap = opts.gap or 8
    local total_w = btn_w * 2 + box_w + gap * 2

    local container = ccui.Layout:create()
    container:setContentSize(cc.size(total_w, h))
    container:setAnchorPoint(0.5, 0.5)
    if opts.pos then
        container:setPosition(opts.pos)
    end

    -- 中间深底数值框（外深黑描边 + 内暗褐底 + 亮金数字，与左右按键严格同高）
    local box_border = ccui.Layout:create()
    box_border:setContentSize(cc.size(box_w, h))
    box_border:setAnchorPoint(0.5, 0.5)
    box_border:setPosition(total_w * 0.5, h * 0.5)
    box_border:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
    box_border:setBackGroundColor(cc.c3b(22, 17, 9))
    box_border:setBackGroundColorOpacity(255)
    container:addChild(box_border, 1)

    local box_fill = ccui.Layout:create()
    box_fill:setContentSize(cc.size(box_w - 4, h - 4))
    box_fill:setAnchorPoint(0.5, 0.5)
    box_fill:setPosition(box_w * 0.5, h * 0.5)
    box_fill:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
    box_fill:setBackGroundColor(cc.c3b(44, 35, 22))
    box_fill:setBackGroundColorOpacity(255)
    box_border:addChild(box_fill, 1)

    local tf = ccui.TextField:create(opts.placeholder or "", FONT_FACE, opts.font_size or 23)
    tf:setString(tostring(opts.value or ""))
    tf:setMaxLengthEnabled(true)
    tf:setMaxLength(opts.max_length or 5)
    tf:setTouchAreaEnabled(true)
    tf:setTouchSize(cc.size(box_w - 4, h - 4))
    tf:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    tf:setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
    tf:setPosition((box_w - 4) * 0.5, (h - 4) * 0.5)
    tf:setTextColor(cc.c4b(255, 234, 156, 255))
    box_fill:addChild(tf, 2)

    local minus_btn = self:CreateButton({
        style = opts.btn_style or "gold",
        title = "-",
        font_size = opts.step_font_size or 28,
        size = cc.size(btn_w, h),
        pos = cc.p(btn_w * 0.5, h * 0.5),
        on_click = function()
            if type(opts.on_minus) == "function" then
                opts.on_minus(tf)
            end
        end,
    })
    container:addChild(minus_btn, 2)

    local plus_btn = self:CreateButton({
        style = opts.btn_style or "gold",
        title = "+",
        font_size = opts.step_font_size or 28,
        size = cc.size(btn_w, h),
        pos = cc.p(total_w - btn_w * 0.5, h * 0.5),
        on_click = function()
            if type(opts.on_plus) == "function" then
                opts.on_plus(tf)
            end
        end,
    })
    container:addChild(plus_btn, 2)

    if parent then
        parent:addChild(container, opts.z_order or 3)
    end
    return {
        node = container,
        tf = tf,
        minus_btn = minus_btn,
        plus_btn = plus_btn,
        width = total_w,
        height = h,
    }
end

-- 原生 1A 复刻弹窗（bg/box_bg.png 精确 50/56 九宫格 + 原生右上关闭键 + 返回键入栈）
function pixel_kit:CreateDialog(parent, opts)
    opts = opts or {}
    local w = opts.width or 520
    local h = opts.height or 420
    local z_order = opts.z_order or 200
    local pos_y = opts.pos_y or 576
    local remove_on_close = (opts.remove_on_close ~= false)

    local overlay = ccui.Layout:create()
    overlay:setContentSize(cc.size(640, 1136))
    overlay:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
    overlay:setBackGroundColor(cc.c3b(0, 0, 0))
    overlay:setBackGroundColorOpacity(opts.scrim_opacity or 165)
    overlay:setTouchEnabled(true)

    local dlg = {
        overlay = overlay,
        width = w,
        height = h,
    }

    local function do_close()
        pixel_kit:PopOverlay(overlay)
        if type(opts.on_close) == "function" then
            pcall(opts.on_close)
        end
        if not tolua.isnull(overlay) then
            if remove_on_close then
                overlay:removeFromParent()
            else
                overlay:setVisible(false)
            end
        end
    end
    dlg.Close = do_close

    if opts.close_on_scrim ~= false then
        overlay:addTouchEventListener(function(_, et)
            if et == ccui.TouchEventType.ended then
                audio_manager:PlayEffect("click")
                do_close()
            end
        end)
    end

    -- 原生精确九宫格橄榄木外框（capInsets 与 bag_panel.csb / confirm_msgbox.csb 1:1 一致）
    local outer = ccui.ImageView:create("bg/box_bg.png", PLIST_TYPE)
    outer:setScale9Enabled(true)
    outer:setCapInsets(cc.rect(50, 56, 20, 8))
    outer:setContentSize(cc.size(w, h))
    outer:setAnchorPoint(0.5, 0.5)
    outer:setPosition(320, pos_y)
    outer:setTouchEnabled(true)
    overlay:addChild(outer, 2)

    -- 内安全内容区（避开外框阴影与双层斜切边，保证零穿框）
    local pad_x = 34
    local pad_y = 36
    local inner_w = w - pad_x * 2
    local inner_h = h - pad_y * 2
    local inner = ccui.Layout:create()
    inner:setContentSize(cc.size(inner_w, inner_h))
    inner:setAnchorPoint(0.5, 0.5)
    inner:setPosition(w * 0.5, h * 0.5)
    outer:addChild(inner, 2)

    -- 顶部标题（原生亮金字 + 像素黑描边）
    local header_h = 46
    local title_lbl = self:CreateLabel(opts.title or "", {
        font_size = 25,
        color = 0xffea9c,
        pos = cc.p(inner_w * 0.5, inner_h - 18),
        outline_color = cc.c4b(22, 16, 7, 255),
        outline_size = 2,
    })
    inner:addChild(title_lbl, 3)

    -- 右上角原生凸出关闭键（button/close1_normal.png）
    if opts.show_close ~= false then
        local close_btn = ccui.Button:create("button/close1_normal.png", "button/close1_press.png", "button/close1_normal.png", PLIST_TYPE)
        close_btn:setScale(0.86)
        close_btn:setPosition(w - 16, h - 18)
        close_btn:addTouchEventListener(function(_, et)
            if et == ccui.TouchEventType.ended then
                audio_manager:PlayEffect("click")
                do_close()
            end
        end)
        outer:addChild(close_btn, 6)
        dlg.close_btn = close_btn
    end

    dlg.card = outer
    dlg.inner = inner
    dlg.inner_w = inner_w
    dlg.inner_h = inner_h
    dlg.content_top = inner_h - header_h
    dlg.title_lbl = title_lbl

    if parent then
        parent:addChild(overlay, z_order)
    end
    self:PushOverlay(overlay, do_close)
    return dlg
end

function pixel_kit:CreateStatusBanner(parent, opts)
    opts = opts or {}
    local w = opts.width or 560
    local h = opts.height or 44
    local bg = ccui.ImageView:create("bg/floating_layerbg.png", PLIST_TYPE)
    bg:setScale9Enabled(true)
    bg:setCapInsets(cc.rect(24, 24, 22, 22))
    bg:setContentSize(cc.size(w, h))
    bg:setAnchorPoint(0.5, 0.5)
    if opts.pos then
        bg:setPosition(opts.pos)
    end
    bg:setVisible(opts.visible == true)

    local lbl = self:CreateLabel(opts.text or "", {
        font_size = opts.font_size or 19,
        color = opts.color or 0xffea9c,
        pos = cc.p(w * 0.5, h * 0.5),
        outline_size = 2,
    })
    bg:addChild(lbl, 1)

    if parent then
        parent:addChild(bg, opts.z_order or 12)
    end
    return bg, lbl
end

-- 全局非阻塞原生像素风飘字 Toast（bg/floating_layerbg.png）
function pixel_kit:ShowToast(text, color_hex)
    if not text or text == "" then
        return
    end
    local scene = cc.Director:getInstance():getRunningScene()
    local host = (scene and scene.fix_root_node) or scene
    if not host then
        return
    end
    local old = host:getChildByName("__pixel_kit_toast")
    if old then
        old:removeFromParent()
    end

    local lbl = self:CreateLabel(tostring(text), {
        font_size = 21,
        color = color_hex or 0xffea9c,
        outline_size = 2,
    })
    local tw = math.min(580, math.max(260, lbl:getContentSize().width + 52))
    local th = math.max(52, lbl:getContentSize().height + 24)

    local box = ccui.ImageView:create("bg/floating_layerbg.png", PLIST_TYPE)
    box:setScale9Enabled(true)
    box:setCapInsets(cc.rect(24, 24, 22, 22))
    box:setName("__pixel_kit_toast")
    box:setContentSize(cc.size(tw, th))
    box:setAnchorPoint(0.5, 0.5)
    box:setPosition(320, 820)
    box:setCascadeOpacityEnabled(true)

    lbl:setPosition(tw * 0.5, th * 0.5)
    box:addChild(lbl, 1)
    host:addChild(box, 1950)

    box:setOpacity(0)
    box:runAction(cc.Sequence:create(
        cc.Spawn:create(cc.FadeIn:create(0.15), cc.MoveBy:create(0.15, cc.p(0, 18))),
        cc.DelayTime:create(1.8),
        cc.Spawn:create(cc.FadeOut:create(0.3), cc.MoveBy:create(0.3, cc.p(0, 24))),
        cc.RemoveSelf:create()
    ))
end

return pixel_kit
