local panel_prototype = require "ui.panel"
local panel_util = require "ui.panel_util"
local lang_constants = require "util.language_constants"

local constants = require "util.constants"
local client_constants = require "util.client_constants"
local audio_manager = require "util.audio_manager"
local configuration = require "util.configuration"

local config_manager = require "logic.config_manager"
local graphic = require "logic.graphic"
local troop_logic = require "logic.troop"
local user_logic = require "logic.user"
local temple_logic = require "logic.temple"
local carnival_logic = require "logic.carnival"
local daily_logic = require "logic.daily"

local time_logic = require "logic.time"
local panel_util = require "ui.panel_util"
local magic_shop = require "logic.magic_shop"
local feature_config = require "logic.feature_config"
local hot_mercenary_logic = require "logic.hot_mercenary"
local utils = require "util.utils"
local user_data = require "util.user_data"

local PERMANENT_MARK = constants["PERMANENT_MARK"]
local FEATURE_TYPE = client_constants["FEATURE_TYPE"]
local SCENE_TRANSITION_TYPE = constants.SCENE_TRANSITION_TYPE

local MAX_REFREDH_TIME = 1
local SUB_PANEL_HEIGHT = 190

-- [PC PORT] 神秘召唤(热点佣兵)和秘术召唤 are retired on this server; their
-- pool entries are folded into 血钻召唤/友情召唤 instead.
local HIDE_SPECIAL_RECRUIT = true

local recruit_panel = panel_prototype.New()
function recruit_panel:Init()
    self.root_node = (require "util.helper"):Loader("ui/recruit_panel.csb")
    local root_node = self.root_node

    self.list_view = self.root_node:getChildByName("list_view")

    self.recruit_info = self.root_node:getChildByName("recruit_info")
    if self.recruit_info then
        -- [FIX] 稍微上移并左移，避免压住下方秘术召唤的斜角丝带
        self.recruit_info:setPosition(self.recruit_info:getPositionX() - 8, self.recruit_info:getPositionY() + 8)
    end
    self.recruit_info:addTouchEventListener(function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            graphic:DispatchEvent("show_world_sub_panel", "hero_rule_msgbox")
        end
    end)

    -- [MOD r10.3] 召唤顶部栏新增「心愿祈愿 (代金券)」1A 快捷入口，居中放置避免遮挡左右按钮
    do
        local pixel_kit = require "ui.pixel_kit"
        local bar_y = self.recruit_info and self.recruit_info:getPositionY() or 1012
        self.wish_pool_btn = pixel_kit:CreateButton({
            style = "gold",
            title = "心愿祈愿",
            font_size = 19,
            size = cc.size(142, 42),
            pos = cc.p(320, bar_y),
            on_click = function()
                local wish_pool_dialog = require "ui.wish_pool_dialog"
                wish_pool_dialog:Show(self.root_node)
            end,
        })
        self.root_node:addChild(self.wish_pool_btn, 40)
    end

    self.auto_fire_btn = self.root_node:getChildByName("10times_btn")
    -- 自动解雇按钮
    self.auto_fire_icon = self.root_node:getChildByName("yes_icon")
    -- 自动解雇勾

    if self.auto_fire_icon then
        if feature_config:IsFeatureOpen("auto_fire_mercenary") then
            self.auto_fire_icon:setVisible(configuration:GetAutoFire())
        end
    end

    self.gold_coin_recruit_btn = self.list_view:getChildByName("coin_recruit")
    self.gold_coin_text = self.gold_coin_recruit_btn:getChildByName("coin_cost")

    self.blood_diamond_recruit_btn = self.list_view:getChildByName("blood_diamond_recruit")

    self.blood_diamond_cost_ten = self.blood_diamond_recruit_btn:getChildByName("blood_diamond_cost")
    self.blood_diamond_cost_one = self.blood_diamond_recruit_btn:getChildByName("blood_diamond_cost_0")

    self.blood_diamond_cost_one:setString(panel_util:ConvertUnit(constants.RECRUIT_COST.hero_door))
    self.blood_diamond_cost_ten:setString(panel_util:ConvertUnit(constants.RECRUIT_COST.ten_mercenary_door))

    self.blood_diamond_limit = self.blood_diamond_recruit_btn:getChildByName("blood_diamond_limit")
    if self.blood_diamond_limit then
        local bd_desc = self.blood_diamond_recruit_btn:getChildByName("desc")
        if bd_desc then
            bd_desc:setPositionY(bd_desc:getPositionY() + 7)
        end
        local bd_arrow = self.blood_diamond_recruit_btn:getChildByName("arrow")
        if bd_arrow then
            bd_arrow:setPositionY(bd_arrow:getPositionY() + 7)
        end
        self.blood_diamond_limit:setFontSize(18)
        self.blood_diamond_limit:setPositionY(self.blood_diamond_limit:getPositionY() - 5)
    end
    self.blood_diamond_limit_frame = 0
    self.blood_limit_config = user_data:new(nil, "blood_diamond_limit")
    local blood_diamond_limit_num = self.blood_limit_config:getKeyValue("blood_diamond_limit")
    if blood_diamond_limit_num == nil then
        self.blood_limit_config:setKeyValue("blood_diamond_limit", 0)
        local cur_date = time_logic:GetDate()
        local v = cur_date.year .. cur_date.month .. cur_date.day
        self.blood_limit_config:setKeyValue("blood_diamond_limit_date", v)
    end

    self.blood_diamond_limit_0 = self.gold_coin_recruit_btn:getChildByName("blood_diamond_limit_0")
    if self.blood_diamond_limit_0 then
        local coin_desc = self.gold_coin_recruit_btn:getChildByName("desc")
        if coin_desc then
            coin_desc:setPositionY(coin_desc:getPositionY() + 7)
        end
        local coin_arrow = self.gold_coin_recruit_btn:getChildByName("arrow")
        if coin_arrow then
            coin_arrow:setPositionY(coin_arrow:getPositionY() + 7)
        end
        self.blood_diamond_limit_0:setFontSize(18)
        self.blood_diamond_limit_0:setPositionY(self.blood_diamond_limit_0:getPositionY() - 5)
    end
    self.blood_diamond_limit_frame = 0
    local blood_diamond_limit_0_num = self.blood_limit_config:getKeyValue("blood_diamond_limit_0")
    if blood_diamond_limit_0_num == nil then
        self.blood_limit_config:setKeyValue("blood_diamond_limit_0", 0)
        local cur_date = time_logic:GetDate()
        local v = cur_date.year .. cur_date.month .. cur_date.day
        self.blood_limit_config:setKeyValue("blood_diamond_limit_0_date", v)
    end

    -- 彩钻召唤入口
    self.color_diamond_recruit_btn = self.list_view:getChildByName("colorblood_diamond_recruit_0")
    if self.color_diamond_recruit_btn then
        local ten_color_cost_txt = self.color_diamond_recruit_btn:getChildByName("blood_diamond_cost")
        ten_color_cost_txt:setString("/" .. constants.RECRUIT_COST.ten_color_diamond_door)

        local color_cost_txt = self.color_diamond_recruit_btn:getChildByName("blood_diamond_cost_0")
        color_cost_txt:setString(constants.RECRUIT_COST.color_diamond_door)

        self.color_diamond_limit = self.color_diamond_recruit_btn:getChildByName("blood_diamond_limit")
        self.color_diamond_limit_frame = 0
        self.color_limit_config = user_data:new(nil, "color_diamond_limit")
        local color_diamond_limit_num = self.color_limit_config:getKeyValue("color_diamond_limit")
        if color_diamond_limit_num == nil then
            self.color_limit_config:setKeyValue("color_diamond_limit", 0)
            local cur_date = time_logic:GetDate()
            local v = cur_date.year .. cur_date.month .. cur_date.day
            self.color_limit_config:setKeyValue("color_diamond_limit_date", v)
        end
    end

    self.temple_recruit_btn = self.list_view:getChildByName("temple")
    self.temple_cd_text = self.temple_recruit_btn:getChildByName("reset_time")

    self.friend_recruit_btn = self.list_view:getChildByName("friend_recruit")
    -- [PC PORT] 友情召唤 pool now covers 白将~金将; the zh-CN .csb still has
    -- the old "绿将～" baked in, so override the label here.
    local friend_limit_down = self.friend_recruit_btn:getChildByName("limit_down")
    if friend_limit_down then
        friend_limit_down:setString("白将")
    end
    self.hot_mercenary_btn = self.list_view:getChildByName("hot_recruit")

    self.magic_recruit_btn = self.list_view:getChildByName("magic_recruit")
    self.magic_recruit_btn:setVisible(false)
    if HIDE_SPECIAL_RECRUIT and self.hot_mercenary_btn then
        self.hot_mercenary_btn:setVisible(false)
    end

    self.magic_recruit_time_text = self.magic_recruit_btn:getChildByName("timetip"):getChildByName("time")
    self.magic_recruit_cost_text = self.magic_recruit_btn:getChildByName("blood_diamond_cost")
    if self.hot_mercenary_btn then
        self.top = self.hot_mercenary_btn:getPositionY()
    else
        self.top = self.magic_recruit_btn:getPositionY()
    end

    self.recruit_sub_panels = {}

    self.recruit_sub_panels[1] = self.magic_recruit_btn
    self.recruit_sub_panels[2] = self.blood_diamond_recruit_btn
    self.recruit_sub_panels[3] = self.gold_coin_recruit_btn
    self.recruit_sub_panels[4] = self.friend_recruit_btn
    self.recruit_sub_panels[5] = self.temple_recruit_btn

    -- table.insert(self.recruit_sub_panels, 1, self.color_diamond_recruit_btn)

    self.store_01_btn = self.list_view:getChildByName("store_01") -- 积分商店
    self.store_02_btn = self.list_view:getChildByName("store_02") -- FYD限时积分商店
    if feature_config:IsFeatureOpen("magic_shop") then
        self.magic_recruit_btn2 = self.store_02_btn:getChildByName("magic_recruit")
        self.store_02_time_text = self.store_02_btn:getChildByName("timetip"):getChildByName("time")
        self.store_02_btn:setVisible(false)

        self.store_01_time_text = self.store_01_btn:getChildByName("reset_time_0")

        table.insert(self.recruit_sub_panels, 3, self.store_02_btn)
        table.insert(self.recruit_sub_panels, self.store_01_btn)
    end

    if feature_config:IsFeatureOpen("hot_mercenary") then
        table.insert(self.recruit_sub_panels, 1, self.hot_mercenary_btn)
        self.hot_mercenary_btn:getChildByName("to"):setVisible(false)
        self.hot_mercenary_btn:getChildByName("limit_down"):setVisible(false)
        self.hot_mercenary_btn:getChildByName("limit_up"):setVisible(false)
        self.hot_mercenary_btn:setVisible(not HIDE_SPECIAL_RECRUIT)
        local name_text = self.hot_mercenary_btn:getChildByName("name")
        name_text:setString(lang_constants:Get("hot_mercenary_title"))
        local desc_text = self.hot_mercenary_btn:getChildByName("desc")
        desc_text:setString(lang_constants:Get("hot_mercenary_cost_desc"))

        self.hot_mercenary_time_text = self.hot_mercenary_btn:getChildByName("timetip"):getChildByName("time")
        self.hot_mercenary_text = self.hot_mercenary_btn:getChildByName("blood_diamond_cost")
        self.hot_mercenary_text:setString(tostring(constants["HOT_MERCENARY_COST"]))
    end

    self:RegisterEvent()
    self:RegisterWidgetEvent()
end

function recruit_panel:Show()
    self.root_node:setVisible(true)
    self:UpdateCost()
    self.duration = time_logic:GetDurationToNextDay()
    -- [PC PORT] The login-time query can arrive before the hot-mercenary
    -- module registers its handler; fetch the banner again on first show.
    if not HIDE_SPECIAL_RECRUIT then
        if feature_config:IsFeatureOpen("hot_mercenary") and not hot_mercenary_logic.end_time then
            hot_mercenary_logic:QueryHotMercenary()
        end
        hot_mercenary_logic:RefreshData()
    end
    self:UpdateMagicDoor()
    self.list_view:jumpToTop()
    self.blood_diamond_limit_frame = 1

    CCLOG("GetDate:", time_logic:GetDate())
end

function recruit_panel:UpdateMagicDoor()
    -- 判断是否显示秘术召唤
    local conf = carnival_logic:GetSpecialCarnival(client_constants.CARNIVAL_TEMPLATE_TYPE["magic_door"])
    -- [MOD] 秘术召唤默认启用：原版这里被 HIDE_SPECIAL_RECRUIT 一起关掉了，
    -- 服务端配置（magic_door，880 血钻十连、保底紫将）和招募逻辑都是现成的。
    -- HIDE_SPECIAL_RECRUIT 继续只用于热门佣兵横幅。
    if conf and user_logic:IsFeatureUnlock(client_constants.FEATURE_TYPE["magic"], false) then
        self.magic_recruit_btn:setVisible(true)
        self.magic_recruit_cost_text:setString(tostring(conf.extra_num1))
    else
        self.magic_recruit_btn:setVisible(false)
    end

    -- 判断是否显示血钻召唤
    if feature_config:IsFeatureOpen("review") then
        self.blood_diamond_recruit_btn:setVisible(false)
    else
        self.blood_diamond_recruit_btn:setVisible(true)
    end

    -- 判断是否显示积分商店
    if self.store_01_btn then
        if feature_config:IsFeatureOpen("magic_shop") then
            self.store_01_btn:setVisible(true)
        else
            self.store_01_btn:setVisible(false)
        end
    end

    -- 判断是否显示限时积分商店
    if self.store_02_btn then
        local time_info = magic_shop:GetShopTimeInfo()
        local cur_time = time_logic:Now()
        if feature_config:IsFeatureOpen("magic_shop") and time_info and tonumber(time_info.end_time) >
            tonumber(cur_time) and tonumber(time_info.begin_time) <= tonumber(cur_time) then -- 限时商店开启
            self.store_02_btn:setVisible(true)
        else
            self.store_02_btn:setVisible(false)
        end
    end

    if self.hot_mercenary_btn then
        if HIDE_SPECIAL_RECRUIT then
            self.hot_mercenary_btn:setVisible(false)
        else
            local delt_time = hot_mercenary_logic.end_time and hot_mercenary_logic.end_time - time_logic:Now() or 0
            if feature_config:IsFeatureOpen("hot_mercenary") and delt_time > 0 then
                self.hot_mercenary_btn:setVisible(true)
                local array = utils:getTimeString(delt_time)
                local time_str = string.format("%02d:%02d:%02d", array["hours"] or 0, array["minutes"] or 0,
                    array["seconds"] or 0)
                self.hot_mercenary_time_text:setString(time_str)
            else
                self.hot_mercenary_btn:setVisible(false)
                if feature_config:IsFeatureOpen("hot_mercenary") and hot_mercenary_logic.end_time then
                    hot_mercenary_logic:RefreshData()
                end
            end
        end
    end

    -- 调整位置
    local index = 0
    for _, sub_panel in ipairs(self.recruit_sub_panels) do
        if sub_panel:isVisible() then
            sub_panel:setPositionY(self.top - index * SUB_PANEL_HEIGHT)
            index = index + 1
        end
    end
end

function recruit_panel:Update(elapsed_time)
    -- The panel can be updated before its first Show on this runtime.
    if not self.duration then
        self.duration = time_logic:GetDurationToNextDay()
    end
    self.duration = self.duration - elapsed_time

    if self.duration <= 0 then
        self.duration = time_logic:GetDurationToNextDay()
    end
    if not self.blood_diamond_limit_frame then
        self.blood_diamond_limit_frame = 0
    end

    self.blood_diamond_limit_frame = self.blood_diamond_limit_frame + elapsed_time
    if (self.blood_diamond_limit_frame > 1.0) then
        -- [PC PORT] user_data instances now own their own snapshot; troop.lua
        -- writes the counters through a separate instance, so refresh from
        -- disk before drawing the "每日召唤上限" labels.
        self.blood_limit_config = user_data:new(nil, "blood_diamond_limit")
        if self.color_diamond_limit then
            self.color_limit_config = user_data:new(nil, "color_diamond_limit")
        end

        local blood_diamond_limit_num = self.blood_limit_config:getKeyValue("blood_diamond_limit")
        if blood_diamond_limit_num == nil then
            blood_diamond_limit_num = 0
        end

        local blood_diamond_limit_0 = self.blood_limit_config:getKeyValue("blood_diamond_limit_0")
        if blood_diamond_limit_0 == nil then
            blood_diamond_limit_0 = 0
        end

        local color_diamond_limit_num = self.color_limit_config
            and self.color_limit_config:getKeyValue("color_diamond_limit") or 0
        if color_diamond_limit_num == nil then
            color_diamond_limit_num = 0
        end

        local recruit_limit_desc = lang_constants:Get("recruit_limit_desc")
        recruit_limit_desc = recruit_limit_desc .. blood_diamond_limit_num .. "/10000"
        self.blood_diamond_limit:setString(recruit_limit_desc)

        recruit_limit_desc = lang_constants:Get("recruit_limit_desc")
        recruit_limit_desc = recruit_limit_desc .. blood_diamond_limit_0 .. "/10000"
        self.blood_diamond_limit_0:setString(recruit_limit_desc)

        if self.color_diamond_limit then
            recruit_limit_desc = lang_constants:Get("recruit_limit_desc")
            recruit_limit_desc = recruit_limit_desc .. color_diamond_limit_num .. "/10000"
            self.color_diamond_limit:setString(recruit_limit_desc)
        end

        self.blood_diamond_limit_frame = self.blood_diamond_limit_frame - 1

        local cur_date = time_logic:GetDate()
        local v = cur_date.year .. cur_date.month .. cur_date.day
        local blood_diamond_limit_date = self.blood_limit_config:getKeyValue("blood_diamond_limit_date")
        if v ~= blood_diamond_limit_date then
            self.blood_limit_config:setKeyValue("blood_diamond_limit_date", v)
            self.blood_limit_config:setKeyValue("blood_diamond_limit", 0)

            self.blood_limit_config:setKeyValue("blood_diamond_limit_0_date", v)
            self.blood_limit_config:setKeyValue("blood_diamond_limit_0", 0)
        end
    end

    self.temple_cd_text:setString(panel_util:GetTimeStr(self.duration))

    local conf = carnival_logic:GetSpecialCarnival(client_constants.CARNIVAL_TEMPLATE_TYPE["magic_door"])
    if conf then
        local cur_time = time_logic:Now()
        local remain = conf.end_time - cur_time
        if remain > 30 * 86400 then
            self.magic_recruit_time_text:setString(lang_constants:Get("carnival_for_ever_duration"))
        else
            self.magic_recruit_time_text:setString(panel_util:GetTimeStr(remain))
        end
    end

    if self.store_02_time_text then
        local time_info = magic_shop:GetShopTimeInfo()
        if time_info then
            local cur_time = time_logic:Now()
            self.store_02_time_text:setString(panel_util:GetTimeStr(time_info.end_time - cur_time))
        end
    end

    if self.store_01_time_text then
        -- 积分商城
        if magic_shop.needRestTime then -- 推送
            magic_shop.next_rest_time = magic_shop.needRestTime
        end

        if magic_shop.next_rest_time then
            local cur_time = time_logic:Now()
            local time = magic_shop.next_rest_time - cur_time

            if time <= 0 then
                time = 0
            end
            self.store_01_time_text:setString(panel_util:GetTimeStr(time))
        else
            self.store_01_time_text:setString(lang_constants:Get("next_reset_time_none"))
        end
    end

    if self.hot_mercenary_btn then
        if HIDE_SPECIAL_RECRUIT then
            self.hot_mercenary_btn:setVisible(false)
        else
            local delt_time = hot_mercenary_logic.end_time and hot_mercenary_logic.end_time - time_logic:Now() or 0
            if feature_config:IsFeatureOpen("hot_mercenary") and delt_time > 0 then
                self.hot_mercenary_btn:setVisible(true)
                local array = utils:getTimeString(delt_time)
                local time_str = string.format("%02d:%02d:%02d", array["hours"] or 0, array["minutes"] or 0,
                    array["seconds"] or 0)
                self.hot_mercenary_time_text:setString(time_str)
            else
                self.hot_mercenary_btn:setVisible(false)
                if feature_config:IsFeatureOpen("hot_mercenary") and hot_mercenary_logic.end_time then
                    hot_mercenary_logic:RefreshData()
                end
            end
        end
    end
end

function recruit_panel:UpdateCost()
    panel_util:ConvertUnit(daily_logic:GetRecruitCost(), self.gold_coin_text)
end

function recruit_panel:RegisterEvent()
    graphic:RegisterEvent("recruit_mercenary", function(door_type)
        if not self.root_node:isVisible() then
            return
        end

        self:UpdateCost()
    end)
    graphic:RegisterEvent("update_feature_config", function()
        if not self.root_node:isVisible() then
            return
        end
        self:UpdateMagicDoor()
    end)
    graphic:RegisterEvent("hot_mercenary_updated", function()
        if not self.root_node:isVisible() then
            return
        end
        self:UpdateMagicDoor()
    end)
end

function recruit_panel:RegisterWidgetEvent()
    -- 自动解雇状态
    if self.auto_fire_btn then
        self.auto_fire_btn:addTouchEventListener(function(widget, event_type)
            if event_type == ccui.TouchEventType.ended then
                if self.auto_fire_icon:isVisible() then
                    configuration:SetAutoFire(false)
                    self.auto_fire_icon:setVisible(false)
                else
                    configuration:SetAutoFire(true)
                    self.auto_fire_icon:setVisible(true)
                end
                configuration:Save()
            end
        end)
    end

    -- 彩钻召唤
    if self.color_diamond_recruit_btn then
        self.color_diamond_recruit_btn:addTouchEventListener(function(widget, event_type)
            if event_type == ccui.TouchEventType.ended then
                audio_manager:PlayEffect("click")
                print("log=========彩钻")

                local user_data = require "util.user_data"
                local user_config = user_data:new(nil, "color_diamond_limit")
                local limit_num = user_config:getKeyValue("color_diamond_limit")
                if limit_num == nil then
                    limit_num = 0
                end
                if tonumber(limit_num) > 10000 then
                    graphic:DispatchEvent("show_prompt_panel", "recruit_limit_max")
                    return
                end

                graphic:DispatchEvent("show_world_sub_panel", "color_diamond_recruit_msgbox")
            end
        end)
    end

    -- 金币招募
    self.gold_coin_recruit_btn:addTouchEventListener(function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")

            local user_data = require "util.user_data"
            local user_config = user_data:new(nil, "blood_diamond_limit")
            local blood_diamond_limit_num = user_config:getKeyValue("blood_diamond_limit_0")
            if blood_diamond_limit_num == nil then
                blood_diamond_limit_num = 0
            end
            if tonumber(blood_diamond_limit_num) > 10000 then
                graphic:DispatchEvent("show_prompt_panel", "recruit_limit_max")
                return
            end

            graphic:DispatchEvent("show_world_sub_panel", "confirm_msgbox",
                client_constants.CONFIRM_MSGBOX_MODE["recruit_mercenary"], "recruiting_door")
        end
    end)

    -- 友情招募
    self.friend_recruit_btn:addTouchEventListener(function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            graphic:DispatchEvent("show_world_sub_panel", "friendship_recruit_msgbox")
        end
    end)

    -- 血钻招募
    self.blood_diamond_recruit_btn:addTouchEventListener(function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            graphic:DispatchEvent("show_world_sub_panel", "blood_diamond_recruit_msgbox")
        end
    end)

    -- 神殿
    self.temple_recruit_btn:addTouchEventListener(function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            if user_logic:IsFeatureUnlock(FEATURE_TYPE["temple"]) then
                temple_logic:MercenaryQuery()
            end
        end
    end)

    -- 秘术招募
    self.magic_recruit_btn:getChildByName("magic_recruit"):addTouchEventListener(function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            graphic:DispatchEvent("show_world_sub_panel", "magic_recruit_msgbox")
        end
    end)

    if self.store_01_btn then
        -- 积分商店
        self.store_01_btn:addTouchEventListener(function(widget, event_type)
            if event_type == ccui.TouchEventType.ended then
                audio_manager:PlayEffect("click")

                if magic_shop.needRestTime then
                    magic_shop.isShowScene = true
                    magic_shop:requireInfo() -- 重新发送请求
                else
                    -- false  暂时只有非限时的酒馆
                    graphic:DispatchEvent("show_world_sub_scene", "magic_shop_sub_scene", nil, false)
                end
            end
        end)
    end

    if self.magic_recruit_btn2 then
        -- 限时积分商店
        self.magic_recruit_btn2:addTouchEventListener(function(widget, event_type)
            if event_type == ccui.TouchEventType.ended then
                audio_manager:PlayEffect("click")
                if not self.magic_shop_pannel then
                    self.magic_shop_pannel = require("ui.magic_shop_pannel").new(true)
                end
                self.magic_shop_pannel:Show(self.root_node)
            end
        end)
    end

    if self.hot_mercenary_btn then
        -- 热点佣兵
        self.hot_mercenary_btn:getChildByName("magic_recruit"):addTouchEventListener(function(widget, event_type)
            if event_type == ccui.TouchEventType.ended then
                audio_manager:PlayEffect("click")
                hot_mercenary_logic:ShowPanel()
            end
        end)
    end
end

return recruit_panel
