local config_manager = require "logic.config_manager"
local resource_logic = require "logic.resource"
local constants = require "util.constants"
local audio_manager = require "util.audio_manager"

local graphic = require "logic.graphic"
local feature_config = require "logic.feature_config"
local panel_prototype = require "ui.panel"
local panel_util = require "ui.panel_util"
local pixel_kit = require "ui.pixel_kit"
local client_constants = require "util.client_constants"
local lang_constants = require "util.language_constants"
local rune_logic = require "logic.rune"

local rune_config = config_manager.rune_config

local PLIST_TYPE = ccui.TextureResType.plistType

local BAG_CELL_COL = 5

local RUNE_PROPERTY_KEYS_NODE_NAME = {
    ["mine_property"] = "property_me",
    ["enemy_property"] = "property_enemy",
}

local equip_pos_sub_panel = panel_prototype.New()
equip_pos_sub_panel.__index = equip_pos_sub_panel

function equip_pos_sub_panel.New()
    return setmetatable({}, equip_pos_sub_panel)
end

function equip_pos_sub_panel:Init(pos, root_node)
    self.pos = pos
    self.root_node = root_node

    self.icon_img = self.root_node:getChildByName("rune_icon")
    self.top_quality_img = self.root_node:getChildByName("top_quality")
    self.select_img = self.root_node:getChildByName("select_light")
    self.select_img:setVisible(false)

    self.rune_level_text = self.root_node:getChildByName("rune_level")
    self.rune_level_text:setLocalZOrder(1)
    panel_util:SetTextOutline(self.rune_level_text, 0x000, 2)

    self.rune_name_text = self.root_node:getChildByName("rune_name")

    self.equip_rune_btn = self.root_node:getChildByName("add_btn01")
    self.add_img = self.root_node:getChildByName("add_btn_1")
    self.add_img:setTouchEnabled(false)
    self.add_img:runAction(cc.RepeatForever:create(cc.Sequence:create(cc.FadeTo:create(1, 150), cc.FadeTo:create(1, 255))))

    self.rune_info = nil
end

function equip_pos_sub_panel:Show(rune_info)
    self.rune_info = rune_info
    
    if self.rune_info then
        self.icon_img:setVisible(true)
        self.icon_img:loadTexture(CheckTextureCache(self.rune_info.template_info.icon), PLIST_TYPE)
        self.top_quality_img:setVisible(self.rune_info.template_info.quality == constants["MAX_RUNE_QUALITY"])
        if self.rune_info.level >= self.rune_info.template_info.level_limit then
            self.rune_level_text:setString("Lv MAX")
        else
            self.rune_level_text:setString(string.format(lang_constants:Get("rune_level"), self.rune_info.level))
        end
        self.rune_name_text:setString(self.rune_info.template_info.name)
        self.rune_name_text:setColor(panel_util:GetColor4B(client_constants["RUNE_TEXT_QUALITY_COLOR"][self.rune_info.template_info.quality]))
        self.add_img:setVisible(false)
    else
        self.icon_img:setVisible(false)
        self.top_quality_img:setVisible(false)
        self.rune_level_text:setString("")
        self.rune_name_text:setString("")
        self.add_img:setVisible(true)
    end
end

function equip_pos_sub_panel:SetRuneSelectSprite( is_selected )
    self.select_img:setVisible(is_selected)
end

local rune_equip_panel = panel_prototype.New(true)
function rune_equip_panel:Init(root_node)
    self.root_node = (require "util.helper"):Loader("ui/rune_panel.csb")

    local title_node = self.root_node:getChildByName("title_bg")
    self.rune_name_text = title_node:getChildByName("rune_name")
    self.rune_desc_text = self.root_node:getChildByName("rune_desc")

    self.back_btn = self.root_node:getChildByName("back_btn")
    self.draw_btn = self.root_node:getChildByName("draw_btn")
    self.bag_btn = self.root_node:getChildByName("set_btn")
    self.replace_btn = self.root_node:getChildByName("replace_btn")
    self.levelup_btn = self.root_node:getChildByName("levelup_btn")

    local property_node = self.root_node:getChildByName("lineup")
    self.property_text_list = {}
    for i,key in ipairs(constants["RUNE_PROPERTY_KEYS"]) do
        self.property_text_list[key] = {}
        for property_type, property_name in ipairs(constants["PROPERTY_TYPE_NAME"]) do
            self.property_text_list[key][property_name] = property_node:getChildByName(RUNE_PROPERTY_KEYS_NODE_NAME[key]):getChildByName(property_name):getChildByName("value")
        end
    end

    self.equip_pos_templates = {}
    for pos = 1, constants["MAX_RUNE_EQUIPMENT_NUM"] do
        self.equip_pos_templates[pos] = self.root_node:getChildByName(string.format("rune_00%d", pos))
    end

    self.cur_select_pos = 1
    self.rune_sub_panels = {}

    self:RegisterEvent()
    self:RegisterWidgetEvent()
    self:CreateEquipPos()
    self:CreatePresetWidgets()
end

function rune_equip_panel:Show()
    self:ShowRuneEquipment()
    self:UpdatePresetStrip()

    self.root_node:setVisible(true)
end

function rune_equip_panel:ShowRuneDesc()
    local rune_info = self.rune_sub_panels[self.cur_select_pos].rune_info
    if rune_info then
        self.rune_name_text:setString(rune_info.template_info.name)
        local desc_str = rune_logic:GetRunePropertysDesc(rune_info.template_id, rune_info.level)
        if desc_str ~= "" then
            desc_str = desc_str .. lang_constants:Get("comma")
        end
        self.rune_desc_text:setString(desc_str .. rune_info.template_info.desc)
        self.rune_desc_text:setColor(panel_util:GetColor4B(0xdecb97))
    else
        self.rune_name_text:setString("")
        self.rune_desc_text:setString(lang_constants:Get("rune_pos_no_equip_desc"))
        self.rune_desc_text:setColor(panel_util:GetColor4B(0xffd100))

    end
end

function rune_equip_panel:ShowRuneEquipmentPropertys()
    local rune_property = rune_logic:GenerateRuneListPropertys(rune_logic:GetRuneEquipmentList())

    for key,propertys in pairs(rune_property) do
        for property_name,property_value in pairs(propertys) do
            local color = panel_util:GetColor4B(client_constants["TEXT_COLOR"]["write"])
            if property_value > 0 then
                color = panel_util:GetColor4B(client_constants["TEXT_COLOR"]["green"])
                property_value = string.format("+%d", property_value)
            elseif property_value < 0 then
                color = panel_util:GetColor4B(client_constants["TEXT_COLOR"]["red"])
            end
            self.property_text_list[key][property_name]:setColor(color)
            self.property_text_list[key][property_name]:setString(tostring(property_value))
        end
    end
end

function rune_equip_panel:ShowRuneEquipment()
    local rune_equipment_list = rune_logic:GetRuneEquipmentList()
    for pos = 1, constants["MAX_RUNE_EQUIPMENT_NUM"] do
        local sub_panel = self.rune_sub_panels[pos]
        sub_panel:Show(rune_equipment_list[pos])
    end

    self.rune_sub_panels[self.cur_select_pos]:SetRuneSelectSprite( true )
    self:ShowReplaceAndLevelUpBtn(self.rune_sub_panels[self.cur_select_pos].rune_info)
    self:ShowRuneDesc()
    self:ShowRuneEquipmentPropertys()
    self:UpdatePresetStrip()
end

function rune_equip_panel:ShowReplaceAndLevelUpBtn( rune_info )
    if rune_info then
        self.replace_btn:setColor(panel_util:GetColor4B(client_constants["TEXT_COLOR"]["write"]))
        if rune_info.level < rune_info.template_info.level_limit then
            self.levelup_btn:setColor(panel_util:GetColor4B(client_constants["TEXT_COLOR"]["write"]))
        else
            self.levelup_btn:setColor(panel_util:GetColor4B(client_constants["TEXT_COLOR"]["gray"]))
        end
    else
        self.replace_btn:setColor(panel_util:GetColor4B(client_constants["TEXT_COLOR"]["gray"]))
        self.levelup_btn:setColor(panel_util:GetColor4B(client_constants["TEXT_COLOR"]["gray"]))
    end
end

function rune_equip_panel:CreateEquipPos()
    for pos = 1, constants["MAX_RUNE_EQUIPMENT_NUM"] do
        local sub_panel = equip_pos_sub_panel.New()
        sub_panel:Init(pos, self.equip_pos_templates[pos])

        sub_panel.equip_rune_btn:setTag(pos)
        sub_panel.equip_rune_btn:addTouchEventListener(self.equip_rune_method)
        self.rune_sub_panels[pos] = sub_panel
    end
end

function rune_equip_panel:RegisterEvent()
    graphic:RegisterEvent("update_resource_list", function()
        if not self.root_node:isVisible() then
            return
        end

    end)

    graphic:RegisterEvent("rune_bag_select_confirm", function(show_type, select_rune_list)
        if not self.root_node:isVisible() then
            return
        end

        if show_type ~= client_constants["RUNE_BAG_SHOW_TYPE"]["EQUIP"] or #select_rune_list == 0 then
            return
        end

        rune_logic:EquipRune(self.cur_select_pos, select_rune_list[1])
    end)

    graphic:RegisterEvent("refresh_rune_equipment", function()
        if not self.root_node:isVisible() then
            return
        end
        self:ShowRuneEquipment()
    end)

    graphic:RegisterEvent("rune_presets_updated", function()
        if not self.root_node:isVisible() then
            return
        end
        self:UpdatePresetStrip()
        if self._preset_dlg and self._preset_dlg.root and not tolua.isnull(self._preset_dlg.root) then
            self:PopulatePresetManagerCards()
        end
    end)

end

function rune_equip_panel:RegisterWidgetEvent()
    --点击装备格
    self.equip_rune_method = function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            local pos = widget:getTag()
            local sub_panel = self.rune_sub_panels[pos]
            if not sub_panel.rune_info then
                graphic:DispatchEvent("show_world_sub_scene", "rune_bag_sub_scene", constants["SCENE_TRANSITION_TYPE"]["none"], client_constants["RUNE_BAG_SHOW_TYPE"]["EQUIP"])
            end

            self.rune_sub_panels[self.cur_select_pos]:SetRuneSelectSprite( false )
            self.cur_select_pos = pos
            self.rune_sub_panels[self.cur_select_pos]:SetRuneSelectSprite( true )

            self:ShowReplaceAndLevelUpBtn(sub_panel.rune_info)
            self:UpdatePresetStrip()

            self:ShowRuneDesc()
        end
    end

    --替换
    self.replace_btn:addTouchEventListener(function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            
            if self.rune_sub_panels[self.cur_select_pos].rune_info then
                graphic:DispatchEvent("show_world_sub_scene", "rune_bag_sub_scene", constants["SCENE_TRANSITION_TYPE"]["none"], client_constants["RUNE_BAG_SHOW_TYPE"]["EQUIP"], { self.rune_sub_panels[self.cur_select_pos].rune_info })
            else
                graphic:DispatchEvent("show_prompt_panel", "no_replace_rune")
            end
        end
    end)

    --升级
    self.levelup_btn:addTouchEventListener(function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            
            local rune_info = self.rune_sub_panels[self.cur_select_pos].rune_info
            if rune_info then
                if rune_info.level < rune_info.template_info.level_limit then
                    graphic:DispatchEvent("show_world_sub_scene", "rune_upgrade_sub_scene", constants["SCENE_TRANSITION_TYPE"]["none"], rune_info)
                else
                    graphic:DispatchEvent("show_prompt_panel", "rune_already_max_level")
                end
            else
                graphic:DispatchEvent("show_prompt_panel", "no_target_rune")
            end
        end
    end)

    --符文交换
    self.draw_btn:addTouchEventListener(function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            if feature_config:IsFeatureOpen("rune_exchange") then
                graphic:DispatchEvent("show_world_sub_scene", "rune_exchange_sub_scene", constants["SCENE_TRANSITION_TYPE"]["none"], true)
            end
        end
    end)

    --符文背包
    self.bag_btn:addTouchEventListener(function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            
            graphic:DispatchEvent("show_world_sub_scene", "rune_bag_sub_scene", constants["SCENE_TRANSITION_TYPE"]["none"], client_constants["RUNE_BAG_SHOW_TYPE"]["PACKAGE"])
        end
    end)

    self.back_btn:addTouchEventListener(function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            if self._preset_dlg and type(self._preset_dlg.Close) == "function" then
                self._preset_dlg.Close()
            end
            self.rune_sub_panels[self.cur_select_pos]:SetRuneSelectSprite( false )
            self.cur_select_pos = 1
            graphic:DispatchEvent("hide_world_sub_scene")
        end
    end)
end

-- [MOD] 主界面多套符文快捷切换条 + 单槽卸下按钮（1A 四色统一像素按钮）
function rune_equip_panel:CreatePresetWidgets()
    self.preset_quick_btns = {}
    local positions = {
        { x = 50,  y = 816 },
        { x = 122, y = 816 },
        { x = 194, y = 816 },
        { x = 446, y = 816 },
        { x = 518, y = 816 },
    }
    for i = 1, 5 do
        local idx = i
        local btn = pixel_kit:CreateButton({
            style = "grey",
            title = "套" .. tostring(idx),
            font_size = 17,
            size = cc.size(66, 36),
            pos = cc.p(positions[idx].x, positions[idx].y),
            on_click = function()
                local p = rune_logic:GetPresets()[idx]
                if p and p.saved then
                    if rune_logic:GetActivePresetIndex() == idx then
                        pixel_kit:ShowToast(string.format("当前已应用「%s」", rune_logic:GetPresetDisplayName(idx)), 0xa1e01b)
                    else
                        rune_logic:ApplyPreset(idx)
                    end
                else
                    self:ShowPresetManagerDialog()
                end
            end,
        })
        self.root_node:addChild(btn, 50)
        self.preset_quick_btns[idx] = btn
    end

    self.preset_mgr_btn = pixel_kit:CreateButton({
        style = "gold",
        title = "方 案",
        font_size = 17,
        size = cc.size(66, 36),
        pos = cc.p(590, 816),
        on_click = function()
            self:ShowPresetManagerDialog()
        end,
    })
    self.root_node:addChild(self.preset_mgr_btn, 50)

    self.unequip_slot_btn = pixel_kit:CreateButton({
        style = "grey",
        title = "卸下槽位",
        font_size = 17,
        size = cc.size(116, 40),
        pos = cc.p(562, 898),
        on_click = function()
            local sp = self.rune_sub_panels[self.cur_select_pos]
            if sp and sp.rune_info then
                rune_logic:UnequipSlot(self.cur_select_pos)
            else
                pixel_kit:ShowToast("当前选中槽位未装备符文", 0xf5d66b)
            end
        end,
    })
    self.root_node:addChild(self.unequip_slot_btn, 50)
end

function rune_equip_panel:UpdatePresetStrip()
    if not self.preset_quick_btns then
        return
    end
    local presets = rune_logic:GetPresets()
    local active_idx = rune_logic:GetActivePresetIndex()
    for i = 1, 5 do
        local btn = self.preset_quick_btns[i]
        if btn and not tolua.isnull(btn) then
            local p = presets[i]
            if p and p.saved and active_idx == i then
                pixel_kit:ApplyButtonStyle(btn, "green")
            elseif p and p.saved then
                pixel_kit:ApplyButtonStyle(btn, "gold")
            else
                pixel_kit:ApplyButtonStyle(btn, "grey")
            end
        end
    end
    if self.unequip_slot_btn and not tolua.isnull(self.unequip_slot_btn) then
        local sp = self.rune_sub_panels[self.cur_select_pos]
        local has_rune = sp and sp.rune_info ~= nil
        pixel_kit:ApplyButtonStyle(self.unequip_slot_btn, has_rune and "orange" or "grey")
    end
end

local STAT_SHORT_ORDER = {
    { key = "speed", label = "先" },
    { key = "defense", label = "防" },
    { key = "dodge", label = "闪" },
    { key = "authority", label = "王" },
}

local function formatPresetStatSummary(rune_list)
    local props = rune_logic:GenerateRuneListPropertys(rune_list)
    local function fmtGroup(tbl, prefix)
        local parts = {}
        for _, item in ipairs(STAT_SHORT_ORDER) do
            local v = tonumber(tbl and tbl[item.key]) or 0
            if v ~= 0 then
                parts[#parts + 1] = string.format("%s%s%d", item.label, v > 0 and "+" or "", v)
            end
        end
        if #parts == 0 then
            return nil
        end
        return prefix .. " " .. table.concat(parts, " ")
    end
    local mine_str = fmtGroup(props.mine_property, "己")
    local enemy_str = fmtGroup(props.enemy_property, "敌")
    if mine_str and enemy_str then
        return mine_str .. "  |  " .. enemy_str
    elseif mine_str then
        return mine_str
    elseif enemy_str then
        return enemy_str
    end
    return "空预设（应用后将卸下全部符文）"
end

function rune_equip_panel:ShowRenamePresetDialog(idx)
    local cur_name = rune_logic:GetPresetDisplayName(idx)
    local rdlg = pixel_kit:CreateDialog(self.root_node, {
        title = string.format("重命名方案 %d", idx),
        width = 472,
        height = 290,
        pos_y = 590,
        z_order = 360,
    })
    local inner = rdlg.inner
    local iw = rdlg.inner_w
    local top_y = rdlg.content_top

    pixel_kit:CreatePaperCard(inner, {
        width = iw,
        height = top_y - 76,
        pos = cc.p(iw * 0.5, 70 + (top_y - 76) * 0.5),
        z_order = 1,
    })

    inner:addChild(pixel_kit:CreateLabel("输入方案名称（最多 8 个字）", {
        font_size = 18,
        color = 0x5b4827,
        pos = cc.p(iw * 0.5, top_y - 28),
        outline = false,
    }), 3)

    local box_w, box_h = 300, 48
    local box_border = ccui.Layout:create()
    box_border:setContentSize(cc.size(box_w, box_h))
    box_border:setAnchorPoint(0.5, 0.5)
    box_border:setPosition(iw * 0.5, top_y - 78)
    box_border:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
    box_border:setBackGroundColor(cc.c3b(22, 17, 9))
    box_border:setBackGroundColorOpacity(255)
    inner:addChild(box_border, 3)

    local box_fill = ccui.Layout:create()
    box_fill:setContentSize(cc.size(box_w - 4, box_h - 4))
    box_fill:setAnchorPoint(0.5, 0.5)
    box_fill:setPosition(box_w * 0.5, box_h * 0.5)
    box_fill:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
    box_fill:setBackGroundColor(cc.c3b(44, 35, 22))
    box_fill:setBackGroundColorOpacity(255)
    box_border:addChild(box_fill, 1)

    local tf = ccui.TextField:create("请输入方案名", client_constants["FONT_FACE"], 22)
    tf:setString(cur_name)
    tf:setMaxLengthEnabled(true)
    tf:setMaxLength(16)
    tf:setTouchAreaEnabled(true)
    tf:setTouchSize(cc.size(box_w - 4, box_h - 4))
    tf:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    tf:setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
    tf:setPosition((box_w - 4) * 0.5, (box_h - 4) * 0.5)
    tf:setTextColor(cc.c4b(255, 234, 156, 255))
    box_fill:addChild(tf, 2)

    inner:addChild(pixel_kit:CreateButton({
        style = "grey",
        title = "取 消",
        font_size = 20,
        size = cc.size(156, 46),
        pos = cc.p(iw * 0.5 - 92, 30),
        on_click = function()
            rdlg.Close()
        end,
    }), 4)

    inner:addChild(pixel_kit:CreateButton({
        style = "green",
        title = "确认改名",
        font_size = 20,
        size = cc.size(156, 46),
        pos = cc.p(iw * 0.5 + 92, 30),
        on_click = function()
            rune_logic:RenamePreset(idx, tf:getString())
            rdlg.Close()
        end,
    }), 4)
end

function rune_equip_panel:ShowPresetManagerDialog()
    if self._preset_dlg and self._preset_dlg.root and not tolua.isnull(self._preset_dlg.root) then
        self:PopulatePresetManagerCards()
        return
    end
    local dlg = pixel_kit:CreateDialog(self.root_node, {
        title = "多套符文预设",
        width = 588,
        height = 836,
        pos_y = 576,
        z_order = 320,
        on_close = function()
            self._preset_dlg = nil
        end,
    })
    self._preset_dlg = dlg
    local inner = dlg.inner
    local iw = dlg.inner_w
    local top_y = dlg.content_top

    inner:addChild(pixel_kit:CreateLabel("保存 5 套符文搭配 · 一键切换自动替换/卸下当前符文", {
        font_size = 16,
        color = 0x5b4827,
        pos = cc.p(iw * 0.5, top_y - 16),
        outline = false,
    }), 3)

    local cards_node = cc.Node:create()
    inner:addChild(cards_node, 2)
    dlg.cards_node = cards_node
    dlg.cards_top_y = top_y - 38

    inner:addChild(pixel_kit:CreateButton({
        style = "orange",
        title = "一键全卸",
        font_size = 21,
        size = cc.size(180, 48),
        pos = cc.p(iw * 0.5 - 108, 32),
        on_click = function()
            rune_logic:UnequipAll()
        end,
    }), 4)

    inner:addChild(pixel_kit:CreateButton({
        style = "grey",
        title = "返 回",
        font_size = 21,
        size = cc.size(180, 48),
        pos = cc.p(iw * 0.5 + 108, 32),
        on_click = function()
            dlg.Close()
        end,
    }), 4)

    self:PopulatePresetManagerCards()
end

function rune_equip_panel:PopulatePresetManagerCards()
    local dlg = self._preset_dlg
    if not dlg or not dlg.cards_node or tolua.isnull(dlg.cards_node) then
        return
    end
    local cards_node = dlg.cards_node
    cards_node:removeAllChildren()

    local iw = dlg.inner_w
    local card_w = iw - 6
    local card_h = 114
    local gap = 8
    local presets = rune_logic:GetPresets()
    local active_idx = rune_logic:GetActivePresetIndex()

    for i = 1, 5 do
        local idx = i
        local p = presets[idx] or { id = idx, saved = false, slots = { 0, 0, 0, 0, 0 } }
        local is_active = p.saved and active_idx == idx
        local card_y = dlg.cards_top_y - (idx - 1) * (card_h + gap) - card_h * 0.5

        local card = pixel_kit:CreatePaperCard(cards_node, {
            width = card_w,
            height = card_h,
            pos = cc.p(iw * 0.5, card_y),
            z_order = 1,
        })

        local name = rune_logic:GetPresetDisplayName(idx)
        local title_txt = name
        local title_color = 0x7d6b4c
        if is_active then
            title_txt = name .. "  [当前使用]"
            title_color = 0x2f5e11
        elseif p.saved then
            title_txt = name .. "  [已保存]"
            title_color = 0x3b260b
        else
            title_txt = name .. "  [未保存]"
        end

        card:addChild(pixel_kit:CreateLabel(title_txt, {
            font_size = 18,
            color = title_color,
            anchor = cc.p(0, 0.5),
            pos = cc.p(14, card_h - 19),
            outline = false,
        }), 3)

        local resolved_runes = {}
        for pos = 1, 5 do
            local rinfo = rune_logic:FindRuneById(p.slots and p.slots[pos] or 0)
            if rinfo then
                resolved_runes[#resolved_runes + 1] = rinfo
            end
        end

        local summary_str = p.saved and formatPresetStatSummary(resolved_runes) or "未保存 · 点击「存当前」存入当前 5 槽装配"
        local summary_lbl = pixel_kit:CreateLabel(summary_str, {
            font_size = 14,
            color = p.saved and 0x5b4827 or 0x8b7b60,
            size = cc.size(card_w - 190, 22),
            align = cc.TEXT_ALIGNMENT_LEFT,
            valign = cc.VERTICAL_TEXT_ALIGNMENT_CENTER,
            anchor = cc.p(0, 0.5),
            pos = cc.p(14, card_h - 43),
            outline = false,
        })
        card:addChild(summary_lbl, 3)

        -- 左侧 5 个迷你符文槽位预览
        for pos = 1, 5 do
            local sx = 34 + (pos - 1) * 56
            local sy = 32
            local slot_bg = ccui.Layout:create()
            slot_bg:setContentSize(cc.size(44, 44))
            slot_bg:setAnchorPoint(0.5, 0.5)
            slot_bg:setPosition(sx, sy)
            slot_bg:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
            slot_bg:setBackGroundColor(cc.c3b(44, 35, 22))
            slot_bg:setBackGroundColorOpacity(235)
            card:addChild(slot_bg, 2)

            local rid = p.slots and p.slots[pos] or 0
            local rinfo = rune_logic:FindRuneById(rid)
            if rinfo then
                local icon = ccui.ImageView:create(CheckTextureCache(rinfo.template_info.icon), PLIST_TYPE)
                icon:ignoreContentAdaptWithSize(false)
                icon:setContentSize(cc.size(34, 34))
                icon:setPosition(22, 24)
                slot_bg:addChild(icon, 2)

                local lv_txt = (rinfo.level >= rinfo.template_info.level_limit) and "MAX" or ("Lv" .. tostring(rinfo.level))
                slot_bg:addChild(pixel_kit:CreateLabel(lv_txt, {
                    font_size = 11,
                    color = 0xffe44d,
                    anchor = cc.p(0.5, 0),
                    pos = cc.p(22, 0),
                    outline_size = 1,
                }), 3)
            else
                slot_bg:addChild(pixel_kit:CreateLabel(p.saved and "-" or "·", {
                    font_size = 16,
                    color = 0x8b7b60,
                    pos = cc.p(22, 22),
                    outline = false,
                }), 2)
            end
        end

        -- 右侧 2x2 统一 1A 按钮矩阵：应用 / 清 / 存当前 / 改名
        local col1_x = card_w - 118
        local col2_x = card_w - 38
        local row1_y = card_h - 32
        local row2_y = 32

        local apply_style = is_active and "grey" or (p.saved and "green" or "grey")
        local apply_title = is_active and "已应用" or (p.saved and "应 用" or "未保存")
        card:addChild(pixel_kit:CreateButton({
            style = apply_style,
            title = apply_title,
            font_size = 17,
            size = cc.size(96, 36),
            pos = cc.p(col1_x, row1_y),
            on_click = function()
                if not p.saved then
                    pixel_kit:ShowToast("请先点击「存当前」保存该方案", 0xf5d66b)
                elseif is_active then
                    pixel_kit:ShowToast("当前已应用该方案", 0xa1e01b)
                else
                    rune_logic:ApplyPreset(idx)
                end
            end,
        }), 4)

        card:addChild(pixel_kit:CreateButton({
            style = "grey",
            title = "清 空",
            font_size = 15,
            size = cc.size(56, 36),
            pos = cc.p(col2_x, row1_y),
            on_click = function()
                if p.saved then
                    rune_logic:ClearPreset(idx)
                else
                    pixel_kit:ShowToast("该方案为空，无需清空", 0xf5d66b)
                end
            end,
        }), 4)

        card:addChild(pixel_kit:CreateButton({
            style = "gold",
            title = "存当前",
            font_size = 17,
            size = cc.size(96, 36),
            pos = cc.p(col1_x, row2_y),
            on_click = function()
                rune_logic:SavePreset(idx)
            end,
        }), 4)

        card:addChild(pixel_kit:CreateButton({
            style = "grey",
            title = "改 名",
            font_size = 15,
            size = cc.size(56, 36),
            pos = cc.p(col2_x, row2_y),
            on_click = function()
                self:ShowRenamePresetDialog(idx)
            end,
        }), 4)
    end
end

return rune_equip_panel

