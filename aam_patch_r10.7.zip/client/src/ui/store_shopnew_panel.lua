local panel_prototype = require "ui.panel"
local panel_util = require "ui.panel_util"
local icon_template = require "ui.icon_panel"

local config_manager = require "logic.config_manager"
local constants = require "util.constants"
local client_constants = require "util.client_constants"
local audio_manager = require "util.audio_manager"
local lang_constants = require "util.language_constants"
local platform_manager = require "logic.platform_manager"
local feature_config = require "logic.feature_config"

local graphic = require "logic.graphic"
local resource_logic = require "logic.resource"
local store_logic = require "logic.store"
local payment_logic = require "logic.payment"
local helper = require "util.helper"
local tableview = require "helper.tableview"

local Game = require "Game"
local PLIST_TYPE = ccui.TextureResType.plistType
local CARNIVAL_TEMPLATE_TYPE = client_constants.CARNIVAL_TEMPLATE_TYPE

-- 从道具商店移到血钻商店的商品（服务端 ID 保持稳定）。
local BLOOD_STORE_GOOD_IDS = {
    [1] = true,  -- 初级矿石包
    [2] = true,  -- 中级矿石包
    [3] = true,  -- 高级矿石包
    [4] = true,  -- 佣兵列表上限+1
    [5] = true,  -- 矿镐耐久上限+1
    [6] = true,  -- 迷宫宝箱上限+1
    [7] = true,  -- 雷管
    [8] = true,  -- 矿工包
    [13] = true, -- 闪耀矿稿
    [27] = true, -- 水晶包
    [900003] = true, -- 主角变幻币*800（16000042）
    [900004] = true, -- 随机闪金灵魂石
    [900005] = true, -- 酒馆积分*1000
    [900006] = true, -- 友情点*10000
    [900007] = true, -- 灵魂石合成材料盲盒
    [900021] = true, -- 矿区钥匙组合包
    [900022] = true, -- 天空神像
    [900023] = true, -- 冒险成长补给包
}

-- 道具商城（代金券）商品。
local CASH_STORE_GOOD_IDS = client_constants.CASH_STORE_GOOD_IDS

local meta = panel_prototype.New()
function meta:Init()
    self.root_node = (require "util.helper"):Loader("ui/store_shopnew_panel.csb")

    self.back_btn = helper:getChild(self.root_node, "store_new_panel.back_btn")

    self.btn_1 = helper:getChild(self.root_node, "store_new_panel.btn_1")
    helper:SetCocosSetting(self.btn_1, "ui/store_shopnew_btn_template.csb")
    helper:BindTimeLine(self.btn_1, "ui/store_shopnew_btn_template.csb")
    self.btn_btn_1 = helper:getChild(self.btn_1, "btn_template.btn")
    self.btn_1_desc = helper:getChild(self.btn_1, "btn_template.desc")
    self.btn_1_remind_icon = helper:getChild(self.btn_1, "btn_template.remind_icon")
    helper:SetTextByKey(self.btn_1_desc, "shop_new_panel_btn_desc_1")
    helper:AddClick(self.btn_btn_1, function()
        self.select_btn_index = 1
        self:UpdateBtn()
        self:UpdateTab()

        Game:SendLog(Game.log_type.open_gift_store)

        if Game.vip:isMonthUser() == false then
            local vip_data = Game:GetUserData("vip_btn_vip")
            local date_value = vip_data:setKeyValue("date_value", Game:GetDate())
            self.btn_1_remind_icon:setVisible(false)
        end

    end)

    self.btn_2 = helper:getChild(self.root_node, "store_new_panel.btn_2")
    helper:SetCocosSetting(self.btn_2, "ui/store_shopnew_btn_template.csb")
    helper:BindTimeLine(self.btn_2, "ui/store_shopnew_btn_template.csb")
    self.btn_btn_2 = helper:getChild(self.btn_2, "btn_template.btn")
    self.btn_2_desc = helper:getChild(self.btn_2, "btn_template.desc")
    helper:SetTextByKey(self.btn_2_desc, "shop_new_panel_btn_desc_2")
    helper:AddClick(self.btn_btn_2, function()
        self.select_btn_index = 2
        self:UpdateBtn()
        self:UpdateTab()

        Game:SendLog(Game.log_type.open_blood_store)

    end)

    self.btn_3 = helper:getChild(self.root_node, "store_new_panel.btn_3")
    helper:SetCocosSetting(self.btn_3, "ui/store_shopnew_btn_template.csb")
    helper:BindTimeLine(self.btn_3, "ui/store_shopnew_btn_template.csb")
    self.btn_btn_3 = helper:getChild(self.btn_3, "btn_template.btn")
    self.btn_3_desc = helper:getChild(self.btn_3, "btn_template.desc")
    helper:SetTextByKey(self.btn_3_desc, "shop_new_panel_btn_desc_3")
    helper:AddClick(self.btn_btn_3, function()
        self.select_btn_index = 3
        self:UpdateBtn()

        self:UpdateTab()
        Game:SendLog(Game.log_type.open_item_store)

    end)

    self.btn_list = {}
    table.insert(self.btn_list, self.btn_1)
    table.insert(self.btn_list, self.btn_2)
    table.insert(self.btn_list, self.btn_3)

    self.select_btn_index = 1

    self.template_listview = helper:getChild(self.root_node, "store_new_panel.template_2")
    self.template_1 = helper:getChild(self.root_node, "store_new_panel.template_1")
    self.template_1:setVisible(false)
    self.template_listview:setVisible(true)
    -- [PC PORT] both stencil and scissor clipping hide this ListView's rows on
    -- Windows.  Instead hide list rows that leave the visible strip between
    -- the tab strip and the footer; this keeps the shop background intact and
    -- stops rows from drawing through the chrome.
    if self.template_listview.setClippingEnabled then
        self.template_listview:setClippingEnabled(false)
    end
    for _, chrome in ipairs({
        "top_bg", "top_shadow", "top_board", "bg_title",
        "btn_bg", "btn_1", "btn_2", "btn_3",
        "bottom_bg", "bottom_shadow", "bottom_board", "back_btn", "desc_title",
    }) do
        local node = helper:getChild(self.root_node, "store_new_panel." .. chrome)
        if node then
            -- Keep the chrome above the list for the transparent gaps.
            node:setLocalZOrder(100)
        end
    end
    -- [PC PORT] The CSB ListView cannot clip on this Windows build.  Use the
    -- same cc.TableView-based list as 召唤/竞技 for every shop tab; TableView
    -- clips cells natively at the frame edge instead of hiding whole rows.
    do
        local panel = helper:getChild(self.root_node, "store_new_panel")
        local shop_view = tableview.new(cc.size(640, 733), cc.size(630, 172))
        shop_view:setPosition(cc.p(-320, 167))
        shop_view:setLocalZOrder(10)
        shop_view:setBackGroundColor(nil, 0)
        panel:addChild(shop_view)
        self.shop_view = shop_view
        self.table_rows = {}

        shop_view:UpdateCellNums(function()
            return #(self.table_rows or {})
        end)
        shop_view:UpdateSizeForCell(function(index)
            local row = self.table_rows[index]
            -- 这个 cc.TableView 绑定按 (宽, 高) 取尺寸；之前高度放第一位，
            -- 每个商品行被当成 630 高，商店列表才有巨大空白。
            return 630, (row and row.kind == "direct_title") and 56 or 172
        end)
        shop_view:UpdateCreateCell(function(cell, index)
            self:CreateShopCell(cell, index)
            return true
        end)
        shop_view:UpdateCell(function(cell, index)
            local row = self.table_rows[index]
            if not row then
                return
            end
            if cell.shop_kind ~= row.kind or not cell.shop_item then
                self:CreateShopCell(cell, index)
            else
                self:SetupShopCell(cell, index)
            end
        end)
        shop_view:UpdateCellClick(function(index)
            local row = self.table_rows[index]
            if not row or self.scroll_touch == true then
                return
            end
            if row.kind == "blood" then
                payment_logic:TryBuy(row.info)
            elseif row.kind == "direct" then
                graphic:DispatchEvent("show_world_sub_panel", "store_shopnew_vip_panel",
                    row.info.rmb_title, row.group_index)
            elseif row.kind == "goods" then
                local info = store_logic:GetGoodsInfo(row.goods_index)
                if info and CASH_STORE_GOOD_IDS[info.id] then
                    -- 代金券礼包点一下就买一份；buy_btn 的点击也会走到这里。
                    store_logic:BuyGoods(row.goods_index, 1)
                    return
                end
                graphic:DispatchEvent("show_world_sub_panel", "store_msgbox",
                    client_constants.BATCH_MSGBOX_MODE.blood_store, row.goods_index)
            end
        end)
    end

    self.template_4 = helper:getChild(self.root_node, "store_new_panel.template_4_sale_giftbag")
    if self.template_4 ~= nil then
        self.template_4:setVisible(false)
    end

    self.touch_listener = ccui.Layout:create()
    self.touch_listener:setContentSize(helper:GetFrameSize().width, helper:GetFrameSize().height)
    self.touch_listener:setSwallowTouches(false)
    self.root_node:addChild(self.touch_listener)
    self.touch_listener:setLocalZOrder(1000)
    if not self.listener then
        local location_node_begin = 0
        local location_node_spacing = 30 -- 判断是否是滑动的值
        local start_pos = 0
        local end_pos = 0
        local function onTouchBegan(touch, event)
            location_node_begin = self.root_node:convertToNodeSpace(touch:getLocation()).y
            return true
        end
        local function onTouchMoved(touch, event)
        end
        local function onTouchEnded(touch, event)
            local location_node_end = self.root_node:convertToNodeSpace(touch:getLocation()).y
            if location_node_begin > location_node_end then
                if (location_node_begin - location_node_spacing) > location_node_end then
                    self.scroll_touch = true
                else
                    self.scroll_touch = false
                end
            else
                if (location_node_begin + location_node_spacing) < location_node_end then
                    self.scroll_touch = true
                else
                    self.scroll_touch = false
                end
            end
        end
        self.listener = cc.EventListenerTouchOneByOne:create()
        self.listener:setSwallowTouches(false)
        self.listener:registerScriptHandler(onTouchBegan, cc.Handler.EVENT_TOUCH_BEGAN)
        self.listener:registerScriptHandler(onTouchMoved, cc.Handler.EVENT_TOUCH_MOVED)
        self.listener:registerScriptHandler(onTouchEnded, cc.Handler.EVENT_TOUCH_ENDED)
        self.touch_listener:getEventDispatcher():addEventListenerWithSceneGraphPriority(self.listener,
            self.touch_listener)
    end

    self:RegisterEvent()
    self:RegisterWidgetEvent()

    graphic:RegisterEvent("update_store_shop_panel", function()
        self:UpdateBtn()
        -- A purchase refreshes the list; keep the player at the row they were
        -- browsing instead of snapping back to the top.
        self:UpdateTab(true)
    end)

    Game.graphic:RegisterEvent("take_vip_reward_success", function()
        self.btn_1_remind_icon:setVisible(false)
        local t = {"adventure", "whileGold", "lastGold"}
        for k, v in pairs(t) do
            local can_reward = Game.vip:VipReward(constants["VIP_TYPE"][v])
            if can_reward == true then
                self.btn_1_remind_icon:setVisible(true)
            end
        end

        for k, v in pairs(self.direct_purchase_title_template) do
            v:SetInfo()
        end

    end)

    self.first_open = true

    -- [PC PORT] The CSB back button's touch box sits ~35px below the drawn
    -- arrow on this runtime, so tapping the arrow itself misses.  Cover the
    -- artwork with an explicit click area.
    do
        local back_hit = ccui.Layout:create()
        back_hit:setContentSize(cc.size(233, 90))
        back_hit:setPosition(cc.p(-283, 208))
        back_hit:setTouchEnabled(true)
        back_hit:addTouchEventListener(function(widget, event_type)
            if event_type == ccui.TouchEventType.ended then
                audio_manager:PlayEffect("click")
                graphic:DispatchEvent("hide_world_sub_scene")
            end
        end)
        local panel = helper:getChild(self.root_node, "store_new_panel")
        if panel then
            panel:addChild(back_hit)
            back_hit:setLocalZOrder(101)
            -- [MOD r10.3] 道具商店右上角增加「心愿祈愿」快捷入口，直达代金券心愿祈愿池
            local pixel_kit = require "ui.pixel_kit"
            local wish_btn = pixel_kit:CreateButton({
                style = "gold",
                title = "心愿祈愿",
                font_size = 18,
                size = cc.size(126, 40),
                pos = cc.p(232, 246),
                on_click = function()
                    local wish_pool_dialog = require "ui.wish_pool_dialog"
                    wish_pool_dialog:Show(self.root_node)
                end,
            })
            panel:addChild(wish_btn, 102)
            self.wish_pool_btn = wish_btn
        end
    end

end

function meta:UpdateBtn()
    for k, v in pairs(self.btn_list) do
        if k == self.select_btn_index then
            self.btn_list[self.select_btn_index]:GotoFrame(1)
        else
            self.btn_list[k]:GotoFrame(2)
        end
    end

end

function meta:Show(index)
    self.root_node:setVisible(true)
    if index ~= nil then
        -- Explicit tab request (the 商店 entry passes 3 = 道具商店, where the
        -- free item/pack catalogue lives).
        self.select_btn_index = index
    else
        local config = Game.carnival:GetSpecialCarnival(CARNIVAL_TEMPLATE_TYPE["first_payment"])
        if not config then
            if Game.payment.buy_blood_flag == true then
                self.select_btn_index = 2
            else
                self.select_btn_index = 1
            end
        else
            self.select_btn_index = 2
        end
    end

    -- 周四
    if Game.time:GetWeek() == 4 then
        if self.first_open == true then
            local is_open = Game:GetUserData("week_4_open"):getKeyValue("week_4_open")
            if is_open == true then
            else
                self.select_btn_index = 1
                self.first_open = false
                Game:GetUserData("week_4_open"):setKeyValue("week_4_open", true)
            end
        end
    else
        Game:GetUserData("week_4_open"):setKeyValue("week_4_open", false)
    end

    self:UpdateBtn()
    self:UpdateTab()

    Game.graphic:DispatchEvent("take_vip_reward_success")

    Game:SendLog(Game.log_type.open_store)

    if Game.vip:isMonthUser() == false then
        local vip_data = Game:GetUserData("vip_btn_vip")
        local date_value = vip_data:getKeyValue("date_value")
        if date_value ~= Game:GetDate() then
            self.btn_1_remind_icon:setVisible(true)
        else
        end
    end

end

function meta:RegisterEvent()

end

function meta:RegisterWidgetEvent()
    self.back_btn:addTouchEventListener(function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            graphic:DispatchEvent("hide_world_sub_scene")
        end
    end)

end

function meta:UpdateTab(keep_pos)
    self.template_listview:setVisible(false)
    self.direct_purchase_title_template = {}
    local rows = {}
    self.table_rows = rows

    if self.select_btn_index == 1 then
        local gift_list = payment_logic:GetGiftList()
        for k, info_list in pairs(gift_list) do
            table.insert(rows, { kind = "direct_title", desc = lang_constants.rmb_title[k] })
            for i = 1, #info_list do
                table.insert(rows, { kind = "direct", info = info_list[i], group_index = i })
            end
        end
    elseif self.select_btn_index == 2 then
        local goods_num = store_logic:GetGoodsNum()
        for i = 1, goods_num do
            local info = store_logic:GetGoodsInfo(i)
            if info and BLOOD_STORE_GOOD_IDS[info.id] then
                table.insert(rows, { kind = "goods", goods_index = i, blood = true })
            end
        end
    else
        -- 道具商城：代金券商品（宝藏礼包 + 每日限购平衡补给）。
        table.insert(rows, { kind = "direct_title", desc = "宝藏礼包" })
        local goods_num = store_logic:GetGoodsNum()
        local daily_rows = {}
        for i = 1, goods_num do
            local info = store_logic:GetGoodsInfo(i)
            if info and CASH_STORE_GOOD_IDS[info.id] ~= nil then
                if info.id == 900001 or info.id == 900002 then
                    table.insert(rows, { kind = "goods", goods_index = i })
                else
                    table.insert(daily_rows, { kind = "goods", goods_index = i })
                end
            end
        end
        if #daily_rows > 0 then
            table.insert(rows, { kind = "direct_title", desc = "每日限购补给" })
            for _, r in ipairs(daily_rows) do
                table.insert(rows, r)
            end
        end
    end

    if self.shop_view then
        self.shop_view:Refresh(keep_pos == true)
    end
end

function meta:CreateShopCell(cell, index)
    local row = self.table_rows[index]
    if not row then
        return
    end
    cell:removeAllChildren()
    cell.shop_kind = row.kind
    local item
    if row.kind == "direct_title" then
        item = require("ui.store_shopnew_direct_purchase_title_panel").new()
    elseif row.kind == "direct" then
        item = require("ui.store_shopnew_direct_purchase_template").new()
    elseif row.kind == "blood" then
        item = require("ui.store_shopnew_blood_diamond_template").new()
    else
        item = require("ui.store_shopnew_panel_item").new()
    end
    cell.shop_item = item
    cell:addChild(item:GetLayout())
    if row.kind == "direct" then
        table.insert(self.direct_purchase_title_template, item)
    end
    self:SetupShopCell(cell, index)
end

function meta:SetupShopCell(cell, index)
    local row = self.table_rows[index]
    local item = cell.shop_item
    if not row or not item then
        return
    end
    if row.kind == "direct_title" then
        item:SetDesc(row.desc)
    elseif row.kind == "direct" then
        item:SetInfo(row.info)
        item:AddClick(function(product)
            if self.scroll_touch == true then
                return
            end
            graphic:DispatchEvent("show_world_sub_panel", "store_shopnew_vip_panel",
                product.rmb_title, row.group_index)
        end)
    elseif row.kind == "blood" then
        item:SetInfo(row.info)
        item:AddClick(function(product)
            if self.scroll_touch == true then
                return
            end
            payment_logic:TryBuy(product)
        end)
    else
        local product = store_logic:GetGoodsInfo(row.goods_index)
        if not product then
            return
        end
        item:SetInfo(product, row.blood == true)
        item:AddClick(function()
            if self.scroll_touch == true then
                return
            end
            if CASH_STORE_GOOD_IDS[product.id] then
                -- 代金券礼包由表格行点击购买，格子自身不再重复发请求。
                return
            else
                graphic:DispatchEvent("show_world_sub_panel", "store_msgbox",
                    client_constants.BATCH_MSGBOX_MODE.blood_store, row.goods_index)
            end
        end)
    end
end

return meta
