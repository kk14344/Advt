local panel_prototype = require "ui.panel"

local config_manager = require "logic.config_manager"
local graphic = require "logic.graphic"

local resource_logic = require "logic.resource"
local mining_logic = require "logic.mining"
local store_logic = require "logic.store"
local user_logic = require "logic.user"
local panel_util = require "ui.panel_util"
local reuse_scrollview = require "widget.reuse_scrollview"

local spine_manager = require "util.spine_manager"

local audio_manager = require "util.audio_manager"

local constants = require "util.constants"
local client_constants = require "util.client_constants"
local lang_constants = require "util.language_constants"
local platform_manager = require "logic.platform_manager"

local icon_tempalte = require "ui.icon_panel"


local PLIST_TYPE = ccui.TextureResType.plistType

local icon_template_with_text = require "ui.icon_panel"
local helper = require("util.helper")

local MAX_ROW, MAX_COL = 6, 6
local SUB_PANEL_HEIGHT = 88
local SHOP_PANEL_HEIGHT = 165
local FIRST_SUB_PANEL_OFFSET = -55


local item_sub_panel = panel_prototype.New()
item_sub_panel.__index = item_sub_panel

function item_sub_panel.New()
    return setmetatable({}, item_sub_panel)
end

function item_sub_panel:Init(root_node)
    self.root_node = root_node
    self.icon_img = root_node:getChildByName("item_icon")
    self.lock_icon = root_node:getChildByName("lock_icon")
    self.text_bg_img = root_node:getChildByName("text_bg")
    self.num_text = self.text_bg_img:getChildByName("num")
    self.text_bg_img:setVisible(false)

    self.root_node:setCascadeColorEnabled(false)
    self.root_node:setCascadeOpacityEnabled(true)
end

function item_sub_panel:Load(item_info)
    self.root_node:setVisible(true)
    self.root_node:setOpacity(255)
    self.lock_icon:setVisible(false)
    self.next_unlock = false

    local model_id = item_info.model_id
    local config = config_manager.treasure_map_config[model_id]

    self.item_id = item_info.id

    -- CCLOG("item_info = > ", item_info)
    -- CCLOG("config = > ", config)


    self.icon_img:loadTexture(CheckTextureCache(config.icon), PLIST_TYPE)
    self.root_node:loadTexture(CheckTextureCache(client_constants.MERCENARY_BG_SPRITE[config.map_quality]), PLIST_TYPE)
end

local ore_sub_panel = panel_prototype.New()
ore_sub_panel.__index = ore_sub_panel

function ore_sub_panel.New()
    return setmetatable({}, ore_sub_panel)
end

function ore_sub_panel:Init(root_node, class)
    self.root_node = root_node


    local item_explain_node = self.root_node:getChildByName("item_explain")
    self.item_explain_node = item_explain_node

    self.have_item_node = item_explain_node:getChildByName("have_item_node")
    self.empty_desc_node = item_explain_node:getChildByName("no_item_desc")

    self.bg_img = self.have_item_node:getChildByName("item_bg")
    self.icon_img = self.have_item_node:getChildByName("item_icon")
    self.name_text = self.have_item_node:getChildByName("item_name")
    self.icon_img:ignoreContentAdaptWithSize(true)
    self.use_btn = self.have_item_node:getChildByName("use_btn")

    local desc_list = self.have_item_node:getChildByName("desc_list")
    self.desc_txt = desc_list:getChildByName("desc")
    self.desc_limit_txt = desc_list:getChildByName("desc_0")



    self.bag_template = self.root_node:getChildByName("bag_template")
    self.bag_template:setVisible(false)


    local scroll_view = root_node:getChildByName("scroll_view")
    self.scroll_view = scroll_view


    self.select_spine = spine_manager:GetNode("item_skill_choose")
    self.scroll_view:addChild(self.select_spine, 100)
    self.select_spine:setVisible(false)
    self.select_spine:setAnimation(0, "animation", true)

    self.scroll_view:setVisible(true)


    self.duration = 0
    self.cur_capacity_row = 0
    self.item_sub_panels = {}

    self.item_offset, self.sub_panel_row = 0, 0

    self.cur_reward_index, self.reward_num, self.reward_info_list = 1, 0, {}
    self.cur_sub_panel_index = 1

    self.reuse_scrollview = reuse_scrollview.New(self, self.scroll_view, self.item_sub_panels, SUB_PANEL_HEIGHT)
    self.reuse_scrollview:RegisterMethod(function(self)
        return self.parent_panel.cur_capacity_row
    end, function(self, sub_panel, is_up)
        local offset = is_up and self.parent_panel.sub_panel_row or 1
        local pos_y = sub_panel.root_node:getPositionY()
        self.parent_panel:ShowSingleRowItem(self.data_offset + offset, sub_panel, pos_y)
    end)


    self.view_bag_content = function(widget, event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            local index = widget:getTag()

            local row = math.ceil(index / MAX_COL)
            local col = index - (row - 1) * MAX_COL
            local sub_panel = self.item_sub_panels[row][col]

            self.cur_itme_id = sub_panel.item_id
            if self.cur_itme_id == 0 then
                return
            end

            self:ShowDetailInfo(self.cur_itme_id)

            self.cur_sub_panel_index = index
            self:SetSelectBoxPosition()
        end
    end

    helper:AddClick(self.use_btn, function()
        local item = mining_logic.treasure_map_record[self.cur_itme_id]
        if item == nil then
            return
        end

        if mining_logic.current_treasure then
            local config = config_manager.treasure_map_config[mining_logic.current_treasure.model_id]

            -- 提示已经存在藏宝图，需要二次确认，是否替换
            graphic:DispatchEvent("show_simple_msgbox", lang_constants:Get("藏宝图替换提示"),
                lang_constants:GetFormattedStr("treasure_map_confrom_tips_desc", config.name),
                lang_constants:Get("common_confirm"), lang_constants:Get("common_cancel"), function()
                    mining_logic:ReqNewTreasureMap(self.cur_itme_id)
                end, function()
                end)
        else
            mining_logic:ReqNewTreasureMap(self.cur_itme_id)
        end
    end)

    -- [PC PORT] 使用/合成两个按钮上下排列，和参考图一致：用九宫格背景重建
    -- 两个扁长按钮（原 CSB 按钮接近正方形，直接叠两个会超出详情卡）。
    -- 标题使用原版黑字字体，不做压扁/缩放。
    do
        local pos = cc.p(self.use_btn:getPosition())
        local parent = self.use_btn:getParent()
        self.use_btn:setVisible(false)

        local gap = 8
        local button_w, button_h = 95, 48
        local offset = button_h * 0.5 + gap * 0.5

        local function make_button(title, y, handler)
            -- 3.4 的 ccui.Button 背景不吃 setContentSize（会保持原图大小），
            -- 这里用九宫格 ImageView + 文本做出参考图里的扁长按钮。
            local bg = ccui.ImageView:create("button/buttonbg_4.png", PLIST_TYPE)
            bg:setScale9Enabled(true)
            bg:setContentSize(cc.size(button_w, button_h))
            bg:setPosition(cc.p(pos.x, y))
            bg:setTouchEnabled(true)
            parent:addChild(bg)

            local label = ccui.Text:create(title, "fonts/general.ttf", 26)
            label:setColor(cc.c3b(0, 0, 0))
            label:setPosition(cc.p(button_w / 2, button_h / 2))
            bg:addChild(label)

            helper:AddClick(bg, handler)
            return bg
        end

        local function on_use_click()
            local item = mining_logic.treasure_map_record[self.cur_itme_id]
            if item == nil then
                return
            end
            if mining_logic.current_treasure then
                local config = config_manager.treasure_map_config[mining_logic.current_treasure.model_id]
                graphic:DispatchEvent("show_simple_msgbox", lang_constants:Get("藏宝图替换提示"),
                    lang_constants:GetFormattedStr("treasure_map_confrom_tips_desc", config.name),
                    lang_constants:Get("common_confirm"), lang_constants:Get("common_cancel"),
                    function()
                        mining_logic:ReqNewTreasureMap(self.cur_itme_id)
                    end, function()
                    end)
            else
                mining_logic:ReqNewTreasureMap(self.cur_itme_id)
            end
        end

        self.use_btn = make_button("使用", pos.y + offset, on_use_click)
        self.compose_btn = make_button("合成", pos.y - offset, function()
            if self.cur_itme_id then
                mining_logic:ReqComposeTreasureMap(self.cur_itme_id)
            end
        end)
    end
end

function ore_sub_panel:ShowDetailInfo(item_id)
    local item = mining_logic.treasure_map_record[item_id]
    if not item then
        self.have_item_node:setVisible(false)
        self.empty_desc_node:setVisible(true)
        return
    end

    self.have_item_node:setVisible(true)
    self.empty_desc_node:setVisible(false)

    local config = config_manager.treasure_map_config[item.model_id]

    self.icon_img:loadTexture(CheckTextureCache(config.icon), PLIST_TYPE)
    self.bg_img:loadTexture(CheckTextureCache(client_constants.MERCENARY_BG_SPRITE[config.map_quality]), PLIST_TYPE)

    self.name_text:setString(config.name)

    local strs = config.dec

    local effect_ids = item.effect_ids or {}
    for i = 1, #effect_ids do
        local effect_id = effect_ids[i]
        local effect_config = config_manager.treasure_map_effect_config[effect_id]
        strs = strs .. "\n" .. lang_constants:GetFormattedStr("treasure_map_effect_desc_" .. effect_config.effect,
            effect_config.effect_value)
    end


    self.desc_txt:setString(strs)

    self.cur_itme_id = item_id
end

function ore_sub_panel:SetSelectBoxPosition()
    local row = math.ceil(self.cur_sub_panel_index / MAX_COL)
    local col = self.cur_sub_panel_index - (row - 1) * MAX_COL

    local sub_panel = self.item_sub_panels[row][col]

    self.select_spine:setPosition(sub_panel.root_node:getPosition())
    self.select_spine:setVisible(true)
end

function ore_sub_panel:CreateSubPanels(row)
    local cur_row = math.min(MAX_ROW, row)
    if self.sub_panel_row >= cur_row then
        return
    end

    local begin_x, interval = 45, 88
    -- 绑定事件
    for row = self.sub_panel_row + 1, cur_row do
        self.item_sub_panels[row] = {}

        for col = 1, MAX_COL do
            local x = begin_x + (col - 1) * interval
            local tag = (row - 1) * MAX_COL + col

            local sub_panel = item_sub_panel.New()
            sub_panel:Init(self.bag_template:clone())
            sub_panel.root_node:setTag(tag)
            sub_panel.root_node:setPositionX(x)

            sub_panel.root_node:setTouchEnabled(true)
            sub_panel.root_node:addTouchEventListener(self.view_bag_content)
            self.scroll_view:addChild(sub_panel.root_node)

            self.item_sub_panels[row][col] = sub_panel
            sub_panel.root_node:setVisible(true)
        end

        self.item_sub_panels[row].root_node = self.item_sub_panels[row][1].root_node
    end

    self.sub_panel_row = cur_row
end

function ore_sub_panel:ShowSingleRowItem(item_row, sub_row_panel, pos_y)
    for col = 1, MAX_COL do
        local data_index = (item_row - 1) * MAX_COL + col
        local sub_panel = sub_row_panel[col]

        sub_panel.root_node:setVisible(true)

        if data_index <= self.item_num then
            local item = mining_logic.treasure_map_list[data_index]
            sub_panel:Load(item)
        else
            sub_panel:Hide()
        end

        if pos_y then
            sub_panel.root_node:setPositionY(pos_y)
        end
    end
end

function ore_sub_panel:Show()
    self.root_node:setVisible(true)

    self.item_num = #mining_logic.treasure_map_list
    self.cur_capacity_row = math.ceil(self.item_num / MAX_COL)


    self:CreateSubPanels(self.cur_capacity_row)

    self.height = math.max(self.cur_capacity_row * SUB_PANEL_HEIGHT, self.reuse_scrollview.sview_height)
    self.cur_sub_panel_index = 1

    local begin_x, interval = 53, 88
    local begin_y = self.height + FIRST_SUB_PANEL_OFFSET

    for row = 1, self.sub_panel_row do
        local y = begin_y - (row - 1) * interval
        self:ShowSingleRowItem(row, self.item_sub_panels[row], y)
    end


    self.reuse_scrollview:Show(self.height, 0)

    if self.item_num > 0 then
        if self.cur_sub_panel_index > self.item_num then
            self.cur_sub_panel_index = self.item_num
        end

        local row = math.ceil(self.cur_sub_panel_index / MAX_COL)
        local col = self.cur_sub_panel_index - (row - 1) * MAX_COL
        local sub_panel = self.item_sub_panels[row][col]
        self:ShowDetailInfo(sub_panel.item_id)

        self:SetSelectBoxPosition()
    else
        self:ShowDetailInfo(0)
        self.select_spine:setVisible(false)
    end
end

function ore_sub_panel:Hide()
    self.root_node:setVisible(false)
end

local goods_item_panel = panel_prototype.New()
goods_item_panel.__index = goods_item_panel

function goods_item_panel.New()
    return setmetatable({}, goods_item_panel)
end

function goods_item_panel:Init(root_node)
    self.root_node = root_node



    self.name_txt = self.root_node:getChildByName("name")
    self.desc_txt = self.root_node:getChildByName("desc")

    self.desc_limit_txt = self.root_node:getChildByName("desc_0")

    self.cost_num_txt = self.root_node:getChildByName("cost_num")
    self.cost_icon_img = self.root_node:getChildByName("cost_icon")

    self.buy_btn = self.root_node:getChildByName("buy_btn")
    local buy_btn_size = self.buy_btn:getContentSize()

    self.buy_btn:ignoreContentAdaptWithSize(true)
    self.buy_btn:setScale(0.9, 0.9)

    local icon = self.root_node:getChildByName("icon")
    if icon then
        icon:setVisible(false)
    end

    self.icon_panel = icon_tempalte.New(nil, 2)
    self.icon_panel:Init(root_node)
    self.icon_panel:SetPosition(73, 83)

    helper:AddClick(self.buy_btn, function()
        -- 购买
        if self.sold_out then
            return
        end
        mining_logic:ReqBuyTreasureMapShopItem(self.index)
    end)
end

function goods_item_panel:Show(data, index)
    self.root_node:setVisible(true)
    self.index = index

    self.data = data

    self:Refresh()
end

function goods_item_panel:Refresh()
    local data = mining_logic.current_treasure.shop_item_list[self.index]
    self.data = data
    local config = config_manager.treasure_map_shop_item_config[data.id]

    self.icon_panel:Show(config.item_type, config.item_id, config.item_num, nil, true)

    -- [MOD] 限购为 0 时不显示 "0/0"，改显示已兑换数量
    local limit_count = tonumber(config.limit_count) or 0
    local bought = tonumber(data.num) or 0
    if limit_count > 0 then
        self.name_txt:setString(self.icon_panel.conf.name .. "(" .. bought .. "/" .. limit_count .. ")")
    else
        self.name_txt:setString(self.icon_panel.conf.name .. "(已兑换 " .. bought .. ")")
    end
    self.desc_txt:setString(self.icon_panel.conf.desc)

    self.desc_limit_txt:setString("限购" .. config.limit_count .. "次")

    local cost = config.cost
    local value = mining_logic:GetTreasureEffectValue(mining_logic.current_treasure,
        constants.TREASURE_MAP_EFFECT.decrease_item_cost) -- 重置商店需要积分降低X%
    local cost_num = math.floor(cost * (100 - value) / 100)
    self.cost_num_txt:setString(cost_num)

    self.buy_btn:setContentSize(96, 22)

    -- Sold-out slots: gray out and disable the purchase button.
    local limit = tonumber(config.limit_count) or 0
    local bought = tonumber(data.num) or 0
    self.sold_out = limit > 0 and bought >= limit
    if self.buy_btn.setCascadeColorEnabled then
        self.buy_btn:setCascadeColorEnabled(true)
    end
    if self.buy_btn.setCascadeOpacityEnabled then
        self.buy_btn:setCascadeOpacityEnabled(true)
    end
    if self.buy_btn.setBright then
        self.buy_btn:setBright(not self.sold_out)
    end
    if self.buy_btn.setColor then
        self.buy_btn:setColor(self.sold_out and cc.c3b(110, 110, 110) or cc.c3b(255, 255, 255))
    end
    if self.buy_btn.setOpacity then
        self.buy_btn:setOpacity(self.sold_out and 160 or 255)
    end
    self.buy_btn:setTouchEnabled(not self.sold_out)
end

function goods_item_panel:Hide()
    self.root_node:setVisible(false)
end

local tool_sub_panel = panel_prototype.New()
tool_sub_panel.__index = tool_sub_panel

function tool_sub_panel.New()
    return setmetatable({}, tool_sub_panel)
end

function tool_sub_panel:Init(root_node, tool_type)
    self.root_node = root_node


    self.stop_btn = self.root_node:getChildByName("stop_btn")
    self.refresh_btn = self.root_node:getChildByName("refresh_btn")
    self.refresh_cost_txt = self.root_node:getChildByName("cost_num")
    self.refresh_cost_img = self.root_node:getChildByName("cost_icon")

    self.have_num_txt = self.root_node:getChildByName("have_num")
    self.have_num_img = self.root_node:getChildByName("have_icon")

    self.scroll_view = self.root_node:getChildByName("scroll_view")

    self.size_num = 0
    self.sub_panels = {}

    for i = 1, 4 do
        local template = self.scroll_view:getChildByName("template" .. i)
        template:setVisible(false)
        self.sub_panels[i] = goods_item_panel.New()
        self.sub_panels[i]:Init(template)
    end
    self.sub_panel_num = 4

    self.reuse_scrollview = reuse_scrollview.New(self, self.scroll_view, self.sub_panels, SHOP_PANEL_HEIGHT)

    self.reuse_scrollview:RegisterMethod(
        function(self)
            local list = mining_logic.current_treasure.shop_item_list
            return #list
        end,

        function(self, sub_panel, is_up)
            local index = is_up and self.data_offset + self.sub_panel_num or self.data_offset + 1
            local list = mining_logic.current_treasure.shop_item_list
            sub_panel:Show(list[index], index)
        end
    )

    helper:AddClick(self.stop_btn, function()
        -- 关闭探索
        mining_logic:ReqStopTreasureMap()
    end)

    helper:AddClick(self.refresh_btn, function()
        -- 刷新探索
        mining_logic:ReqRefreshTreasureMap()
    end)
end

function tool_sub_panel:Refresh()
    -- [MOD] 直接完整重建：重排格子、重设滚动高度、重读商品数据
    if _G["BOOT_TRACE"] then
        local ct = mining_logic.current_treasure
        _G["BOOT_TRACE"]("shop Refresh rebuild len=" ..
            tostring(ct and ct.shop_item_list and #ct.shop_item_list or -1))
    end
    self:Show(true)
end

function tool_sub_panel:RefreshUI()
    local current_treasure = mining_logic.current_treasure
    if current_treasure == nil then
        return
    end

    local config = config_manager.treasure_map_config[current_treasure.model_id]
    self.have_num_txt:setString(current_treasure.num)


    local free_count = mining_logic:GetTreasureEffectValue(current_treasure,
        constants.TREASURE_MAP_EFFECT.extra_free_refresh) -- 免费次数
    if current_treasure.refresh_count < free_count then
        self.refresh_cost_txt:setString("免费")
    else
        local shop_config = config_manager.treasure_map_shop_config[current_treasure.shop_id]
        -- CCLOG("current_treasure = > ", current_treasure, shop_config)

        local cost = mining_logic:GetTreasureEffectValue(current_treasure,
            constants.TREASURE_MAP_EFFECT.decrease_reset_shop_cost) -- 重置商店需要积分降低X%
        local cost_num = math.floor(shop_config.refresh * (100 - cost) / 100)
        self.refresh_cost_txt:setString(cost_num)
    end
end

function tool_sub_panel:Show(is_refresh)
    self.root_node:setVisible(true)

    local current_treasure = mining_logic.current_treasure
    if current_treasure == nil then
        return
    end

    self.size_num = #current_treasure.shop_item_list
    local height = math.max(self.size_num * SHOP_PANEL_HEIGHT, self.reuse_scrollview.sview_height)
    for i = 1, self.sub_panel_num do
        local sub_panel = self.sub_panels[i]

        sub_panel:Show(current_treasure.shop_item_list[i], i)

        local y = height + FIRST_SUB_PANEL_OFFSET - (i - 1) * SHOP_PANEL_HEIGHT
        sub_panel.root_node:setPositionY(y)
    end
    self.reuse_scrollview:Show(height + 100, 0)
    self:RefreshUI()
    if _G["BOOT_TRACE"] then
        local ids = {}
        for i = 1, math.min(#current_treasure.shop_item_list, 8) do
            ids[#ids + 1] = tostring(current_treasure.shop_item_list[i] and current_treasure.shop_item_list[i].id)
        end
        _G["BOOT_TRACE"]("shop render ids=" .. table.concat(ids, ","))
    end
end

function tool_sub_panel:Hide()
    self.root_node:setVisible(false)
end

local treasure_map_bag_panel = panel_prototype.New(true)

function treasure_map_bag_panel:Init()
    self.root_node = (require "util.helper"):Loader("ui/bag_treasure_map.csb")


    local o1 = ore_sub_panel.New()
    self.ore_node = o1
    o1:Init(self.root_node:getChildByName("ore_sub_panel"))

    local t1 = tool_sub_panel.New()
    self.tool_node = t1
    t1:Init(self.root_node:getChildByName("tool_sub_panel"))

    self.tool_tab = self.root_node:getChildByName("tool_tab")
    self.ore_tab = self.root_node:getChildByName("ore_tab")


    self.rule_icon = self.root_node:getChildByName("rule_icon")

    -- [MOD] 藏宝图背包底部居中边框放置「一键合成」按钮（原生 1A 统一金键，与背包「全部使用」同尺寸）
    do
        local pixel_kit = require "ui.pixel_kit"
        local sv = self.ore_node and self.ore_node.scroll_view
        local sv_box = sv and sv:getBoundingBox() or { x = 40, y = 240, width = 560, height = 400 }
        local btn_x = sv_box.x + sv_box.width * 0.5
        local btn_y = math.max(150, sv_box.y - 24)
        self.compose_all_btn = pixel_kit:CreateButton({
            style = "gold",
            title = "一键合成",
            font_size = 22,
            size = cc.size(184, 48),
            pos = cc.p(btn_x, btn_y),
            on_click = function()
                local preview = mining_logic:PreviewComposeAllTreasureMaps()
                if (preview.total_merges or 0) <= 0 then
                    graphic:DispatchEvent("show_prompt_panel", "treasure_map_compose_not_enough")
                    return
                end
                local names = { "普通", "中级", "高级", "珍品", "传奇" }
                local step_lines = {}
                for q = 1, 4 do
                    local m = preview.merges_by_q[q] or 0
                    if m > 0 then
                        step_lines[#step_lines + 1] = string.format("%s×%d → %s×%d", names[q], m * 3, names[q + 1], m)
                    end
                end
                local after_lines = {}
                for q = 5, 1, -1 do
                    if (preview.after[q] or 0) > 0 then
                        after_lines[#after_lines + 1] = string.format("%s×%d", names[q], preview.after[q])
                    end
                end
                local msg = string.format(
                    "将按「普通→中级→高级→珍品→传奇」顺序链式合成（共 %d 次，优先消耗词条少的图，绝不动挖掘中/传奇图）：\n%s\n\n合成后持有：%s",
                    preview.total_merges,
                    table.concat(step_lines, "；"),
                    table.concat(after_lines, "、")
                )
                graphic:DispatchEvent("show_simple_msgbox", "藏宝图一键合成", msg, "确认合成", "取消",
                    function()
                        mining_logic:ReqComposeAllTreasureMaps()
                    end, function()
                    end)
            end,
        })
        self.root_node:addChild(self.compose_all_btn, 102)
    end

    self:RegisterEvent()
    self:RegisterWidgetEvent()
end

function treasure_map_bag_panel:Show(sub_panel_type, jumpToBottom)
    self:ShowSubPanel(sub_panel_type or 1)


    self.root_node:setVisible(true)
end

function treasure_map_bag_panel:ShowSubPanel(sub_panel_type, is_refresh)
    self.cur_sub_panel = sub_panel_type or 1
    if _G["BOOT_TRACE"] then
        _G["BOOT_TRACE"]("ShowSubPanel type=" .. tostring(sub_panel_type) .. " refresh=" .. tostring(is_refresh))
    end

    if sub_panel_type == 2 and not mining_logic.current_treasure then
        graphic:DispatchEvent("show_prompt_panel", "treasure_map_progress")
        return
    end

    if sub_panel_type == 2 and mining_logic.current_treasure.value < 5 then
        graphic:DispatchEvent("show_prompt_panel", "treasure_shop_limit")
        return
    end

    if sub_panel_type == 2 then
        -- [MOD] 刷新必须走完整重建：Refresh 只重画已有格子，商品顺序/数量变化时不会重排
        self.tool_node:Show(is_refresh)
        self.ore_node:Hide()
        if self.compose_all_btn then
            self.compose_all_btn:setVisible(false)
        end

        self.tool_tab:setLocalZOrder(2)
        self.ore_tab:setLocalZOrder(1)

        self.tool_tab:setColor(panel_util:GetColor4B(0xffffff))
        self.ore_tab:setColor(panel_util:GetColor4B(0x7f7f7f))
    else
        self.tool_node:Hide()
        self.ore_node:Show()
        if self.compose_all_btn then
            self.compose_all_btn:setVisible(true)
        end

        self.tool_tab:setLocalZOrder(1)
        self.ore_tab:setLocalZOrder(2)

        self.tool_tab:setColor(panel_util:GetColor4B(0x7f7f7f))
        self.ore_tab:setColor(panel_util:GetColor4B(0xffffff))
    end
end

function treasure_map_bag_panel:RegisterWidgetEvent()
    self.ore_tab:addTouchEventListener(function(widget, event_type)
        print("ore_tab = > ", event_type)
        if event_type == ccui.TouchEventType.ended then
            audio_manager:PlayEffect("click")
            self:ShowSubPanel(1)
        end
    end)

    self.tool_tab:addTouchEventListener(function(widget, event_type)
        print("tool_tab = > ", event_type)
        if event_type == ccui.TouchEventType.ended then
            self:ShowSubPanel(2)
            audio_manager:PlayEffect("click")
        end
    end)

    helper:AddClick(self.rule_icon, function()
        -- graphic:DispatchEvent("show_prompt_panel", "treasure_map_rule")
        print("rule_icon = > ")
        graphic:DispatchEvent("show_world_sub_panel", "treasure_rule_panel")
    end)


    panel_util:RegisterCloseMsgbox(self.root_node:getChildByName("close_btn"), self:GetName())
end

function treasure_map_bag_panel:RegisterEvent()
    graphic:RegisterEvent("treasure_map_refresh", function(item_id)
        self:ShowSubPanel(1)
    end)

    graphic:RegisterEvent("treasure_map_stop", function()
    end)

    graphic:RegisterEvent("treasure_shop_refresh", function(shop_item_list)
        if _G["BOOT_TRACE"] then
            _G["BOOT_TRACE"]("shop refresh len=" .. tostring(shop_item_list and #shop_item_list or -1))
        end
        self:ShowSubPanel(2, true)
        -- [MOD] 兜底：逐个刷新商品格子（数据已更新，强制重画）
        pcall(function()
            local node = self.tool_node
            if node and node.sub_panels then
                for i = 1, #node.sub_panels do
                    node.sub_panels[i]:Refresh()
                end
            end
            if node then
                node:RefreshUI()
            end
        end)
    end)

    -- [PC PORT] 合成后服务端会重新下发藏宝图列表，打开中的藏宝阁需刷新背包页。
    graphic:RegisterEvent("treasure_map_list_updated", function()
        if self.root_node:isVisible() then
            -- [MOD] 保持当前页签（原来固定回页签 1，导致商店刷新后跳走/不更新）
            self:ShowSubPanel(self.cur_sub_panel or 1)
        end
    end)
end

return treasure_map_bag_panel
