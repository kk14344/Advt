-- 代金券「心愿祈愿池」1A 原生像素风格弹窗
-- 支持 3 档祈愿池（闪金心愿 500 / 彩虹心愿 2000 / 升星材料 5000），保底 100% 必得自选目标；
-- 消耗 resource 106（代金券）并自动联动「豪华累消」，数据持久化在 wish_save.json。
local network = require "util.network"
local graphic = require "logic.graphic"
local config_manager = require "logic.config_manager"
local resource_logic = require "logic.resource"
local constants = require "util.constants"
local client_constants = require "util.client_constants"
local json = require "util.json"
local pixel_kit = require "ui.pixel_kit"
local panel_util = require "ui.panel_util"

local FONT = client_constants["FONT_FACE"]
local PLIST_TYPE = ccui.TextureResType.plistType
local RES_VOUCHER = constants.RESOURCE_TYPE["cash_tickets"] or 106
local RES_RAINBOW = constants.RESOURCE_TYPE["rainbow_soul_chip"] or 102
local RES_STAR = constants.RESOURCE_TYPE["hight_rainbow_soul_chip"] or 108

local POOLS = {
    [1] = { id = 1, name = "闪金心愿", cost1 = 500, cost10 = 4500, pityMax = 10, targetQ = 6,
            sub = "保底10抽必出心愿闪金 · 副产灵魂碎片/闪金碎片/契约石" },
    [2] = { id = 2, name = "彩虹心愿", cost1 = 2000, cost10 = 18000, pityMax = 20, targetQ = 21,
            sub = "保底20抽必出心愿0★彩虹 · 副产彩虹碎片/升星石/崇高契约石" },
    [3] = { id = 3, name = "升星材料", cost1 = 5000, cost10 = 45000, pityMax = 10, targetQ = 0,
            sub = "保底10抽必出【升星石x50 + 彩虹碎片x2500】大奖！" },
}

local wish_pool_dialog = {
    dlg = nil,
    picker_dlg = nil,
    registered = false,
    cur_pool = 1,
    state = { t1 = 19000348, t2 = 19000325, p1 = 0, p2 = 0, p3 = 0, total = 0, spent = 0 },
    busy = false,
}

function wish_pool_dialog:EnsureEvent()
    if self.registered then
        return
    end
    self.registered = true
    graphic:RegisterEvent("wish_sync_ret", function(raw_str)
        self:OnWishSync(raw_str)
    end)
    graphic:RegisterEvent("update_resource_list", function()
        self:RefreshView()
    end)
end

function wish_pool_dialog:GetEligibleTargets(pool_id)
    local target_q = POOLS[pool_id] and POOLS[pool_id].targetQ or 0
    if target_q <= 0 then
        return {}
    end
    local out = {}
    for id, conf in pairs(config_manager.mercenary_config) do
        local init_bp = tonumber(conf.init_bp) or 0
        if type(id) == "number" and id > 0 and id < 90000000 and tonumber(conf.quality) == target_q
            and init_bp > 0 and init_bp < 100000
            and conf.name and conf.name ~= "" and conf.name ~= "主角" then
            table.insert(out, conf)
        end
    end
    table.sort(out, function(a, b) return (a.ID or 0) > (b.ID or 0) end)
    return out
end

function wish_pool_dialog:OnWishSync(raw_str)
    self.busy = false
    local ok, data = pcall(json.decode, json, tostring(raw_str or ""))
    if not ok or type(data) ~= "table" then
        return
    end
    self.state = {
        t1 = tonumber(data.t1) or self.state.t1,
        t2 = tonumber(data.t2) or self.state.t2,
        p1 = tonumber(data.p1) or 0,
        p2 = tonumber(data.p2) or 0,
        p3 = tonumber(data.p3) or 0,
        total = tonumber(data.total) or 0,
        spent = tonumber(data.spent) or 0,
    }
    if self.pending_target_switch then
        local req = self.pending_target_switch
        self.pending_target_switch = nil
        local active_tid = (req.pool_id == 1) and self.state.t1 or self.state.t2
        if active_tid == req.tid then
            pixel_kit:ShowToast("心愿目标已切换为：" .. tostring(req.name), 0xa1e01b)
        else
            pixel_kit:ShowToast("该佣兵暂不可设为心愿目标", 0xf87f26)
        end
    end
    if type(data.last) == "table" then
        local last = data.last
        local cost = tonumber(last.cost) or 0
        if cost > 0 then
            -- 本地扣除代金券（resource.lua 会自动通过 -106 上报豪华累消）
            resource_logic:UpdateResource(RES_VOUCHER, -cost)
            graphic:DispatchEvent("update_resource_list")
            resource_logic:ClearDirtyFlags()
        end
        local parts = {}
        local hits = tonumber(last.hits) or 0
        local jackpots = tonumber(last.jackpots) or 0
        if hits > 0 and last.targetId then
            local mc = config_manager.mercenary_config[tonumber(last.targetId)]
            parts[#parts + 1] = string.format("★心愿命中：%s x%d", mc and mc.name or tostring(last.targetId), hits)
        end
        if jackpots > 0 then
            parts[#parts + 1] = string.format("★升星大奖 x%d", jackpots)
        end
        if type(last.res) == "table" then
            for _, r in ipairs(last.res) do
                local rc = config_manager.resource_config[tonumber(r.id)]
                parts[#parts + 1] = string.format("%s x%d", rc and rc.name or ("资源" .. tostring(r.id)), tonumber(r.num) or 0)
            end
        end
        local summary_txt = "祈愿收获：" .. table.concat(parts, "、")
        if self.result_lbl and not tolua.isnull(self.result_lbl) then
            self.result_lbl:setString(summary_txt)
        end
        pixel_kit:ShowToast(hits > 0 and ("心愿达成！" .. parts[1]) or summary_txt, hits > 0 and 0xf5d31f or 0xa1e01b)
    end
    self:RefreshView()
end

function wish_pool_dialog:RequestDraw(count)
    if self.busy then
        return
    end
    local p = POOLS[self.cur_pool]
    local cost = (count == 10) and p.cost10 or p.cost1
    local owned = resource_logic:GetResourceNum(RES_VOUCHER) or 0
    if owned < cost then
        pixel_kit:ShowToast(string.format("代金券不足！需要 %d，当前仅有 %d", cost, owned), 0xf87f26)
        return
    end
    self.busy = true
    network:Send({
        use_item = {
            item_id = self.cur_pool * 100 + count,
            golem_lv = -203,
        }
    })
end

function wish_pool_dialog:OpenTargetPicker()
    if not self.dlg or tolua.isnull(self.dlg.overlay) then
        return
    end
    local pool_id = self.cur_pool
    if pool_id ~= 1 and pool_id ~= 2 then
        return
    end
    if self.picker_dlg and not tolua.isnull(self.picker_dlg.overlay) then
        self.picker_dlg.Close()
    end

    local all_targets = self:GetEligibleTargets(pool_id)
    local picker = pixel_kit:CreateDialog(self.dlg.overlay, {
        title = pool_id == 1 and "选择闪金心愿佣兵" or "选择 0★ 彩虹心愿佣兵",
        width = 560,
        height = 760,
        pos_y = 576,
        z_order = 280,
        on_close = function()
            self.picker_dlg = nil
        end,
    })
    self.picker_dlg = picker

    local inner = picker.inner
    local iw = picker.inner_w
    local top_y = picker.content_top

    -- 搜索框
    local sbg = ccui.Layout:create()
    sbg:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
    sbg:setBackGroundColor(cc.c3b(44, 32, 22))
    sbg:setBackGroundColorOpacity(235)
    sbg:setContentSize(cc.size(iw - 140, 40))
    sbg:setAnchorPoint(0, 0.5)
    sbg:setPosition(14, top_y - 24)
    inner:addChild(sbg)

    local search_tf = ccui.TextField:create("输入佣兵名关键词筛选…", FONT, 18)
    search_tf:setAnchorPoint(0.5, 0.5)
    search_tf:setPosition((iw - 140) * 0.5, 20)
    search_tf:setTextColor(cc.c4b(255, 246, 215, 255))
    search_tf:setPlaceHolderColor(cc.c4b(150, 138, 118, 255))
    search_tf:ignoreContentAdaptWithSize(false)
    search_tf:setContentSize(cc.size(iw - 156, 32))
    sbg:addChild(search_tf)

    local sv_w = iw - 12
    local sv = ccui.ScrollView:create()
    sv:setDirection(ccui.ScrollViewDir.vertical)
    sv:setBounceEnabled(true)
    sv:setContentSize(cc.size(sv_w, top_y - 110))
    sv:setPosition(6, 56)
    inner:addChild(sv)

    local function rebuild(kw)
        sv:removeAllChildren()
        kw = tostring(kw or ""):gsub("^%s+", ""):gsub("%s+$", "")
        local list = {}
        for _, c in ipairs(all_targets) do
            if kw == "" or string.find(tostring(c.name or ""), kw, 1, true) then
                list[#list + 1] = c
            end
        end
        local cols = 4
        local gap = 6
        local cell_w = math.floor((sv_w - 14 - (cols - 1) * gap) / cols)
        local cell_h = 118
        local rows = math.max(1, math.ceil(#list / cols))
        local inner_h = math.max(sv:getContentSize().height, rows * cell_h + 12)
        sv:setInnerContainerSize(cc.size(sv_w, inner_h))
        local cur_tid = (pool_id == 1) and self.state.t1 or self.state.t2
        local start_x = math.floor((sv_w - (cols * cell_w + (cols - 1) * gap)) * 0.5)
        for idx, c in ipairs(list) do
            local r = math.floor((idx - 1) / cols)
            local col = (idx - 1) % cols
            local cx = start_x + col * (cell_w + gap) + cell_w * 0.5
            local cy = inner_h - 8 - r * cell_h - cell_h * 0.5
            local is_cur = (c.ID == cur_tid)
            local item = ccui.Layout:create()
            item:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
            item:setBackGroundColor(is_cur and cc.c3b(122, 92, 32) or cc.c3b(58, 44, 30))
            item:setBackGroundColorOpacity(235)
            item:setContentSize(cc.size(cell_w, cell_h - 8))
            item:setAnchorPoint(0.5, 0.5)
            item:setPosition(cx, cy)
            item:setTouchEnabled(true)
            item:addTouchEventListener(function(_, et)
                if et == ccui.TouchEventType.ended then
                    local sentinel = (pool_id == 1) and -202 or -204
                    self.pending_target_switch = { pool_id = pool_id, tid = c.ID, name = c.name }
                    network:Send({ use_item = { item_id = c.ID, golem_lv = sentinel } })
                    picker.Close()
                end
            end)
            sv:addChild(item)

            local sp_frame = CheckTextureCache(client_constants["MERCENARY_ROLE_IMG_PATH"] .. tostring(c.sprite) .. ".png")
            local icon = ccui.ImageView:create()
            pcall(function() icon:loadTexture(sp_frame, PLIST_TYPE) end)
            icon:setPosition(cell_w * 0.5, 68)
            icon:setScale(1.35)
            item:addChild(icon)

            local nm = ccui.Text:create(tostring(c.name or c.ID), FONT, 15)
            nm:setPosition(cell_w * 0.5, 22)
            nm:setColor(is_cur and cc.c3b(255, 232, 110) or cc.c3b(245, 236, 212))
            item:addChild(nm)
        end
        sv:jumpToTop()
    end

    inner:addChild(pixel_kit:CreateButton({
        style = "gold",
        title = "筛 选",
        font_size = 17,
        size = cc.size(104, 40),
        pos = cc.p(iw - 66, top_y - 24),
        on_click = function()
            rebuild(search_tf:getString())
        end,
    }))

    inner:addChild(pixel_kit:CreateButton({
        style = "grey",
        title = "返 回",
        font_size = 18,
        size = cc.size(150, 42),
        pos = cc.p(iw * 0.5, 26),
        on_click = function() picker.Close() end,
    }))

    rebuild("")
end

function wish_pool_dialog:RefreshView()
    if not self.dlg or tolua.isnull(self.dlg.overlay) or not self.pity_lbl or tolua.isnull(self.pity_lbl) then
        return
    end
    local p = POOLS[self.cur_pool]
    local voucher = resource_logic:GetResourceNum(RES_VOUCHER) or 0
    local rb_chip = resource_logic:GetResourceNum(RES_RAINBOW) or 0
    local star_st = resource_logic:GetResourceNum(RES_STAR) or 0
    self.wallet_lbl:setString(string.format("代金券：%d   |   彩虹碎片：%d   |   升星石：%d", voucher, rb_chip, star_st))

    for i = 1, 3 do
        pixel_kit:ApplyButtonStyle(self.tab_btns[i], i == self.cur_pool and "gold" or "grey")
    end

    local pity = (self.cur_pool == 1 and self.state.p1) or (self.cur_pool == 2 and self.state.p2) or self.state.p3
    self.pity_lbl:setString(string.format("当前心愿值：%d / %d（满值必出保底，消耗同步计入豪华累消）", pity, p.pityMax))
    self.pity_fill:setContentSize(cc.size(math.max(4, math.floor((self.pity_bar_w - 4) * math.min(1, pity / p.pityMax))), 18))
    self.sub_lbl:setString(p.sub)

    if self.cur_pool == 1 or self.cur_pool == 2 then
        local tid = (self.cur_pool == 1) and self.state.t1 or self.state.t2
        local conf = config_manager.mercenary_config[tid]
        self.change_btn:setVisible(true)
        if conf then
            local frame = CheckTextureCache(client_constants["MERCENARY_ROLE_IMG_PATH"] .. tostring(conf.sprite) .. ".png")
            pcall(function() self.target_icon:loadTexture(frame, PLIST_TYPE) end)
            self.target_icon:setScale(2.4)
            self.target_name:setString(string.format("心愿目标：%s", tostring(conf.name)))
            local qcol = client_constants["TEXT_QUALITY_COLOR"][conf.quality] or 0xf5d31f
            self.target_name:setColor(panel_util:GetColor4B(qcol))
            self.target_tip:setString(self.cur_pool == 1 and "单抽 12% 概率提前命中 · 满 10 抽 100% 必出" or "单抽 8% 概率提前命中 · 满 20 抽 100% 必出")
        end
    else
        self.change_btn:setVisible(false)
        local rconf = config_manager.resource_config[RES_STAR]
        if rconf then
            pcall(function() self.target_icon:loadTexture(CheckTextureCache(rconf.icon), PLIST_TYPE) end)
            self.target_icon:setScale(1.6)
        end
        self.target_name:setString("终极升星大奖：升星石 x50 + 彩虹碎片 x2500")
        self.target_name:setColor(cc.c3b(255, 224, 96))
        self.target_tip:setString("单抽保底 升星石x10 + 彩虹碎片x500 + 崇高契约石x4 · 满10抽必出大奖")
    end

    self.btn_draw1:setTitleText(string.format("祈愿 1 次 (%d)", p.cost1))
    self.btn_draw10:setTitleText(string.format("十连 9折 (%d)", p.cost10))
end

function wish_pool_dialog:Show(parent)
    if not parent or tolua.isnull(parent) then
        return
    end
    self:EnsureEvent()
    if self.dlg and not tolua.isnull(self.dlg.overlay) then
        self.dlg.Close()
    end

    local dlg = pixel_kit:CreateDialog(parent, {
        title = "心愿祈愿池 · 代金券专享",
        width = 584,
        height = 804,
        pos_y = 576,
        z_order = 250,
        on_close = function()
            self.dlg = nil
        end,
    })
    self.dlg = dlg

    local inner = dlg.inner
    local iw = dlg.inner_w
    local top_y = dlg.content_top

    -- 顶部钱包栏
    local wallet_bg = ccui.Layout:create()
    wallet_bg:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
    wallet_bg:setBackGroundColor(cc.c3b(32, 24, 17))
    wallet_bg:setBackGroundColorOpacity(220)
    wallet_bg:setContentSize(cc.size(iw - 20, 36))
    wallet_bg:setAnchorPoint(0.5, 0.5)
    wallet_bg:setPosition(iw * 0.5, top_y - 20)
    inner:addChild(wallet_bg)

    self.wallet_lbl = ccui.Text:create("", FONT, 16)
    self.wallet_lbl:setPosition((iw - 20) * 0.5, 18)
    self.wallet_lbl:setColor(cc.c3b(255, 224, 128))
    wallet_bg:addChild(self.wallet_lbl)

    -- 3 档池切换
    self.tab_btns = {}
    local tw = 166
    local tgap = 10
    local tx0 = iw * 0.5 - (3 * tw + 2 * tgap) * 0.5 + tw * 0.5
    for i = 1, 3 do
        local btn = pixel_kit:CreateButton({
            style = i == self.cur_pool and "gold" or "grey",
            title = string.format("%s (%d)", POOLS[i].name, POOLS[i].cost1),
            font_size = 16,
            size = cc.size(tw, 42),
            pos = cc.p(tx0 + (i - 1) * (tw + tgap), top_y - 68),
            on_click = function()
                self.cur_pool = i
                self:RefreshView()
            end,
        })
        inner:addChild(btn)
        self.tab_btns[i] = btn
    end

    -- 中央羊皮纸展示卡
    local cw = iw - 24
    local card = pixel_kit:CreatePaperCard(inner, {
        width = cw,
        height = 340,
        pos = cc.p(iw * 0.5, top_y - 270),
    })

    local icon_bg = ccui.Layout:create()
    icon_bg:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
    icon_bg:setBackGroundColor(cc.c3b(44, 32, 22))
    icon_bg:setBackGroundColorOpacity(235)
    icon_bg:setContentSize(cc.size(136, 136))
    icon_bg:setAnchorPoint(0.5, 0.5)
    icon_bg:setPosition(cw * 0.5, 246)
    card:addChild(icon_bg)

    self.target_icon = ccui.ImageView:create()
    self.target_icon:setPosition(68, 68)
    icon_bg:addChild(self.target_icon)

    self.change_btn = pixel_kit:CreateButton({
        style = "gold",
        title = "更换心愿",
        font_size = 16,
        size = cc.size(116, 38),
        pos = cc.p(cw - 76, 286),
        on_click = function()
            self:OpenTargetPicker()
        end,
    })
    card:addChild(self.change_btn)

    self.target_name = ccui.Text:create("", FONT, 22)
    self.target_name:setPosition(cw * 0.5, 148)
    panel_util:SetTextOutline(self.target_name)
    card:addChild(self.target_name)

    self.target_tip = ccui.Text:create("", FONT, 16)
    self.target_tip:setPosition(cw * 0.5, 114)
    self.target_tip:setColor(cc.c3b(90, 56, 22))
    card:addChild(self.target_tip)

    -- 心愿保底进度条
    self.pity_bar_w = cw - 52
    local bar_bg = ccui.Layout:create()
    bar_bg:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
    bar_bg:setBackGroundColor(cc.c3b(42, 30, 20))
    bar_bg:setBackGroundColorOpacity(240)
    bar_bg:setContentSize(cc.size(self.pity_bar_w, 22))
    bar_bg:setAnchorPoint(0.5, 0.5)
    bar_bg:setPosition(cw * 0.5, 84)
    card:addChild(bar_bg)

    self.pity_fill = ccui.Layout:create()
    self.pity_fill:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
    self.pity_fill:setBackGroundColor(cc.c3b(232, 180, 48))
    self.pity_fill:setBackGroundColorOpacity(255)
    self.pity_fill:setContentSize(cc.size(4, 18))
    self.pity_fill:setPosition(2, 2)
    bar_bg:addChild(self.pity_fill)

    self.pity_lbl = ccui.Text:create("", FONT, 15)
    self.pity_lbl:setPosition(cw * 0.5, 54)
    self.pity_lbl:setColor(cc.c3b(72, 46, 20))
    card:addChild(self.pity_lbl)

    self.sub_lbl = ccui.Text:create("", FONT, 14)
    self.sub_lbl:setPosition(cw * 0.5, 28)
    self.sub_lbl:setColor(cc.c3b(115, 78, 36))
    card:addChild(self.sub_lbl)

    -- 最近一次收获提示框
    local res_bg = ccui.Layout:create()
    res_bg:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
    res_bg:setBackGroundColor(cc.c3b(32, 24, 17))
    res_bg:setBackGroundColorOpacity(215)
    res_bg:setContentSize(cc.size(iw - 24, 86))
    res_bg:setAnchorPoint(0.5, 0.5)
    res_bg:setPosition(iw * 0.5, top_y - 504)
    inner:addChild(res_bg)

    self.result_lbl = ccui.Text:create("选择心愿目标后点击下方按钮消耗代金券祈愿，十连享 9 折优惠！", FONT, 16)
    self.result_lbl:setPosition((iw - 24) * 0.5, 43)
    self.result_lbl:setColor(cc.c3b(235, 224, 196))
    self.result_lbl:ignoreContentAdaptWithSize(false)
    self.result_lbl:setContentSize(cc.size(iw - 52, 72))
    self.result_lbl:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    self.result_lbl:setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_CENTER)
    res_bg:addChild(self.result_lbl)

    -- 祈愿按钮区
    self.btn_draw1 = pixel_kit:CreateButton({
        style = "gold",
        title = "祈愿 1 次",
        font_size = 19,
        size = cc.size(240, 52),
        pos = cc.p(iw * 0.5 - 130, 96),
        on_click = function() self:RequestDraw(1) end,
    })
    inner:addChild(self.btn_draw1)

    self.btn_draw10 = pixel_kit:CreateButton({
        style = "green",
        title = "十连 9折",
        font_size = 19,
        size = cc.size(240, 52),
        pos = cc.p(iw * 0.5 + 130, 96),
        on_click = function() self:RequestDraw(10) end,
    })
    inner:addChild(self.btn_draw10)

    inner:addChild(pixel_kit:CreateButton({
        style = "grey",
        title = "返 回",
        font_size = 18,
        size = cc.size(160, 42),
        pos = cc.p(iw * 0.5, 32),
        on_click = function() dlg.Close() end,
    }))

    self:RefreshView()
    network:Send({ use_item = { item_id = 1, golem_lv = -201 } })
end

return wish_pool_dialog
