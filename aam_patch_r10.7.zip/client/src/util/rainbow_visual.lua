-- 彩虹佣兵视觉升级模块（方案 3 · 皇家鎏金虹纹 + 星样 3 · 银金星冠托座）
-- 特性：
--   1. 彻底移除原版脚底蓝环（colorful_hero_general.csb）
--   2. 统一保留 0★(bg20单角花) / ★(bg21四角花) / ★★(bg21四角花+原生桂冠) 原生银白八角框
--   3. GLES 2.0 宝石虹流转着色器（含错相缓流 + 75% 网格克制亮度防花眼 + 安全降级）
--   4. 顶部居中 14~16px 银金星冠托座（仅上探 4px，适配 12px 真实行缝零穿模）
--   5. 详情大舞台改用干净脚底投影 + 旋转太阳花虹光 + ★★ 鎏金像素桂冠双环与微尘
local shader_manager = require "util.shader_manager"

local rainbow_visual = {}

local ASSET_DIR = "res/ui/rainbow_v3/"
local ADDITIVE_BLEND = {
    src = (gl and gl.SRC_ALPHA) or 0x0302,
    dst = (gl and gl.ONE) or 1,
}

local function safe_alias(sprite)
    if not sprite then return end
    pcall(function()
        local tex = sprite:getTexture()
        if tex and tex.setAliasTexParameters then
            tex:setAliasTexParameters()
        end
    end)
end

local function create_pixel_sprite(filename)
    local path = ASSET_DIR .. filename
    local ok, sp = pcall(cc.Sprite.create, cc.Sprite, path)
    if ok and sp then
        safe_alias(sp)
        return sp
    end
    return nil
end

function rainbow_visual:GetTier(quality)
    local q = tonumber(quality) or 0
    if q < 21 then
        return 0, 0
    elseif q >= 31 then
        return 3, math.min(3, q - 29)
    elseif q == 30 then
        return 2, 1
    else
        return 1, 0
    end
end

function rainbow_visual:_ApplyCardShader(sprite, tier, phase, intensity)
    if not sprite then return end
    pcall(function()
        local prog = shader_manager:GetProgram("rainbow_card")
        if not prog then return end
        if cc.GLProgramState and cc.GLProgramState.create then
            local state = sprite._rb_gl_state
            if not state or tolua.isnull(state) then
                state = cc.GLProgramState:create(prog)
                sprite:setGLProgramState(state)
                sprite._rb_gl_state = state
            end
            state:setUniformFloat("u_phase", phase or 0.0)
            state:setUniformFloat("u_tier", tonumber(tier) or 1.0)
            state:setUniformFloat("u_intensity", tonumber(intensity) or 0.75)
        end
    end)
end

-- 沿 112x112 原生八角切角边框巡游（Cocos2d-x Y-up 坐标）
local CHAMFER_VERTS = {
    { 13, 107 }, { 99, 107 }, { 107, 99 }, { 107, 13 },
    { 99, 5 },   { 13, 5 },   { 5, 13 },   { 5, 99 },
}

local function run_chamfer_glider(dot, start_idx, speed_sec)
    if not dot then return end
    dot:stopAllActions()
    local p0 = CHAMFER_VERTS[start_idx]
    dot:setPosition(p0[1], p0[2])
    local actions = {}
    local n = #CHAMFER_VERTS
    for step = 1, n do
        local idx = ((start_idx - 1 + step) % n) + 1
        local prev = CHAMFER_VERTS[((start_idx - 2 + step) % n) + 1]
        local cur = CHAMFER_VERTS[idx]
        local dist = math.sqrt((cur[1] - prev[1]) ^ 2 + (cur[2] - prev[2]) ^ 2)
        local dur = math.max(0.05, (dist / 390.0) * speed_sec)
        table.insert(actions, cc.MoveTo:create(dur, cc.p(cur[1], cur[2])))
    end
    dot:runAction(cc.RepeatForever:create(cc.Sequence:create(actions)))
end

function rainbow_visual:_EnsureCardNodes(root_node)
    if root_node._rb_nodes and not tolua.isnull(root_node._rb_nodes.face) then
        return root_node._rb_nodes
    end

    local sz = root_node:getContentSize()
    local cw = (sz and sz.width > 10) and sz.width or 112
    local ch = (sz and sz.height > 10) and sz.height or 112
    local sx, sy = cw / 112.0, ch / 112.0

    local nodes = { cw = cw, ch = ch, sx = sx, sy = sy }

    -- z=1: 独立 112x112 宝石虹卡面（保证 UV 为严格 [0,1]，银白外框原样保留）
    local face = create_pixel_sprite("rb_bg_0.png")
    if face then
        face:setPosition(cw * 0.5, ch * 0.5)
        face:setScale(sx, sy)
        face:setVisible(false)
        root_node:addChild(face, 1)
        nodes.face = face
    end

    -- z=2: 中心缓慢旋转金辉日轮（★/★★ 激活）
    local sun = create_pixel_sprite("rb_sunburst.png")
    if sun then
        sun:setPosition(cw * 0.5, ch * 0.52)
        sun:setScale(sx * 0.92, sy * 0.92)
        pcall(function() sun:setBlendFunc(ADDITIVE_BLEND) end)
        sun:setVisible(false)
        root_node:addChild(sun, 2)
        nodes.sun = sun
    end

    -- z=9: 前景克制装饰容器（四角宝石微闪 + ★★ 八边双流光点）
    local fx_layer = cc.Node:create()
    fx_layer:setScale(sx, sy)
    fx_layer:setVisible(false)
    root_node:addChild(fx_layer, 9)
    nodes.fx_layer = fx_layer

    local corner_pts = { { 12, 100 }, { 100, 100 }, { 12, 12 }, { 100, 12 } }
    nodes.corners = {}
    for i, pt in ipairs(corner_pts) do
        local c = create_pixel_sprite("rb_dot.png")
        if c then
            c:setPosition(pt[1], pt[2])
            c:setScale(1.25)
            pcall(function() c:setBlendFunc(ADDITIVE_BLEND) end)
            fx_layer:addChild(c, 1)
            nodes.corners[i] = c
        end
    end

    nodes.gliders = {}
    for g = 1, 2 do
        local gd = create_pixel_sprite("rb_glint.png")
        if gd then
            gd:setScale(0.55)
            gd:setColor(g == 1 and cc.c3b(255, 226, 125) or cc.c3b(242, 166, 212))
            pcall(function() gd:setBlendFunc(ADDITIVE_BLEND) end)
            gd:setVisible(false)
            fx_layer:addChild(gd, 2)
            nodes.gliders[g] = gd
        end
    end

    -- z=13: 顶中银金星冠托座（星样 3，14~16px 紧凑版，仅上探 4px 完美适配 12px 行缝）
    local crown = create_pixel_sprite("rb_crown_1.png")
    if crown then
        crown:setAnchorPoint(0.5, 0.5)
        -- 48x18 中心置 y = ch - 5*sy -> 顶沿 = ch + 4*sy（严格仅上探 4px）
        crown:setPosition(cw * 0.5, ch - 5 * sy)
        crown:setScale(sx, sy)
        crown:setVisible(false)
        root_node:addChild(crown, 13)
        nodes.crown = crown

        local glint = create_pixel_sprite("rb_glint.png")
        if glint then
            glint:setScale(0.65)
            pcall(function() glint:setBlendFunc(ADDITIVE_BLEND) end)
            glint:setVisible(false)
            crown:addChild(glint, 2)
            nodes.crown_glint = glint
        end
    end

    root_node._rb_nodes = nodes
    return nodes
end

function rainbow_visual:_ResetRoleBob(role_img)
    if not role_img or tolua.isnull(role_img) then return end
    if role_img._rb_bobbing then
        role_img:stopActionByTag(9301)
        if role_img._rb_base_y then
            role_img:setPositionY(role_img._rb_base_y)
        end
        role_img._rb_bobbing = false
    end
end

function rainbow_visual:ClearCard(root_node, opts)
    opts = opts or {}
    if opts.role_img then
        self:_ResetRoleBob(opts.role_img)
    end
    if not root_node or tolua.isnull(root_node) then return end
    local nodes = root_node._rb_nodes
    if not nodes then return end
    if nodes.face and not tolua.isnull(nodes.face) then
        nodes.face:setVisible(false)
    end
    if nodes.sun and not tolua.isnull(nodes.sun) then
        nodes.sun:stopAllActions()
        nodes.sun:setVisible(false)
    end
    if nodes.fx_layer and not tolua.isnull(nodes.fx_layer) then
        nodes.fx_layer:setVisible(false)
        for _, c in ipairs(nodes.corners or {}) do
            if c and not tolua.isnull(c) then c:stopAllActions() end
        end
        for _, g in ipairs(nodes.gliders or {}) do
            if g and not tolua.isnull(g) then
                g:stopAllActions()
                g:setVisible(false)
            end
        end
    end
    if nodes.crown and not tolua.isnull(nodes.crown) then
        nodes.crown:setVisible(false)
        if nodes.crown_glint and not tolua.isnull(nodes.crown_glint) then
            nodes.crown_glint:stopAllActions()
            nodes.crown_glint:setVisible(false)
        end
    end
end

function rainbow_visual:ApplyToCard(root_node, quality, opts)
    opts = opts or {}
    if not root_node or tolua.isnull(root_node) then return end

    local tier, stars = self:GetTier(quality)
    if tier == 0 then
        self:ClearCard(root_node, opts)
        return
    end

    local nodes = self:_EnsureCardNodes(root_node)
    local dimmed = opts.dimmed == true
    local intensity = dimmed and 0.0 or (opts.intensity or 0.75)
    local phase = opts.phase
    if not phase then
        local tag = (root_node.getTag and root_node:getTag()) or 0
        phase = (tag % 37) * 0.68
    end

    -- 1) 宝石虹卡面 + 着色器
    if nodes.face and not tolua.isnull(nodes.face) then
        local bg_file = (tier == 1) and "rb_bg_0.png" or ((tier == 2) and "rb_bg_1.png" or "rb_bg_2.png")
        if nodes.face._rb_tex_name ~= bg_file then
            pcall(function()
                nodes.face:setTexture(ASSET_DIR .. bg_file)
                safe_alias(nodes.face)
            end)
            nodes.face._rb_tex_name = bg_file
        end
        nodes.face:setVisible(true)
        self:_ApplyCardShader(nodes.face, tier, phase, intensity)
    end

    -- 2) 中心缓慢旋转金辉日轮（★/★★ 且非置灰）
    if nodes.sun and not tolua.isnull(nodes.sun) then
        nodes.sun:stopAllActions()
        if (not dimmed) and tier >= 2 then
            nodes.sun:setVisible(true)
            nodes.sun:setOpacity(tier >= 3 and 78 or 48)
            nodes.sun:setRotation((phase * 47) % 360)
            local speed = tier >= 3 and 22.0 or 32.0
            nodes.sun:runAction(cc.RepeatForever:create(cc.RotateBy:create(speed, 360)))
        else
            nodes.sun:setVisible(false)
        end
    end

    -- 3) 四角微光宝石 + ★★ 八边双巡游流光
    if nodes.fx_layer and not tolua.isnull(nodes.fx_layer) then
        if (not dimmed) and tier >= 2 then
            nodes.fx_layer:setVisible(true)
            local colors = (tier >= 3)
                and { cc.c3b(255, 224, 125), cc.c3b(240, 142, 194), cc.c3b(140, 226, 232), cc.c3b(255, 224, 125) }
                or  { cc.c3b(242, 200, 107), cc.c3b(217, 142, 184), cc.c3b(242, 200, 107), cc.c3b(217, 142, 184) }
            for i, c in ipairs(nodes.corners or {}) do
                if c and not tolua.isnull(c) then
                    c:stopAllActions()
                    c:setColor(colors[i])
                    c:setOpacity(90)
                    local delay = ((phase * 0.23) + i * 0.35) % 1.4
                    c:runAction(cc.Sequence:create(
                        cc.DelayTime:create(delay),
                        cc.CallFunc:create(function()
                            c:runAction(cc.RepeatForever:create(cc.Sequence:create(
                                cc.FadeTo:create(0.75, 225),
                                cc.FadeTo:create(0.75, 70)
                            )))
                        end)
                    ))
                end
            end

            for g, gd in ipairs(nodes.gliders or {}) do
                if gd and not tolua.isnull(gd) then
                    if tier >= 3 then
                        gd:setVisible(true)
                        gd:setOpacity(math.floor(195 * math.min(1.0, intensity + 0.15)))
                        run_chamfer_glider(gd, g == 1 and 1 or 5, 5.4)
                    else
                        gd:stopAllActions()
                        gd:setVisible(false)
                    end
                end
            end
        else
            nodes.fx_layer:setVisible(false)
            for _, c in ipairs(nodes.corners or {}) do
                if c and not tolua.isnull(c) then c:stopAllActions() end
            end
            for _, g in ipairs(nodes.gliders or {}) do
                if g and not tolua.isnull(g) then
                    g:stopAllActions()
                    g:setVisible(false)
                end
            end
        end
    end

    -- 4) ★★ 角色轻微呼吸浮沉（严格锁定基准 Y，回收零漂移）
    local role_img = opts.role_img
    if role_img and not tolua.isnull(role_img) then
        if not role_img._rb_base_y then
            role_img._rb_base_y = role_img:getPositionY()
        end
        self:_ResetRoleBob(role_img)
        if (not dimmed) and tier >= 3 then
            local by = role_img._rb_base_y
            local bob = cc.RepeatForever:create(cc.Sequence:create(
                cc.MoveTo:create(1.1, cc.p(role_img:getPositionX(), by + 1.5)),
                cc.MoveTo:create(1.1, cc.p(role_img:getPositionX(), by - 0.5))
            ))
            bob:setTag(9301)
            role_img:runAction(bob)
            role_img._rb_bobbing = true
        end
    end

    -- 5) 顶中银金星冠托座（星样 3）并隐藏旧版左上角星标
    if opts.legacy_star_node and not tolua.isnull(opts.legacy_star_node) then
        opts.legacy_star_node:setVisible(false)
    end
    if nodes.crown and not tolua.isnull(nodes.crown) then
        if stars > 0 then
            local crown_file = (stars == 1) and "rb_crown_1.png" or ((stars == 2) and "rb_crown_2.png" or "rb_crown_3.png")
            if nodes.crown._rb_tex_name ~= crown_file then
                pcall(function()
                    nodes.crown:setTexture(ASSET_DIR .. crown_file)
                    safe_alias(nodes.crown)
                end)
                nodes.crown._rb_tex_name = crown_file
            end
            nodes.crown:setVisible(true)

            if nodes.crown_glint and not tolua.isnull(nodes.crown_glint) then
                nodes.crown_glint:stopAllActions()
                if not dimmed then
                    local csz = nodes.crown:getContentSize()
                    nodes.crown_glint:setPosition(csz.width * 0.5 + (stars == 2 and -7 or 0), csz.height - 6)
                    nodes.crown_glint:setVisible(true)
                    nodes.crown_glint:setOpacity(0)
                    local d = (phase * 0.31) % 1.8
                    nodes.crown_glint:runAction(cc.Sequence:create(
                        cc.DelayTime:create(d),
                        cc.CallFunc:create(function()
                            nodes.crown_glint:runAction(cc.RepeatForever:create(cc.Sequence:create(
                                cc.FadeTo:create(0.45, 220),
                                cc.FadeTo:create(0.55, 0),
                                cc.DelayTime:create(1.2)
                            )))
                        end)
                    ))
                else
                    nodes.crown_glint:setVisible(false)
                end
            end
        else
            nodes.crown:setVisible(false)
            if nodes.crown_glint and not tolua.isnull(nodes.crown_glint) then
                nodes.crown_glint:stopAllActions()
                nodes.crown_glint:setVisible(false)
            end
        end
    end
end

-- =========================================================================
-- 佣兵详情大舞台（以同源太阳花 + 鎏金桂冠双环取代廉价蓝环 · 脚下仅留干净投影）
-- =========================================================================
function rainbow_visual:_EnsureDetailNodes(parent_node, anchor_x, anchor_y, z_order)
    if parent_node._rb_detail and not tolua.isnull(parent_node._rb_detail.container) then
        return parent_node._rb_detail
    end

    local container = cc.Node:create()
    container:setPosition(anchor_x, anchor_y)
    container:setVisible(false)
    parent_node:addChild(container, z_order or 90)

    local d = { container = container, motes = {} }

    local shadow = create_pixel_sprite("rb_shadow.png")
    if shadow then
        shadow:setPosition(0, 8)
        shadow:setScale(2.6, 2.2)
        shadow:setOpacity(175)
        container:addChild(shadow, 1)
        d.shadow = shadow
    end

    local sun = create_pixel_sprite("rb_sunburst.png")
    if sun then
        sun:setPosition(0, 74)
        sun:setScale(2.7)
        pcall(function() sun:setBlendFunc(ADDITIVE_BLEND) end)
        container:addChild(sun, 2)
        d.sun = sun
    end

    local wreath = create_pixel_sprite("rb_wreath.png")
    if wreath then
        wreath:setPosition(0, 74)
        wreath:setScale(2.55)
        pcall(function() wreath:setBlendFunc(ADDITIVE_BLEND) end)
        wreath:setVisible(false)
        container:addChild(wreath, 3)
        d.wreath = wreath
    end

    local mote_cols = {
        cc.c3b(252, 224, 139),
        cc.c3b(235, 176, 210),
        cc.c3b(166, 224, 230),
    }
    for i = 1, 6 do
        local m = create_pixel_sprite("rb_dot.png")
        if m then
            m:setScale(2.0)
            m:setColor(mote_cols[((i - 1) % #mote_cols) + 1])
            pcall(function() m:setBlendFunc(ADDITIVE_BLEND) end)
            m:setVisible(false)
            container:addChild(m, 4)
            d.motes[i] = m
        end
    end

    parent_node._rb_detail = d
    return d
end

function rainbow_visual:ApplyToDetail(parent_node, quality, anchor_x, anchor_y, z_order)
    if not parent_node or tolua.isnull(parent_node) then return end
    local tier = self:GetTier(quality)
    if tier == 0 then
        local d = parent_node._rb_detail
        if d and d.container and not tolua.isnull(d.container) then
            d.container:setVisible(false)
            if d.sun and not tolua.isnull(d.sun) then d.sun:stopAllActions() end
            if d.wreath and not tolua.isnull(d.wreath) then d.wreath:stopAllActions() end
            for _, m in ipairs(d.motes or {}) do
                if m and not tolua.isnull(m) then m:stopAllActions() end
            end
        end
        return
    end

    local d = self:_EnsureDetailNodes(parent_node, anchor_x or 320, anchor_y or 620, z_order or 90)
    d.container:setVisible(true)

    if d.sun and not tolua.isnull(d.sun) then
        d.sun:stopAllActions()
        if tier == 1 then
            d.sun:setOpacity(95)
            d.sun:setScale(2.45)
            d.sun:runAction(cc.RepeatForever:create(cc.Sequence:create(
                cc.FadeTo:create(1.8, 130),
                cc.FadeTo:create(1.8, 85)
            )))
        elseif tier == 2 then
            d.sun:setOpacity(135)
            d.sun:setScale(2.65)
            d.sun:runAction(cc.RepeatForever:create(cc.RotateBy:create(30.0, 360)))
            d.sun:runAction(cc.RepeatForever:create(cc.Sequence:create(
                cc.FadeTo:create(1.5, 170),
                cc.FadeTo:create(1.5, 115)
            )))
        else
            d.sun:setOpacity(175)
            d.sun:setScale(2.85)
            d.sun:runAction(cc.RepeatForever:create(cc.RotateBy:create(20.0, 360)))
            d.sun:runAction(cc.RepeatForever:create(cc.Sequence:create(
                cc.FadeTo:create(1.3, 215),
                cc.FadeTo:create(1.3, 145)
            )))
        end
    end

    if d.wreath and not tolua.isnull(d.wreath) then
        d.wreath:stopAllActions()
        if tier >= 3 then
            d.wreath:setVisible(true)
            d.wreath:setOpacity(150)
            d.wreath:runAction(cc.RepeatForever:create(cc.Sequence:create(
                cc.Spawn:create(cc.FadeTo:create(1.4, 220), cc.ScaleTo:create(1.4, 2.62)),
                cc.Spawn:create(cc.FadeTo:create(1.4, 135), cc.ScaleTo:create(1.4, 2.52))
            )))
        else
            d.wreath:setVisible(false)
        end
    end

    local xs = { -78, -42, -14, 18, 48, 80 }
    for i, m in ipairs(d.motes or {}) do
        if m and not tolua.isnull(m) then
            m:stopAllActions()
            if tier >= 3 then
                local sx = xs[i] or 0
                m:setVisible(true)
                m:setOpacity(0)
                m:setPosition(sx, 14)
                local dur = 2.0 + (i % 3) * 0.45
                m:runAction(cc.Sequence:create(
                    cc.DelayTime:create((i - 1) * 0.38),
                    cc.CallFunc:create(function()
                        m:runAction(cc.RepeatForever:create(cc.Sequence:create(
                            cc.Place:create(cc.p(sx, 14)),
                            cc.Spawn:create(
                                cc.MoveBy:create(dur, cc.p(0, 128)),
                                cc.Sequence:create(
                                    cc.FadeTo:create(dur * 0.25, 200),
                                    cc.DelayTime:create(dur * 0.40),
                                    cc.FadeTo:create(dur * 0.35, 0)
                                )
                            )
                        )))
                    end)
                ))
            else
                m:setVisible(false)
            end
        end
    end
end

return rainbow_visual
