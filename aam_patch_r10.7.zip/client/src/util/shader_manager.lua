local TARGET_PLATFORM = cc.Application:getInstance():getTargetPlatform()

local shader_manager = {} 

function shader_manager:Init()
    self.programs = {}

    self.vert_file_list = {}
    self.frag_file_list = {}

    self.vert_file_list["battle_role"] = "res/shader/battle_role.vert"
    self.frag_file_list["battle_role"] = "res/shader/battle_role.frag"

    self.vert_file_list["tile"] = "res/shader/common.vert"
    self.frag_file_list["tile"] = "res/shader/tile.frag"

    self.vert_file_list["grayscale"] = "res/shader/common.vert"
    self.frag_file_list["grayscale"] = "res/shader/grayscale.frag"

    self.programs["battle_role"] = cc.GLProgram:createWithFilenames(self.vert_file_list["battle_role"], self.frag_file_list["battle_role"])
    self.programs["battle_role"]:retain()

    self.programs["tile"] = cc.GLProgram:createWithFilenames(self.vert_file_list["tile"], self.frag_file_list["tile"])
    self.programs["tile"]:retain()

    self.programs["grayscale"] = cc.GLProgram:createWithFilenames(self.vert_file_list["grayscale"], self.frag_file_list["grayscale"])
    self.programs["grayscale"]:retain()

    -- [MOD] 彩虹佣兵宝石虹流转着色器（GLES 2.0，按文件存在性安全加载，永不崩端）
    pcall(function()
        local fu = cc.FileUtils and cc.FileUtils:getInstance()
        local frag = "res/shader/rainbow_card.frag"
        if fu and fu:isFileExist(frag) then
            self.vert_file_list["rainbow_card"] = "res/shader/common.vert"
            self.frag_file_list["rainbow_card"] = frag
            local prog = cc.GLProgram:createWithFilenames("res/shader/common.vert", frag)
            if prog then
                prog:retain()
                self.programs["rainbow_card"] = prog
            end
        end
    end)


    local listener = cc.EventListenerCustom:create("event_renderer_recreated", function()
        print("EVENT_RENDERER_RECREATED")
        self:Reload()
    end)

    cc.Director:getInstance():getEventDispatcher():addEventListenerWithFixedPriority(listener, 1)
end

function shader_manager:GetProgram(name)
    return self.programs[name]
end

function shader_manager:Reload()

    for name, program in pairs(self.programs) do
        program:reset()

        program:initWithFilenames(self.vert_file_list[name], self.frag_file_list[name])

        program:link()
        program:updateUniforms()
    end
end

return shader_manager
