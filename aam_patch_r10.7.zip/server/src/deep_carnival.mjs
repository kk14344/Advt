import { existsSync, readFileSync, renameSync, writeFileSync } from "node:fs";
import { join } from "node:path";

export const BLOOD_SPEND_SENTINEL = -2;
export const TOKEN_STAR_CORE = 82;   // 太古星核
export const TOKEN_GRIND_MARK = 83;  // 肝帝印记

export const DEEP_KEYS = {
  BLOOD_BLACKHOLE: "blood_blackhole",
  GRIND_PASS: "grind_pass",
  STAR_CORE_SHOP: "star_core_shop",
  GRIND_MARK_SHOP: "grind_mark_shop",
  SOUL_EXCHANGE: "soul_exchange",
  MASTER_MILESTONES: "master_milestones",
};

const PASS_SOURCE_CAP = 4200; // 单一玩法每轮最多贡献 35%（4200 / 12000）
const PASS_SOURCES = ["mine", "treasure", "vanity", "campaign", "guild", "pvp"];

const rItem = (id, n = 1) => ({ reward_type: 1, param1: id, param2: n });
const rRes = (id, n = 1) => ({ reward_type: 2, param1: id, param2: n });
const rBp = (bp) => ({ reward_type: 6, param1: bp, param2: 1 });
const rMerc = (id) => ({ reward_type: 8, param1: id, param2: 1 });
const rToken = (id, n = 1) => ({ reward_type: 13, param1: id, param2: n });
const rSoul = (id, n = 1) => ({ reward_type: 15, param1: id, param2: n });
const rRune = (tplId, n = 1) => ({ reward_type: 16, param1: tplId, param2: n });
const rMap = (modelId, n = 1) => ({ reward_type: 21, param1: modelId, param2: n });

// ============================================================
// 1. 星海黑洞：血钻深水区累消（12档 · 三轮动态演化）
// ============================================================
export function getBloodBlackholeTiers(cycle = 1) {
  const c = Math.max(1, Math.floor(Number(cycle) || 1));
  const pick = (c1, c2, c3) => (c === 1 ? c1 : c === 2 ? c2 : c3);
  return [
    {
      need: 50000,
      rewards: [
        rToken(TOKEN_STAR_CORE, 1),
        rRes(35, 10),
        rRes(28, 40),
        ...pick([rMerc(19000336)], [rSoul(19000336, 3), rRes(54, 5000)], [rRes(102, 300), rRes(92, 300)]),
      ],
    },
    {
      need: 120000,
      rewards: [
        rToken(TOKEN_STAR_CORE, 1),
        rRes(5, 15),
        rItem(10000008, 2),
        ...pick([rMerc(19000337)], [rSoul(19000337, 3), rRes(56, 8)], [rRes(102, 450), rRes(90, 30)]),
      ],
    },
    {
      need: 250000,
      rewards: [
        rToken(TOKEN_STAR_CORE, 2),
        rItem(16000073, 2),
        rRes(54, 8000),
        ...pick([rMerc(19000338)], [rSoul(19000338, 3), rRes(92, 500)], [rRes(99, 8), rItem(16000076, 2)]),
      ],
    },
    {
      need: 450000,
      rewards: [
        rToken(TOKEN_STAR_CORE, c >= 3 ? 4 : 2),
        rRes(92, 600),
        rRes(90, 30),
        ...pick([rMerc(19000340), rItem(6000006, 1)], [rSoul(19000340, 4), rRes(57, 50)], [rRes(102, 600), rRes(99, 10)]),
      ],
    },
    {
      need: 700000,
      rewards: [
        rToken(TOKEN_STAR_CORE, 3),
        rItem(16000076, 2),
        rRes(99, 8),
        ...pick(
          [rMerc(19000341), rMerc(19000342)],
          [rSoul(19000341, 3), rSoul(19000342, 3)],
          [rItem(16000078, 2), rRes(99, 12)]
        ),
      ],
    },
    {
      need: 1000000,
      rewards: [
        rToken(TOKEN_STAR_CORE, 3),
        rRes(102, 800),
        rRes(56, 12),
        ...pick(
          [rMerc(19000343), rMerc(19000345)],
          [rSoul(19000343, 3), rSoul(19000345, 3), rRes(58, 40)],
          [rRes(106, 5000), rItem(16000061, 1)]
        ),
      ],
    },
    {
      need: 1400000,
      rewards: [
        rToken(TOKEN_STAR_CORE, c >= 3 ? 7 : 4),
        rItem(16000078, 2),
        rRes(54, 20000),
        ...pick(
          [rMerc(19000344), rMerc(19000346)],
          [rSoul(19000344, 3), rSoul(19000346, 3), rItem(6000006, 1)],
          [rItem(16000064, 1), rRes(102, 1000)]
        ),
      ],
    },
    {
      need: 1900000,
      rewards: [
        rToken(TOKEN_STAR_CORE, 5),
        rRes(99, 18),
        rItem(16000067, 1),
        ...pick(
          [rMerc(19000909), rMerc(19000910)],
          [rSoul(19000909, 3), rSoul(19000910, 3), rRes(106, 6000)],
          [rItem(16000061, 1), rRes(99, 20)]
        ),
      ],
    },
    {
      need: 2500000,
      rewards: [
        rToken(TOKEN_STAR_CORE, 6),
        rItem(16000073, 3),
        rRes(58, 60),
        ...pick(
          [rMerc(19000339)],
          [rSoul(19000339, 5), rRes(90, 80)],
          [rItem(16000078, 3), rRes(106, 8000)]
        ),
      ],
    },
    {
      need: 3200000,
      rewards: [
        rToken(TOKEN_STAR_CORE, c >= 3 ? 13 : 8),
        rItem(16000061, 1),
        rRes(99, 25),
        ...pick(
          [rMerc(19000335)],
          [rSoul(19000335, 5), rItem(16000064, 2)],
          [rItem(16000061, 2), rRes(90, 100)]
        ),
      ],
    },
    {
      need: 4000000,
      rewards: [
        rToken(TOKEN_STAR_CORE, 10),
        rItem(16000078, 3),
        rRes(56, 25),
        ...pick(
          [rMerc(19000347), rItem(6000006, 2)],
          [rSoul(19000347, 5), rRes(106, 12000)],
          [rRes(99, 40), rMap(6, 1)]
        ),
      ],
    },
    {
      need: 5000000,
      rewards: [
        rToken(TOKEN_STAR_CORE, c >= 3 ? 25 : 15),
        rMap(6, 2),
        rRes(106, 20000),
        ...pick(
          [rMerc(19000348), rItem(16000061, 2)],
          [rSoul(19000348, 5), rRes(99, 40)],
          [rItem(16000061, 3), rRes(99, 50)]
        ),
      ],
    },
  ];
}

// ============================================================
// 2. 肝帝通行证：六线全能活跃（15档 · 自动重置 · 替代战令）
// ============================================================
export const GRIND_PASS_TIERS = [
  { need: 100, rewards: [rToken(TOKEN_GRIND_MARK, 2), rRes(29, 3), rRes(2, 2000), rRes(54, 3000)] },
  { need: 300, rewards: [rToken(TOKEN_GRIND_MARK, 2), rRes(28, 30), rRes(3, 2000), rItem(16000075, 2)] },
  { need: 600, rewards: [rToken(TOKEN_GRIND_MARK, 3), rRes(5, 10), rRes(35, 8), rRes(92, 300)] },
  { need: 1000, rewards: [rToken(TOKEN_GRIND_MARK, 3), rRes(40, 10), rRes(55, 8), rBp(5000)] },
  { need: 1500, rewards: [rToken(TOKEN_GRIND_MARK, 4), rItem(16000074, 2), rRes(102, 300), rRes(106, 1500)] },
  { need: 2100, rewards: [rToken(TOKEN_GRIND_MARK, 4), rRes(28, 60), rRes(56, 8), rRes(90, 40)] },
  { need: 2800, rewards: [rToken(TOKEN_GRIND_MARK, 5), rItem(16000073, 2), rRes(99, 8), rItem(6000006, 1)] },
  { need: 3600, rewards: [rToken(TOKEN_GRIND_MARK, 5), rRes(18, 30), rRes(57, 50), rRes(106, 2500)] },
  { need: 4500, rewards: [rToken(TOKEN_GRIND_MARK, 6), rItem(16000076, 2), rRes(54, 15000), rRes(92, 800)] },
  { need: 5500, rewards: [rToken(TOKEN_GRIND_MARK, 8), rItem(16000078, 2), rRes(102, 600), rRune(64, 1)] },
  { need: 6700, rewards: [rToken(TOKEN_GRIND_MARK, 8), rRes(28, 120), rRes(58, 50), rRes(106, 4000)] },
  { need: 8000, rewards: [rToken(TOKEN_GRIND_MARK, 10), rItem(16000073, 3), rRes(99, 18), rBp(15000)] },
  { need: 9500, rewards: [rToken(TOKEN_GRIND_MARK, 12), rItem(16000078, 3), rItem(16000061, 1), rItem(16000067, 1)] },
  { need: 11000, rewards: [rToken(TOKEN_GRIND_MARK, 15), rItem(13000007, 3), rRes(99, 25), rRune(86, 1), rRes(106, 6000)] },
  { need: 12000, rewards: [rToken(TOKEN_GRIND_MARK, 20), rToken(TOKEN_STAR_CORE, 10), rMap(6, 2), rItem(16000061, 2), rRes(106, 10000)] },
];

// ============================================================
// 3. 星核兑换：太古星核策略兑换所（19档 · 破星包 / 四圣四凶 / 流派轴）
// ============================================================
export const STAR_CORE_SHOP_TIERS = [
  // 五鲲破星包（5枚灵魂石+10崇高契约石，一步满足0★→★）
  { title: "尸鲲破星包 · 灵魂石×5", cost: 12, limit: 99, rewards: [rSoul(19000319, 5), rRes(99, 10)] },
  { title: "骨鲲破星包 · 灵魂石×5", cost: 12, limit: 99, rewards: [rSoul(19000320, 5), rRes(99, 10)] },
  { title: "土鲲破星包 · 灵魂石×5", cost: 12, limit: 99, rewards: [rSoul(19000322, 5), rRes(99, 10)] },
  { title: "巨鲲破星包 · 灵魂石×5", cost: 12, limit: 99, rewards: [rSoul(19000323, 5), rRes(99, 10)] },
  { title: "蓝鲲破星包 · 灵魂石×5", cost: 12, limit: 99, rewards: [rSoul(19000324, 5), rRes(99, 10)] },
  // 四凶破星包（精准对表 mercenary_quality.csv）
  { title: "混沌破星包 · 灵魂石×5", cost: 18, limit: 99, rewards: [rSoul(19000325, 5), rRes(99, 10)] },
  { title: "饕餮破星包 · 灵魂石×5", cost: 18, limit: 99, rewards: [rSoul(19000326, 5), rRes(99, 10)] },
  { title: "穷奇破星包 · 灵魂石×5", cost: 18, limit: 99, rewards: [rSoul(19000327, 5), rRes(99, 10)] },
  { title: "梼杌破星包 · 灵魂石×5", cost: 18, limit: 99, rewards: [rSoul(19000328, 5), rRes(99, 10)] },
  // 四圣破星包
  { title: "神龙破星包 · 灵魂石×5", cost: 18, limit: 99, rewards: [rSoul(19000329, 5), rRes(99, 10)] },
  { title: "北极虎破星 · 灵魂石×5", cost: 18, limit: 99, rewards: [rSoul(19000330, 5), rRes(99, 10)] },
  { title: "不死鸟破星 · 灵魂石×5", cost: 18, limit: 99, rewards: [rSoul(19000331, 5), rRes(99, 10)] },
  { title: "龙龟破星包 · 灵魂石×5", cost: 18, limit: 99, rewards: [rSoul(19000332, 5), rRes(99, 10)] },
  // 终极14将四大流派包
  { title: "先暴轴：伏羲/杀生丸/千人斩", cost: 14, limit: 99, rewards: [rMerc(19000335), rMerc(19000339), rMerc(19000343)] },
  { title: "闪回轴：女娲/八岐/小杜莎", cost: 14, limit: 99, rewards: [rMerc(19000347), rMerc(19000348), rMerc(19000344)] },
  { title: "侠侣轴：阳过/小聋女/露娜", cost: 12, limit: 99, rewards: [rMerc(19000341), rMerc(19000342), rMerc(19000346)] },
  { title: "越战轴：ikun/skr/阿普", cost: 12, limit: 99, rewards: [rMerc(19000338), rMerc(19000337), rMerc(19000340)] },
  // 终局极品产出
  { title: "王之宝藏×1 + 彩虹碎片", cost: 16, limit: 99, rewards: [rMap(6, 1), rRes(102, 1500)] },
  { title: "神话彩虹符文 · 三王礼盒", cost: 20, limit: 99, rewards: [rRune(86, 1), rRune(88, 1), rRune(90, 1)] },
];

// ============================================================
// 4. 印记工坊：肝帝印记补给与定向兑换（16档 · 补漏 / 养成熔炉）
// ============================================================
export const GRIND_MARK_SHOP_TIERS = [
  { title: "尸鲲补星 · 灵魂石×1", cost: 6, limit: 99, rewards: [rSoul(19000319, 1), rRes(102, 150)] },
  { title: "骨鲲补星 · 灵魂石×1", cost: 6, limit: 99, rewards: [rSoul(19000320, 1), rRes(102, 150)] },
  { title: "土鲲补星 · 灵魂石×1", cost: 6, limit: 99, rewards: [rSoul(19000322, 1), rRes(102, 150)] },
  { title: "巨鲲补星 · 灵魂石×1", cost: 6, limit: 99, rewards: [rSoul(19000323, 1), rRes(102, 150)] },
  { title: "蓝鲲补星 · 灵魂石×1", cost: 6, limit: 99, rewards: [rSoul(19000324, 1), rRes(102, 150)] },
  { title: "四凶补缺 · 混沌 + 饕餮", cost: 24, limit: 99, rewards: [rMerc(19000325), rMerc(19000326)] },
  { title: "四凶补缺 · 穷奇 + 梼杌", cost: 24, limit: 99, rewards: [rMerc(19000327), rMerc(19000328)] },
  { title: "四圣补缺 · 神龙 + 北极虎", cost: 24, limit: 99, rewards: [rMerc(19000329), rMerc(19000330)] },
  { title: "四圣补缺 · 不死鸟 + 龙龟", cost: 24, limit: 99, rewards: [rMerc(19000331), rMerc(19000332)] },
  { title: "先暴补魂 · 伏羲/杀生丸", cost: 12, limit: 99, rewards: [rSoul(19000335, 2), rSoul(19000339, 2)] },
  { title: "闪回补魂 · 女娲/八岐", cost: 12, limit: 99, rewards: [rSoul(19000347, 2), rSoul(19000348, 2)] },
  { title: "升星炉 · 彩碎+崇高契约", cost: 15, limit: 99, rewards: [rRes(102, 1200), rRes(99, 15)] },
  { title: "宿命炉 · 结晶+命运徽章", cost: 12, limit: 99, rewards: [rRes(92, 1200), rRes(90, 60)] },
  { title: "符文井 · 水晶+彩虹经验", cost: 10, limit: 99, rewards: [rRes(54, 30000), rRune(98, 1)] },
  { title: "矿区续航 · 雷管/徽章/镐", cost: 12, limit: 99, rewards: [rRes(28, 150), rRes(5, 30), rItem(6000006, 1)] },
  { title: "王之锻造 · 王图+宝具券", cost: 18, limit: 99, rewards: [rMap(6, 1), rRes(56, 15)] },
];

// ============================================================
// 5. 同源置换：2:1 防非灵魂石互换台（13档 · 原生 mercenary_exchange）
// ============================================================
export const SOUL_EXCHANGE_ENTRIES = {
  101: { id: 101, groupId: 20261101, mercId: 19000325, cost: 2, times: 99 },
  102: { id: 102, groupId: 20261101, mercId: 19000326, cost: 2, times: 99 },
  103: { id: 103, groupId: 20261101, mercId: 19000327, cost: 2, times: 99 },
  104: { id: 104, groupId: 20261101, mercId: 19000328, cost: 2, times: 99 },
  105: { id: 105, groupId: 20261102, mercId: 19000329, cost: 2, times: 99 },
  106: { id: 106, groupId: 20261102, mercId: 19000330, cost: 2, times: 99 },
  107: { id: 107, groupId: 20261102, mercId: 19000331, cost: 2, times: 99 },
  108: { id: 108, groupId: 20261102, mercId: 19000332, cost: 2, times: 99 },
  109: { id: 109, groupId: 20261103, mercId: 19000319, cost: 2, times: 99 },
  110: { id: 110, groupId: 20261103, mercId: 19000320, cost: 2, times: 99 },
  111: { id: 111, groupId: 20261103, mercId: 19000322, cost: 2, times: 99 },
  112: { id: 112, groupId: 20261103, mercId: 19000323, cost: 2, times: 99 },
  113: { id: 113, groupId: 20261103, mercId: 19000324, cost: 2, times: 99 },
};

export const SOUL_EXCHANGE_STEPS = [
  { groupId: 20261101, targetMerc: 19000325, desc: "四凶灵魂石×2 → 混沌×1", icon: "icon/resource/soul_chip2022.png" },
  { groupId: 20261101, targetMerc: 19000326, desc: "四凶灵魂石×2 → 饕餮×1", icon: "icon/resource/soul_chip2022.png" },
  { groupId: 20261101, targetMerc: 19000327, desc: "四凶灵魂石×2 → 穷奇×1", icon: "icon/resource/soul_chip2022.png" },
  { groupId: 20261101, targetMerc: 19000328, desc: "四凶灵魂石×2 → 梼杌×1", icon: "icon/resource/soul_chip2022.png" },
  { groupId: 20261102, targetMerc: 19000329, desc: "四圣灵魂石×2 → 神龙×1", icon: "icon/resource/soul_chip2022.png" },
  { groupId: 20261102, targetMerc: 19000330, desc: "四圣灵魂石×2 → 北极虎×1", icon: "icon/resource/soul_chip2022.png" },
  { groupId: 20261102, targetMerc: 19000331, desc: "四圣灵魂石×2 → 不死鸟×1", icon: "icon/resource/soul_chip2022.png" },
  { groupId: 20261102, targetMerc: 19000332, desc: "四圣灵魂石×2 → 龙龟×1", icon: "icon/resource/soul_chip2022.png" },
  { groupId: 20261103, targetMerc: 19000319, desc: "五鲲灵魂石×2 → 尸鲲×1", icon: "icon/resource/soul_chip2022.png" },
  { groupId: 20261103, targetMerc: 19000320, desc: "五鲲灵魂石×2 → 骨鲲×1", icon: "icon/resource/soul_chip2022.png" },
  { groupId: 20261103, targetMerc: 19000322, desc: "五鲲灵魂石×2 → 土鲲×1", icon: "icon/resource/soul_chip2022.png" },
  { groupId: 20261103, targetMerc: 19000323, desc: "五鲲灵魂石×2 → 巨鲲×1", icon: "icon/resource/soul_chip2022.png" },
  { groupId: 20261103, targetMerc: 19000324, desc: "五鲲灵魂石×2 → 蓝鲲×1", icon: "icon/resource/soul_chip2022.png" },
];

// ============================================================
// 6. 全系宗师：五维终局荣耀里程碑（12档 · 独立实时多维进度）
// ============================================================
export const MASTER_MILESTONE_TIERS = [
  { metric: "bp", need: 500000, desc: "最高战力达到 500K", icon: "icon/mercenarylist/fighting_capacity.png", rewards: [rItem(6000006, 1), rMerc(19000419), rMerc(19000420), rItem(16000073, 2)] },
  { metric: "codex", need: 120, desc: "图鉴收集达到 120 名", icon: "icon/resource/soul_chip2022.png", rewards: [rBp(10000), rMerc(19000422), rMerc(19000423), rRes(54, 15000), rRes(106, 3000)] },
  { metric: "bossKills", need: 50, desc: "累计击杀矿区Boss 50 次", icon: "icon/resource/golem.png", rewards: [rItem(6000006, 2), rMerc(19000424), rRes(28, 200), rRes(5, 50), rItem(16000078, 2)] },
  { metric: "destinyStars", need: 15, desc: "宿命武器总星级达到 15 星", icon: "icon/item/2000002.png", rewards: [rBp(25000), rToken(TOKEN_STAR_CORE, 10), rToken(TOKEN_GRIND_MARK, 20), rRes(92, 2000), rRes(99, 20)] },
  { metric: "bp", need: 20000000, desc: "最高战力达到 20M", icon: "icon/mercenarylist/fighting_capacity.png", rewards: [rItem(6000006, 2), rSoul(19000325, 3), rSoul(19000329, 3), rItem(16000061, 2), rMap(6, 2)] },
  { metric: "runeLv", need: 24, desc: "已装备高阶符文(≥4级)总等级 24", icon: "icon/resource/rune_stone.png", rewards: [rBp(50000), rRune(86, 1), rRune(88, 1), rRes(54, 60000), rRes(106, 10000)] },
  { metric: "star1", need: 3, desc: "累计拥有 3 名 ★ 一星彩虹", icon: "icon/resource/soul_chip2022.png", rewards: [rItem(6000006, 3), rToken(TOKEN_STAR_CORE, 20), rToken(TOKEN_GRIND_MARK, 30), rRes(99, 50), rMap(6, 3)] },
  { metric: "codex", need: 300, desc: "图鉴收集达到 300 名", icon: "icon/resource/soul_chip2022.png", rewards: [rBp(100000), rSoul(19000335, 3), rSoul(19000347, 3), rSoul(19000339, 3), rSoul(19000348, 3), rRes(106, 20000)] },
  { metric: "bossKills", need: 300, desc: "累计击杀矿区Boss 300 次", icon: "icon/resource/golem.png", rewards: [rItem(6000006, 4), rSoul(19000325, 5), rSoul(19000326, 5), rSoul(19000327, 5), rSoul(19000328, 5), rMap(6, 4)] },
  { metric: "destinyStars", need: 45, desc: "宿命武器总星级达到 45 星", icon: "icon/item/2000002.png", rewards: [rBp(200000), rSoul(19000329, 5), rSoul(19000330, 5), rSoul(19000331, 5), rSoul(19000332, 5), rRes(106, 35000)] },
  { metric: "star2", need: 5, desc: "累计拥有 5 名 ★★ 二星彩虹", icon: "icon/resource/soul_chip2022.png", rewards: [rSoul(19000319, 10), rSoul(19000320, 10), rSoul(19000322, 10), rSoul(19000323, 10), rSoul(19000324, 10), rMap(6, 6)] },
  { metric: "bp", need: 500000000, desc: "肝帝之巅：最高战力达到 500M", icon: "icon/mercenarylist/fighting_capacity.png", rewards: [rBp(500000), rToken(TOKEN_STAR_CORE, 60), rToken(TOKEN_GRIND_MARK, 100), rRes(99, 300), rMap(6, 10), rRes(106, 100000)] },
];

// ============================================================
// 持久化状态管理
// ============================================================
let savePath = "";
let cachedState = null;

function emptyDeepState() {
  return {
    bloodSpend: 0,
    bloodCycle: 1,
    bloodClaimed: [],
    passPoints: 0,
    passCycle: 1,
    passClaimed: [],
    passBySource: { mine: 0, treasure: 0, vanity: 0, campaign: 0, guild: 0, pvp: 0 },
    tokens: { [TOKEN_STAR_CORE]: 0, [TOKEN_GRIND_MARK]: 0 },
    starCoreCounts: {},
    grindMarkCounts: {},
    soulExchangeCounts: {},
    masterClaimed: [],
    bossKills: 0,
    peakBp: 0,
  };
}

export function initDeepCarnival(baseDir) {
  savePath = join(baseDir, "../deep_carnival_save.json");
  cachedState = null;
}

export function resetDeepCarnivalCache() {
  cachedState = null;
}

export function loadDeepState() {
  if (cachedState) return cachedState;
  const base = emptyDeepState();
  try {
    if (savePath && existsSync(savePath)) {
      const raw = JSON.parse(readFileSync(savePath, "utf8").replace(/^\uFEFF/, ""));
      base.bloodSpend = Math.max(0, Math.floor(Number(raw.bloodSpend) || 0));
      base.bloodCycle = Math.max(1, Math.floor(Number(raw.bloodCycle) || 1));
      base.bloodClaimed = Array.isArray(raw.bloodClaimed)
        ? [...new Set(raw.bloodClaimed.map((v) => Math.floor(Number(v))).filter((v) => v >= 1 && v <= 12))].sort((a, b) => a - b)
        : [];
      base.passPoints = Math.max(0, Math.floor(Number(raw.passPoints) || 0));
      base.passCycle = Math.max(1, Math.floor(Number(raw.passCycle) || 1));
      base.passClaimed = Array.isArray(raw.passClaimed)
        ? [...new Set(raw.passClaimed.map((v) => Math.floor(Number(v))).filter((v) => v >= 1 && v <= GRIND_PASS_TIERS.length))].sort((a, b) => a - b)
        : [];
      if (raw.passBySource && typeof raw.passBySource === "object") {
        for (const src of PASS_SOURCES) {
          base.passBySource[src] = Math.max(0, Math.floor(Number(raw.passBySource[src]) || 0));
        }
      }
      if (raw.tokens && typeof raw.tokens === "object") {
        base.tokens[TOKEN_STAR_CORE] = Math.max(0, Math.floor(Number(raw.tokens[TOKEN_STAR_CORE]) || 0));
        base.tokens[TOKEN_GRIND_MARK] = Math.max(0, Math.floor(Number(raw.tokens[TOKEN_GRIND_MARK]) || 0));
      }
      if (raw.starCoreCounts && typeof raw.starCoreCounts === "object") base.starCoreCounts = { ...raw.starCoreCounts };
      if (raw.grindMarkCounts && typeof raw.grindMarkCounts === "object") base.grindMarkCounts = { ...raw.grindMarkCounts };
      if (raw.soulExchangeCounts && typeof raw.soulExchangeCounts === "object") base.soulExchangeCounts = { ...raw.soulExchangeCounts };
      base.masterClaimed = Array.isArray(raw.masterClaimed)
        ? [...new Set(raw.masterClaimed.map((v) => Math.floor(Number(v))).filter((v) => v >= 1 && v <= MASTER_MILESTONE_TIERS.length))].sort((a, b) => a - b)
        : [];
      base.bossKills = Math.max(0, Math.floor(Number(raw.bossKills) || 0));
      base.peakBp = Math.max(0, Math.floor(Number(raw.peakBp) || 0));
    }
  } catch (err) {
    console.warn(`[deep_carnival] load failed: ${err?.message ?? err}`);
  }
  cachedState = base;
  return cachedState;
}

export function saveDeepState(state = cachedState) {
  if (!savePath || !state) return;
  const text = JSON.stringify(state, null, 2);
  const tmp = `${savePath}.tmp`;
  try {
    writeFileSync(tmp, text, "utf8");
    try {
      renameSync(tmp, savePath);
    } catch {
      writeFileSync(savePath, text, "utf8");
    }
  } catch (err) {
    console.warn(`[deep_carnival] save failed: ${err?.message ?? err}`);
  }
}

// ============================================================
// 配置构造（支持星海黑洞按轮次动态切换奖励）
// ============================================================
export function buildBloodBlackholeConfig(state = loadDeepState()) {
  const c = state.bloodCycle;
  const tiers = getBloodBlackholeTiers(c);
  const stageDesc =
    c === 1
      ? "第1轮【终极筑基】：送全套14名终极版英雄 + 闪耀矿镐 + 太古星核"
      : c === 2
      ? "第2轮【契约深造】：送14名终极版灵魂石 + 宿命/宝具材料 + 太古星核"
      : `第${c}轮【无限终局】：送高额太古星核 + 彩虹碎片/崇高契约石 + 王之宝藏`;
  return {
    key: DEEP_KEYS.BLOOD_BLACKHOLE,
    name: "星海黑洞",
    desc: `${stageDesc}。累计消耗血钻达标领奖，领满12档自动进化下一轮！`,
    carnival_type: 1,
    need_type: 2,
    tab_icon: "tab_10_consumption_oneday.png",
    pos: 5,
    visible_style: [2, 0, 0],
    mult_num1: tiers.map((t) => t.need),
    mult_str1: ["累计消耗血钻%d"],
    mult_str2: ["icon/resource/blood_diamond.png"],
    collect_step: tiers.map((t) => ({ step_info: [t.need] })),
    reward_list: tiers.map((t) => ({ reward_group_id: 0, reward_info: t.rewards })),
  };
}

export function buildDeepCarnivalConfigs(state = loadDeepState()) {
  return [
    buildBloodBlackholeConfig(state),
    {
      key: DEEP_KEYS.GRIND_PASS,
      name: "肝帝通行证",
      desc: "挖矿/Boss(+1/+30)、传奇图/王之宝藏(+40/+120)、虚空(+35)、合战(+20)、公会Boss(+40)、竞技(+25)均计分（单玩法每轮上限4200），领满15档自动重置！",
      carnival_type: 1,
      need_type: 901,
      tab_icon: "tab_5_explore.png",
      pos: 6,
      visible_style: [2, 0, 0],
      mult_num1: GRIND_PASS_TIERS.map((t) => t.need),
      mult_str1: ["累计肝帝积分%d"],
      mult_str2: ["icon/festival/crown.png"],
      collect_step: GRIND_PASS_TIERS.map((t) => ({ step_info: [t.need] })),
      reward_list: GRIND_PASS_TIERS.map((t) => ({ reward_group_id: 0, reward_info: t.rewards })),
    },
    {
      key: DEEP_KEYS.STAR_CORE_SHOP,
      name: "星核兑换",
      desc: "消耗【星海黑洞】产出的太古星核，定向兑换五鲲/四圣四凶破星包（灵魂石×5+崇高契约石×10）、终极14将流派包与神话彩虹符文。",
      carnival_type: 4,
      need_type: 13,
      tab_icon: "tab_17.png",
      pos: 7,
      visible_style: [6, 4, 0],
      extra_num1: TOKEN_STAR_CORE,
      mult_num1: [TOKEN_STAR_CORE],
      mult_str1: STAR_CORE_SHOP_TIERS.map((t) => t.title),
      collect_step: STAR_CORE_SHOP_TIERS.map((t) => ({ step_info: [t.cost] })),
      reward_list: STAR_CORE_SHOP_TIERS.map((t) => ({ reward_group_id: 0, reward_info: t.rewards })),
    },
    {
      key: DEEP_KEYS.GRIND_MARK_SHOP,
      name: "印记工坊",
      desc: "消耗肝帝印记，兑换五鲲散枚灵魂石、四圣四凶本体、终极群侠与终局升星/宿命/符文材料。",
      carnival_type: 4,
      need_type: 13,
      tab_icon: "tab_3_store.png",
      pos: 8,
      visible_style: [6, 4, 0],
      extra_num1: TOKEN_GRIND_MARK,
      mult_num1: [TOKEN_GRIND_MARK],
      mult_str1: GRIND_MARK_SHOP_TIERS.map((t) => t.title),
      collect_step: GRIND_MARK_SHOP_TIERS.map((t) => ({ step_info: [t.cost] })),
      reward_list: GRIND_MARK_SHOP_TIERS.map((t) => ({ reward_group_id: 0, reward_info: t.rewards })),
    },
    {
      key: DEEP_KEYS.SOUL_EXCHANGE,
      name: "同源置换",
      desc: "防非保底：消耗任意2枚同系（四凶/四圣/五鲲）灵魂石，定向置换1枚目标灵魂石！",
      carnival_type: 18,
      need_type: 15,
      tab_icon: "tab_18.png",
      pos: 9,
      visible_style: [9, 0, 0],
      mult_num1: SOUL_EXCHANGE_STEPS.map((_, i) => i + 1),
      mult_str1: SOUL_EXCHANGE_STEPS.map((s) => s.desc),
      mult_str2: SOUL_EXCHANGE_STEPS.map((s) => s.icon),
      reward_list: SOUL_EXCHANGE_STEPS.map((s) => ({
        reward_group_id: s.groupId,
        reward_info: [rSoul(s.targetMerc, 1)],
      })),
    },
    {
      key: DEEP_KEYS.MASTER_MILESTONES,
      name: "全系宗师",
      desc: "五维终局荣耀（战力/图鉴/矿区Boss/宿命星级/符文与彩虹星级），每项独立计分，送永久镐上限与成套灵魂石！",
      carnival_type: 3,
      need_type: 0,
      tab_icon: "tab_1_bp.png",
      pos: 10,
      visible_style: [2, 0, 0],
      mult_num1: MASTER_MILESTONE_TIERS.map((t) => t.need),
      mult_num2: MASTER_MILESTONE_TIERS.map((_, i) => i + 1),
      mult_str1: MASTER_MILESTONE_TIERS.map((t) => t.desc),
      mult_str2: MASTER_MILESTONE_TIERS.map((t) => t.icon),
      collect_step: MASTER_MILESTONE_TIERS.map((t) => ({ step_info: [t.need] })),
      reward_list: MASTER_MILESTONE_TIERS.map((t) => ({ reward_group_id: 0, reward_info: t.rewards })),
    },
  ];
}

// ============================================================
// 实时进度计算与 Info 包构造
// ============================================================
export function computeMasterMetrics(session, ctx, state = loadDeepState()) {
  const troop = ctx.getTroopState(session);
  const destiny = ctx.getDestinyState(session);
  const runeState = ctx.getRuneState(session);

  const curBp = Math.max(
    state.peakBp,
    Math.floor(Number(troop?.battleBp) || 0),
    Math.floor(Number(ctx.calcFormationBp(troop)) || 0)
  );
  if (curBp > state.peakBp) {
    state.peakBp = curBp;
    saveDeepState(state);
  }

  const codex = troop?.library ? troop.library.size : 0;
  let star1 = 0;
  let star2 = 0;
  if (troop?.mercenaries) {
    for (const m of troop.mercenaries.values()) {
      const q = ctx.getMercQuality(m.templateId);
      if (q === 30) star1 += 1;
      else if (q >= 31) {
        star1 += 1;
        star2 += 1;
      }
    }
  }

  let destinyStars = 0;
  if (Array.isArray(destiny?.starInfo)) {
    for (const it of destiny.starInfo) {
      destinyStars += Math.min(12, Math.max(0, Math.floor(Number(it?.star_level) || 0)));
    }
  }

  let runeLv = 0;
  if (Array.isArray(runeState?.bag)) {
    for (const r of runeState.bag) {
      if ((Number(r.equipPos) || 0) > 0 && (Number(r.level) || 0) >= 4) {
        runeLv += Math.floor(Number(r.level) || 0);
      }
    }
  }

  return {
    bp: curBp,
    codex,
    bossKills: state.bossKills,
    destinyStars,
    runeLv,
    star1,
    star2,
  };
}

export function buildDeepCarnivalInfos(session, ctx, state = loadDeepState()) {
  const bloodClaimed = new Set(state.bloodClaimed);
  const passClaimed = new Set(state.passClaimed);
  const masterClaimed = new Set(state.masterClaimed);
  const metrics = computeMasterMetrics(session, ctx, state);
  const starCoreNum = state.tokens[TOKEN_STAR_CORE] || 0;
  const grindMarkNum = state.tokens[TOKEN_GRIND_MARK] || 0;

  const bloodTiers = getBloodBlackholeTiers(state.bloodCycle);

  // Build exchange_record array indexed by exchangeId (1..113) for soul_exchange
  const exRecordLen = 120;
  const exRecord = new Array(exRecordLen).fill(0);
  for (const [k, v] of Object.entries(state.soulExchangeCounts)) {
    const idx = Number(k);
    if (idx >= 1 && idx <= exRecordLen) exRecord[idx - 1] = Math.max(0, Math.floor(Number(v) || 0));
  }

  return [
    {
      key: DEEP_KEYS.BLOOD_BLACKHOLE,
      cur_value: state.bloodSpend,
      cur_value_multi: [],
      collect_info: [state.bloodSpend],
      step_reward: bloodTiers.map((_, i) => (bloodClaimed.has(i + 1) ? 0 : 1)),
      step_flag: bloodTiers.map((_, i) => (bloodClaimed.has(i + 1) ? 0 : 1)),
      exchange_record: [],
    },
    {
      key: DEEP_KEYS.GRIND_PASS,
      cur_value: state.passPoints,
      cur_value_multi: [],
      collect_info: [state.passPoints],
      step_reward: GRIND_PASS_TIERS.map((_, i) => (passClaimed.has(i + 1) ? 0 : 1)),
      step_flag: GRIND_PASS_TIERS.map((_, i) => (passClaimed.has(i + 1) ? 0 : 1)),
      exchange_record: [],
    },
    {
      key: DEEP_KEYS.STAR_CORE_SHOP,
      cur_value: starCoreNum,
      cur_value_multi: [],
      collect_info: [starCoreNum],
      step_reward: STAR_CORE_SHOP_TIERS.map((t, i) => Math.max(0, t.limit - (Number(state.starCoreCounts[i + 1]) || 0))),
      step_flag: STAR_CORE_SHOP_TIERS.map((t, i) => Math.max(0, t.limit - (Number(state.starCoreCounts[i + 1]) || 0))),
      exchange_record: [],
    },
    {
      key: DEEP_KEYS.GRIND_MARK_SHOP,
      cur_value: grindMarkNum,
      cur_value_multi: [],
      collect_info: [grindMarkNum],
      step_reward: GRIND_MARK_SHOP_TIERS.map((t, i) => Math.max(0, t.limit - (Number(state.grindMarkCounts[i + 1]) || 0))),
      step_flag: GRIND_MARK_SHOP_TIERS.map((t, i) => Math.max(0, t.limit - (Number(state.grindMarkCounts[i + 1]) || 0))),
      exchange_record: [],
    },
    {
      key: DEEP_KEYS.SOUL_EXCHANGE,
      cur_value: 0,
      cur_value_multi: [],
      collect_info: [],
      step_reward: SOUL_EXCHANGE_STEPS.map(() => 99),
      step_flag: SOUL_EXCHANGE_STEPS.map(() => 99),
      exchange_record: exRecord,
    },
    {
      key: DEEP_KEYS.MASTER_MILESTONES,
      cur_value: 0,
      cur_value_multi: MASTER_MILESTONE_TIERS.map((t) => metrics[t.metric] ?? 0),
      collect_info: MASTER_MILESTONE_TIERS.map((t) => Math.min(2147483647, Math.max(0, Math.floor(metrics[t.metric] ?? 0)))),
      step_reward: MASTER_MILESTONE_TIERS.map((_, i) => (masterClaimed.has(i + 1) ? 0 : 1)),
      step_flag: MASTER_MILESTONE_TIERS.map((_, i) => (masterClaimed.has(i + 1) ? 0 : 1)),
      exchange_record: [],
    },
  ];
}

// ============================================================
// 实时行为挂钩：血钻消费 / 六线肝帝积分 / 矿区Boss击杀
// ============================================================
export function recordBloodDiamondSpend(session, amount) {
  const delta = Math.max(0, Math.floor(Number(amount) || 0));
  if (delta <= 0) return;
  const state = loadDeepState();
  state.bloodSpend += delta;
  saveDeepState(state);
  session.send({
    session: 0,
    sync_id: 0,
    update_carnival_info_ret: {
      carnival_info: [
        {
          key: DEEP_KEYS.BLOOD_BLACKHOLE,
          need_type: 2,
          new_value: state.bloodSpend,
        },
      ],
    },
  });
}

export function recordGrindPassActivity(session, source, rawPoints, opts = {}) {
  const pts = Math.max(0, Math.floor(Number(rawPoints) || 0));
  const state = loadDeepState();
  let dirty = false;

  if (opts.bossKill) {
    state.bossKills += Math.max(1, Math.floor(Number(opts.bossKill) || 1));
    dirty = true;
  }

  let added = 0;
  if (pts > 0 && PASS_SOURCES.includes(source)) {
    const curSrc = state.passBySource[source] || 0;
    const room = Math.max(0, PASS_SOURCE_CAP - curSrc);
    added = Math.min(pts, room);
    if (added > 0) {
      state.passBySource[source] = curSrc + added;
      state.passPoints += added;
      dirty = true;
    }
  }

  if (dirty) saveDeepState(state);
  if (added > 0) {
    session.send({
      session: 0,
      sync_id: 0,
      update_carnival_info_ret: {
        carnival_info: [
          {
            key: DEEP_KEYS.GRIND_PASS,
            need_type: 901,
            new_value: state.passPoints,
          },
        ],
      },
    });
  }
}

function pushTokenUpdate(session, tokenId, newVal) {
  const targetKey = tokenId === TOKEN_STAR_CORE ? DEEP_KEYS.STAR_CORE_SHOP : DEEP_KEYS.GRIND_MARK_SHOP;
  session.send({
    session: 0,
    sync_id: 0,
    update_carnival_info_ret: {
      carnival_info: [
        {
          key: targetKey,
          need_type: tokenId,
          new_value: newVal,
        },
      ],
    },
  });
}

function dispatchDeepRewards(session, rawRewards, ctx, state) {
  const toSend = [];
  let mapAdded = false;
  const troop = ctx.getTroopState(session);
  let troopDirty = false;
  const updatedTokens = new Set();

  for (const r of rawRewards) {
    if (r.reward_type === 13) {
      const tid = Number(r.param1);
      const cnt = Math.max(1, Math.floor(Number(r.param2) || 1));
      state.tokens[tid] = (state.tokens[tid] || 0) + cnt;
      updatedTokens.add(tid);
      toSend.push({ ...r });
    } else if (r.reward_type === 21) {
      const cnt = Math.max(1, Math.floor(Number(r.param2) || 1));
      for (let i = 0; i < cnt; i++) {
        const map = ctx.addTreasureMap(session, r.param1);
        if (map) mapAdded = true;
      }
      toSend.push({ ...r });
    } else if (r.reward_type === 16) {
      const cnt = Math.max(1, Math.floor(Number(r.param2) || 1));
      for (let i = 0; i < cnt; i++) {
        ctx.addRuneItemReward(session, r.param1, toSend);
      }
    } else if (r.reward_type === 6) {
      const bp = Math.max(0, Math.floor(Number(r.param1) || 0));
      if (troop && bp > 0) {
        troop.leaderBpBonus = (Number(troop.leaderBpBonus) || 0) + bp;
        troopDirty = true;
      }
      toSend.push({ ...r });
    } else {
      toSend.push({ ...r });
    }
  }

  if (troopDirty) ctx.saveTroopState(troop);
  if (updatedTokens.size > 0) saveDeepState(state);
  if (mapAdded) ctx.pushTreasureMapInfo(session);
  if (toSend.length > 0) ctx.sendRewardList(session, toSend, 50);
  for (const tid of updatedTokens) {
    pushTokenUpdate(session, tid, state.tokens[tid] || 0);
  }
}

// ============================================================
// 统一领奖 / 兑换 / 置换处理入口
// 返回 true 表示已处理该 key，false 交回 server.mjs 原有逻辑
// ============================================================
export function handleDeepTakeCarnivalReward(session, key, step, exchangeId, body, ctx) {
  if (!Object.values(DEEP_KEYS).includes(key)) return false;

  const state = loadDeepState();
  const index = Math.floor(Number(step) || 0);

  // 1) 星海黑洞：血钻深水区累消（支持三轮进化热刷新）
  if (key === DEEP_KEYS.BLOOD_BLACKHOLE) {
    const tiers = getBloodBlackholeTiers(state.bloodCycle);
    const tier = tiers[index - 1];
    const mapNeed = tier ? tier.rewards.filter((r) => r.reward_type === 21).reduce((s, r) => s + (r.param2 || 1), 0) : 0;
    const tState = ctx.getTreasureState(session);
    if (!tier) {
      body.result = 3;
    } else if (state.bloodClaimed.includes(index)) {
      body.result = 4;
    } else if (state.bloodSpend < tier.need) {
      body.result = 3;
    } else if (mapNeed > 0 && tState.maps.size + mapNeed > ctx.MAX_TREASURE_MAPS) {
      body.result = 10;
    } else {
      state.bloodClaimed.push(index);
      state.bloodClaimed.sort((a, b) => a - b);
      const allClaimed = state.bloodClaimed.length >= tiers.length;
      if (allClaimed) {
        state.bloodSpend = 0;
        state.bloodClaimed = [];
        state.bloodCycle += 1;
      }
      saveDeepState(state);
      body.result = 0;
      dispatchDeepRewards(session, tier.rewards, ctx, state);
      session.send({ session: 0, sync_id: 0, take_carnival_reward_ret: body });
      if (allClaimed) {
        const nextCfg = buildBloodBlackholeConfig(state);
        const nextTiers = getBloodBlackholeTiers(state.bloodCycle);
        session.send({
          session: 0,
          sync_id: 0,
          query_carnival_config_ret: { config: [nextCfg] },
        });
        session.send({
          session: 0,
          sync_id: 0,
          query_carnival_info_ret: {
            carnival_info: [
              {
                key: DEEP_KEYS.BLOOD_BLACKHOLE,
                cur_value: 0,
                cur_value_multi: [],
                collect_info: [0],
                step_reward: nextTiers.map(() => 1),
                step_flag: nextTiers.map(() => 1),
                exchange_record: [],
              },
            ],
          },
        });
      }
      console.log(`[deep_carnival] blood_blackhole step=${step} cycle=${state.bloodCycle} spend=${state.bloodSpend}`);
      return true;
    }
    session.send({ session: 0, sync_id: 0, take_carnival_reward_ret: body });
    return true;
  }

  // 2) 肝帝通行证：六线活跃里程碑
  if (key === DEEP_KEYS.GRIND_PASS) {
    const tier = GRIND_PASS_TIERS[index - 1];
    const mapNeed = tier ? tier.rewards.filter((r) => r.reward_type === 21).reduce((s, r) => s + (r.param2 || 1), 0) : 0;
    const tState = ctx.getTreasureState(session);
    if (!tier) {
      body.result = 3;
    } else if (state.passClaimed.includes(index)) {
      body.result = 4;
    } else if (state.passPoints < tier.need) {
      body.result = 3;
    } else if (mapNeed > 0 && tState.maps.size + mapNeed > ctx.MAX_TREASURE_MAPS) {
      body.result = 10;
    } else {
      state.passClaimed.push(index);
      state.passClaimed.sort((a, b) => a - b);
      const allClaimed = state.passClaimed.length >= GRIND_PASS_TIERS.length;
      if (allClaimed) {
        state.passPoints = 0;
        state.passClaimed = [];
        state.passCycle += 1;
        state.passBySource = { mine: 0, treasure: 0, vanity: 0, campaign: 0, guild: 0, pvp: 0 };
      }
      saveDeepState(state);
      body.result = 0;
      dispatchDeepRewards(session, tier.rewards, ctx, state);
      session.send({ session: 0, sync_id: 0, take_carnival_reward_ret: body });
      if (allClaimed) {
        session.send({
          session: 0,
          sync_id: 0,
          query_carnival_info_ret: {
            carnival_info: [
              {
                key: DEEP_KEYS.GRIND_PASS,
                cur_value: 0,
                cur_value_multi: [],
                collect_info: [0],
                step_reward: GRIND_PASS_TIERS.map(() => 1),
                step_flag: GRIND_PASS_TIERS.map(() => 1),
                exchange_record: [],
              },
            ],
          },
        });
      }
      console.log(`[deep_carnival] grind_pass step=${step} cycle=${state.passCycle} pts=${state.passPoints}`);
      return true;
    }
    session.send({ session: 0, sync_id: 0, take_carnival_reward_ret: body });
    return true;
  }

  // 3) 星核兑换 / 4) 印记工坊
  if (key === DEEP_KEYS.STAR_CORE_SHOP || key === DEEP_KEYS.GRIND_MARK_SHOP) {
    const isStar = key === DEEP_KEYS.STAR_CORE_SHOP;
    const tokenId = isStar ? TOKEN_STAR_CORE : TOKEN_GRIND_MARK;
    const tiers = isStar ? STAR_CORE_SHOP_TIERS : GRIND_MARK_SHOP_TIERS;
    const counts = isStar ? state.starCoreCounts : state.grindMarkCounts;
    const tier = tiers[index - 1];
    const used = Math.max(0, Math.floor(Number(counts[index]) || 0));
    const have = state.tokens[tokenId] || 0;
    const mapNeed = tier ? tier.rewards.filter((r) => r.reward_type === 21).reduce((s, r) => s + (r.param2 || 1), 0) : 0;
    const tState = ctx.getTreasureState(session);

    if (!tier) {
      body.result = 3;
    } else if (used >= tier.limit) {
      body.result = 4;
    } else if (have < tier.cost) {
      body.result = 3;
    } else if (mapNeed > 0 && tState.maps.size + mapNeed > ctx.MAX_TREASURE_MAPS) {
      body.result = 10;
    } else {
      state.tokens[tokenId] = have - tier.cost;
      counts[index] = used + 1;
      saveDeepState(state);
      body.result = 0;
      pushTokenUpdate(session, tokenId, state.tokens[tokenId]);
      dispatchDeepRewards(session, tier.rewards, ctx, state);
      session.send({ session: 0, sync_id: 0, take_carnival_reward_ret: body });
      console.log(`[deep_carnival] ${key} step=${index} cost=${tier.cost} left=${state.tokens[tokenId]}`);
      return true;
    }
    session.send({ session: 0, sync_id: 0, take_carnival_reward_ret: body });
    return true;
  }

  // 5) 同源置换（2:1 防非灵魂石置换）
  if (key === DEEP_KEYS.SOUL_EXCHANGE) {
    const stepCfg = SOUL_EXCHANGE_STEPS[index - 1];
    const exCfg = SOUL_EXCHANGE_ENTRIES[Math.floor(Number(exchangeId) || 0)];
    const troop = ctx.getTroopState(session);
    if (!stepCfg || !exCfg || exCfg.groupId !== stepCfg.groupId) {
      body.result = 3;
    } else {
      const used = Math.max(0, Math.floor(Number(state.soulExchangeCounts[exCfg.id]) || 0));
      const curSoul = troop?.library?.get(exCfg.mercId) ?? 0;
      if (used >= exCfg.times) {
        body.result = 22; // exchange_times_limit
      } else if (curSoul < exCfg.cost) {
        body.result = 21; // not_enough_soul
      } else {
        ctx.addTroopLibrary(troop, exCfg.mercId, -exCfg.cost);
        ctx.saveTroopState(troop);
        state.soulExchangeCounts[exCfg.id] = used + 1;
        saveDeepState(state);
        body.result = 0;
        body.exchange_id = exCfg.id;
        body.exchange_mercenary_id = exCfg.mercId;
        body.exchange_soul_stone_num = exCfg.cost;
        dispatchDeepRewards(session, [rSoul(stepCfg.targetMerc, 1)], ctx, state);
        session.send({ session: 0, sync_id: 0, take_carnival_reward_ret: body });
        console.log(`[deep_carnival] soul_exchange ${exCfg.mercId}x${exCfg.cost} -> ${stepCfg.targetMerc}x1`);
        return true;
      }
    }
    session.send({ session: 0, sync_id: 0, take_carnival_reward_ret: body });
    return true;
  }

  // 6) 全系宗师（12档五维独立进度里程碑）
  if (key === DEEP_KEYS.MASTER_MILESTONES) {
    const tier = MASTER_MILESTONE_TIERS[index - 1];
    const metrics = computeMasterMetrics(session, ctx, state);
    const curVal = tier ? (metrics[tier.metric] ?? 0) : 0;
    const mapNeed = tier ? tier.rewards.filter((r) => r.reward_type === 21).reduce((s, r) => s + (r.param2 || 1), 0) : 0;
    const tState = ctx.getTreasureState(session);

    if (!tier) {
      body.result = 3;
    } else if (state.masterClaimed.includes(index)) {
      body.result = 4;
    } else if (curVal < tier.need) {
      body.result = 3;
    } else if (mapNeed > 0 && tState.maps.size + mapNeed > ctx.MAX_TREASURE_MAPS) {
      body.result = 10;
    } else {
      state.masterClaimed.push(index);
      state.masterClaimed.sort((a, b) => a - b);
      saveDeepState(state);
      body.result = 0;
      dispatchDeepRewards(session, tier.rewards, ctx, state);
      session.send({ session: 0, sync_id: 0, take_carnival_reward_ret: body });
      console.log(`[deep_carnival] master_milestones step=${index} metric=${tier.metric} val=${curVal}/${tier.need}`);
      return true;
    }
    session.send({ session: 0, sync_id: 0, take_carnival_reward_ret: body });
    return true;
  }

  return false;
}
